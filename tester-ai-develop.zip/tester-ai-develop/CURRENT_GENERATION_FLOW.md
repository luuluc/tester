# 🚀 Luồng Generate Test Case Hiện Tại

## 📊 Tổng Quan

Sau khi click nút **"🚀 Bắt đầu Generate Test Cases"**, hệ thống sẽ:

1. Sử dụng **sections đã được chọn và phân tích** từ Step 3
2. Áp dụng **hierarchical approach** để gen testcase
3. Dùng **1 prompt duy nhất**: `generate_hierarchical_test_case_prompt()`

---

## 🔄 Luồng Chi Tiết

### 1️⃣ User Action (streamlit_app.py)
```
User click: "🚀 Bắt đầu Generate Test Cases" (line 1668)
  ↓
Set session_state.generation_started = True
  ↓
Rerun app
```

### 2️⃣ Generation Process (streamlit_app.py line 155-280)
```
Check: if generation_started == True
  ↓
Get: selected_sections_for_generation (từ Step 3)
  ↓
Call: generate_test_cases_from_sections() (data/processor.py)
```

### 3️⃣ Main Generation Loop (data/processor.py)
```python
def generate_test_cases_from_sections(selected_sections, progress_placeholder, model_name, template_analysis):
    """Primary and ONLY generation method"""
    
    for section in selected_sections:
        # 1. Tạo hierarchical context
        hierarchy_context = f"{parent_context} > Level {level}: {section_title}"
        
        # 2. Generate prompt
        prompt = generate_hierarchical_test_case_prompt(
            section, 
            hierarchy_context, 
            template_analysis
        )
        
        # 3. Call AI
        response = call_ollama_api(
            prompt, 
            model_name, 
            stream_placeholder,
            section_title, 
            full_path
        )
        
        # 4. Parse response và lưu test cases
        test_cases = parse_response(response)
```

### 4️⃣ Prompt Generation (ai/ollama_client.py)
```python
def generate_hierarchical_test_case_prompt(section: dict, hierarchy_context: str, template_analysis: dict = None) -> str:
    """
    Tạo prompt với:
    - XML structure output
    - Feedback enhancement từ Qdrant
    - Template analysis (nếu có)
    - Domain detection với LLM
    - Optimized query cho semantic search
    """
    
    # 1. Detect domains & get optimized query
    detection_result = detect_domains_with_llm(section_title, content_preview)
    domains = detection_result['domains']
    optimized_query = detection_result['optimized_query']
    
    # 2. Retrieve lessons từ Qdrant
    lessons = qdrant_service.get_relevant_lessons_semantic(
        query_text=optimized_query,
        domain=None,  # Pure semantic search
        limit=10
    )
    
    # 3. Build prompt với feedback enhancement
    feedback_enhancement = get_feedback_enhancement(section_title, content_preview)
    
    # 4. Return complete prompt
    return prompt_with_xml_structure
```

### 5️⃣ AI Call (ai/ollama_client.py)
```python
def call_ollama_api(prompt, model, stream_placeholder, section_title, section_path, stream=True):
    """
    Wrapper cho call_ai_api
    """
    return call_ai_api(prompt, model, stream_placeholder, section_path, stream)

def call_ai_api(prompt, model, stream_placeholder, section_path, stream=True):
    """
    Gọi LLM service để xử lý prompt
    - Hỗ trợ streaming
    - Lưu prompt & response
    - Return AI response
    """
    llm_service = get_llm_service()
    response = llm_service.call_ai_api(
        prompt=prompt,
        model_name=model,
        stream=stream
    )
    
    # Save prompt & response
    save_prompt_and_response(prompt, response, section_path)
    
    return response
```

---

## 📦 Các Hàm Chính Được Dùng

### ✅ ACTIVE Functions

#### **data/processor.py:**
1. `generate_test_cases_from_sections()` - Main generation loop
2. `generate_hierarchical_test_cases()` - Fallback nếu không có selected sections
3. `analyze_excel_template_structure()` - Phân tích Excel template
4. `create_excel_file()` - Export testcases ra Excel

#### **ai/ollama_client.py:**
1. `detect_domains_with_llm()` - Detect domains + optimize query bằng LLM
2. `get_feedback_enhancement()` - Retrieve lessons từ Qdrant
3. `generate_hierarchical_test_case_prompt()` - **PROMPT DUY NHẤT** đang dùng
4. `call_ollama_api()` - Wrapper cho AI call
5. `call_ai_api()` - Main AI call function
6. `save_prompt_and_response()` - Lưu prompt/response vào file JSON

---

## 🗑️ Đã Xóa (490 lines)

### ❌ REMOVED Functions

#### **ai/ollama_client.py:**
1. ❌ `generate_test_case_prompt()` - Old prompt (158 lines)
2. ❌ `generate_test_case_prompt_with_children()` - Old prompt (158 lines)
3. ❌ `ask_ai_merge_decision()` - Không dùng (174 lines)

#### **data/processor.py:**
1. ❌ `generate_test_cases_for_structure()` - Legacy function (4 lines)

#### **streamlit_app.py:**
1. ❌ Removed import `generate_test_cases_for_structure`

---

## 📝 Prompt XML Structure

```xml
<function_analysis>
  <is_testable>true</is_testable>
  <function_description>Mô tả chức năng...</function_description>
  <test_cases>
    <test_case>
      <name>Tên test case</name>
      <steps>
        <step>Bước 1</step>
        <step>Bước 2</step>
      </steps>
      <priority>Cao</priority>
      <location>Path trong tài liệu</location>
      <result></result>
    </test_case>
  </test_cases>
</function_analysis>
```

---

## 🎯 Key Features

1. **Hierarchical Approach**: Xử lý documents theo cấu trúc phân cấp
2. **Single Prompt**: Chỉ dùng 1 prompt function duy nhất (clean & maintainable)
3. **Feedback Enhancement**: Tích hợp RAG với Qdrant
4. **Domain Detection**: LLM detect multiple domains cho semantic search
5. **Template Support**: Hỗ trợ Excel template analysis
6. **Streaming**: Real-time response streaming từ AI

---

## 📊 Statistics

- **Total Active Functions**: 10
- **Removed Functions**: 4 (490 lines deleted)
- **Code Reduction**: ~45% in ollama_client.py
- **Prompt Functions**: 1 (down from 4)

---

**Generated**: 2025-10-05
**Status**: ✅ Production Ready
