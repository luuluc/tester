from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph
import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class DocumentNode:
    """Represents a structured node in the document hierarchy."""
    title: str
    level: int
    content: List[Any]
    children: List['DocumentNode']
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert node to dictionary for JSON serialization."""
        return {
            "title": self.title,
            "level": self.level,
            "content": self.content,
            "children": [child.to_dict() for child in self.children]
        }

@dataclass
class ListItem:
    """Represents a list item in the document."""
    items: List[str]
    list_type: str  # 'bullet' or 'number'
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert list to dictionary for JSON serialization."""
        return {
            "list": self.items,
            "type": self.list_type
        }

class DocumentProcessor:
    """Handles DOCX document processing and structure extraction."""
    
    def __init__(self, docx_path: str, use_pattern_fallback: bool = False):
        """Initialize the document processor.
        
        Args:
            docx_path: Path to the DOCX file to process
            use_pattern_fallback: If True, use pattern detection as fallback when style-based detection fails.
                                 Default is False to respect Word's native structure.
        """
        self.docx_path = docx_path
        self.doc = None
        self.stack: List[DocumentNode] = []
        self.result: List[DocumentNode] = []
        self.current_list: Optional[ListItem] = None
        self.use_pattern_fallback = use_pattern_fallback
        
    def _load_document(self) -> bool:
        """Load the DOCX document.
        
        Returns:
            True if document loaded successfully, False otherwise
        """
        try:
            self.doc = Document(self.docx_path)
            logger.info(f"Successfully loaded document: {self.docx_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to load document {self.docx_path}: {e}")
            return False
    
    def _get_paragraph_level(self, paragraph: Paragraph) -> Optional[int]:
        """Extract heading level from paragraph style or outline level.
        Uses ONLY Word's native structure (Heading styles and outline levels).
        This respects how the user structured their document in Word.
        
        Args:
            paragraph: The paragraph to analyze
            
        Returns:
            Heading level if it's a heading, None otherwise
        """
        try:
            style = paragraph.style.name
            logger.debug(f"Checking paragraph style: '{style}'")
            
            # Method 1: Standard Word Heading styles (Heading 1, Heading 2, etc.)
            if style.startswith("Heading"):
                level_part = style.replace("Heading", "").strip()
                if level_part.isdigit():
                    level = int(level_part)
                    logger.info(f"Found heading from style '{style}' -> Level {level}")
                    return level
                return 1
            
            # Method 2: Outline Level (References -> Add Text -> Level in Word)
            # This is the most reliable way to get document structure
            try:
                p_element = paragraph._p
                pPr = p_element.find('.//w:pPr', paragraph._element.nsmap)
                if pPr is not None:
                    outlineLvl = pPr.find('.//w:outlineLvl', paragraph._element.nsmap)
                    if outlineLvl is not None:
                        level = int(outlineLvl.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val', '0'))
                        level = level + 1  # Outline levels are 0-based, convert to 1-based
                        logger.info(f"Found heading from outline level -> Level {level}")
                        return level
            except Exception as e:
                logger.debug(f"Error checking outline level: {e}")
            
            # Method 3: Check for other common Word heading-related styles
            style_lower = style.lower()
            
            # Title style (usually Level 1)
            if style_lower == 'title':
                logger.info(f"Found Title style -> Level 1")
                return 1
            
            # Subtitle style (usually Level 2)
            if style_lower == 'subtitle':
                logger.info(f"Found Subtitle style -> Level 2")
                return 2
            
            # No heading style found
            return None
            
        except Exception as e:
            logger.warning(f"Error getting paragraph level: {e}")
            return None
    
    def _is_list_paragraph(self, paragraph: Paragraph) -> bool:
        """Check if paragraph is part of a list.
        
        Args:
            paragraph: The paragraph to check
            
        Returns:
            True if paragraph is a list item, False otherwise
        """
        try:
            p = paragraph._p
            numPr = p.find('.//w:numPr', paragraph._element.nsmap)
            return numPr is not None
        except Exception as e:
            logger.warning(f"Error checking list paragraph: {e}")
            return False
    
    def _get_list_type(self, paragraph: Paragraph) -> str:
        """Determine list type (bullet or number).
        
        Args:
            paragraph: The paragraph to analyze
            
        Returns:
            'bullet' or 'number'
        """
        try:
            style = paragraph.style.name.lower()
            if 'bullet' in style:
                return 'bullet'
        except Exception as e:
            logger.warning(f"Error getting list type: {e}")
        return 'number'
    
    def _table_to_html(self, table: Table) -> str:
        """Convert table to HTML format.
        
        Args:
            table: The table to convert
            
        Returns:
            HTML representation of the table
        """
        try:
            html = "<table border='1'>\n"
            for row in table.rows:
                html += "  <tr>\n"
                for cell in row.cells:
                    cell_text = cell.text.strip().replace("\n", "<br/>")
                    html += f"    <td>{cell_text}</td>\n"
                html += "  </tr>\n"
            html += "</table>"
            return html
        except Exception as e:
            logger.warning(f"Error converting table to HTML: {e}")
            return "<table><tr><td>Error processing table</td></tr></table>"
    
    def _create_node(self, title: str, level: int) -> DocumentNode:
        """Create a new document node.
        
        Args:
            title: Node title
            level: Heading level
            
        Returns:
            New DocumentNode instance
        """
        return DocumentNode(
            title=title,
            level=level,
            content=[],
            children=[]
        )
    
    def _add_node_to_stack(self, node: DocumentNode) -> None:
        """Add node to the processing stack maintaining hierarchy.
        
        Args:
            node: The node to add
        """
        # Pop nodes from stack if current level is less than or equal to stack top
        while self.stack and node.level <= self.stack[-1].level:
            self.stack.pop()
        
        # Add to appropriate parent
        if not self.stack:
            self.result.append(node)
        else:
            self.stack[-1].children.append(node)
        
        self.stack.append(node)
    
    def _finalize_current_list(self) -> None:
        """Finalize and add current list to the last node in stack."""
        if self.current_list and self.stack:
            self.stack[-1].content.append(self.current_list.to_dict())
            self.current_list = None
    
    def _add_text_content(self, text: str) -> None:
        """Add text content to current node in standardized format.
        
        Args:
            text: Text content to add
        """
        if not self.stack:
            self._handle_unstructured_content()
        
        self.stack[-1].content.append({
            "text": text
        })
    
    def _add_table_content(self, table_html: str) -> None:
        """Add table content to current node in standardized format.
        
        Args:
            table_html: HTML representation of table
        """
        if not self.stack:
            self._handle_unstructured_content()
        
        self.stack[-1].content.append({
            "table": [table_html]
        })
    
    def _handle_unstructured_content(self) -> None:
        """Handle documents without proper heading structure."""
        if not self.result:
            # Create a default root node for unstructured content
            root_node = self._create_node("Document Content", 1)
            self.result.append(root_node)
            self.stack.append(root_node)
            logger.info("Created default root node for unstructured document")
    
    def _process_paragraph(self, paragraph: Paragraph) -> None:
        """Process a single paragraph.
        Uses Word's native structure (outline levels, heading styles) as primary method.
        
        Args:
            paragraph: The paragraph to process
        """
        text = paragraph.text.strip()
        if not text:
            return
        
        # PRIORITY 1: Get heading level from Word's native structure (styles and outline levels)
        level = self._get_paragraph_level(paragraph)
        
        # PRIORITY 2: Only use pattern detection as fallback if explicitly enabled
        # (Disabled by default to respect Word's structure)
        if level is None and self.use_pattern_fallback:
            level = self._is_potential_heading(paragraph)
        
        if level and text:  # It's a heading
            self._finalize_current_list()
            node = self._create_node(text, level)
            self._add_node_to_stack(node)
            logger.info(f"Created heading node: '{text}' at level {level}")
            
        elif self._is_list_paragraph(paragraph) and text:
            # Ensure we have a node to add content to
            if not self.stack:
                self._handle_unstructured_content()
            
            list_type = self._get_list_type(paragraph)
            
            if not self.current_list or self.current_list.list_type != list_type:
                self._finalize_current_list()
                self.current_list = ListItem(items=[], list_type=list_type)
            
            self.current_list.items.append(text)
            
        elif text:  # Regular paragraph
            # Ensure we have a node to add content to
            if not self.stack:
                self._handle_unstructured_content()
            
            self._finalize_current_list()
            self._add_text_content(text)
    
    def _process_table(self, table: Table) -> None:
        """Process a table element.
        
        Args:
            table: The table to process
        """
        # Ensure we have a node to add content to
        if not self.stack:
            self._handle_unstructured_content()
        
        self._finalize_current_list()
        html = self._table_to_html(table)
        self._add_table_content(html)
    
    def process_document(self) -> List[Dict[str, Any]]:
        """Process the entire document and extract structure.
        
        Returns:
            List of document nodes as dictionaries
        """
        if not self._load_document():
            return []
        
        try:
            # Process document elements
            for block in self.doc.element.body.iterchildren():
                try:
                    if block.tag.endswith("p"):
                        paragraph = Paragraph(block, self.doc)
                        self._process_paragraph(paragraph)
                    elif block.tag.endswith("tbl"):
                        table = Table(block, self.doc)
                        self._process_table(table)
                except Exception as e:
                    logger.warning(f"Error processing block: {e}")
                    continue
            
            # Finalize any remaining list
            self._finalize_current_list()
            
            # Handle case where document has no structure
            if not self.result:
                logger.warning("No structured content found, creating default structure")
                self._handle_unstructured_content()
            
            # Convert to dictionaries for JSON serialization
            return [node.to_dict() for node in self.result]
            
        except Exception as e:
            logger.error(f"Error processing document: {e}")
            return []
    
    def _is_potential_heading(self, paragraph: Paragraph) -> Optional[int]:
        """Check if paragraph could be a heading based on formatting and text patterns.
        Enhanced to detect multiple heading indicators.
        
        Args:
            paragraph: The paragraph to analyze
            
        Returns:
            Estimated heading level if it looks like a heading, None otherwise
        """
        try:
            text = paragraph.text.strip()
            if not text or len(text) > 200:  # Skip empty or very long paragraphs
                return None
            
            # Check formatting characteristics
            is_bold = False
            is_all_bold = True
            font_size = None
            font_sizes = []
            has_underline = False
            
            try:
                # Check if paragraph has runs with formatting
                total_runs = len(paragraph.runs)
                bold_runs = 0
                
                for run in paragraph.runs:
                    # Check bold
                    if run.bold:
                        is_bold = True
                        bold_runs += 1
                    else:
                        is_all_bold = False
                    
                    # Check font size
                    if run.font.size:
                        size_pt = run.font.size.pt
                        font_sizes.append(size_pt)
                        if font_size is None or size_pt > font_size:
                            font_size = size_pt
                    
                    # Check underline
                    if run.font.underline:
                        has_underline = True
                
                # If most runs are bold, consider it all bold
                if total_runs > 0 and bold_runs >= total_runs * 0.8:
                    is_all_bold = True
                    
            except Exception as e:
                logger.debug(f"Error checking formatting: {e}")
            
            # Import regex for pattern matching
            import re
            
            # 1. Check for strong numbering patterns (high confidence)
            # Roman numerals (I., II., III., etc.)
            if re.match(r'^[IVX]+\.\s+', text):
                return 1
            
            # Numbered sections (1., 2., 3., etc.)
            if re.match(r'^\d+\.\s+', text):
                # If bold or large font, level 1, otherwise level 2
                if is_bold or (font_size and font_size >= 14):
                    return 1
                return 2
            
            # Multi-level numbering (1.1, 1.2, 1.1.1, etc.)
            numbering_match = re.match(r'^(\d+(?:\.\d+)*)\.\s+', text)
            if numbering_match:
                depth = numbering_match.group(1).count('.')
                return min(depth + 1, 6)  # Cap at level 6
                
            # Lettered subsections (a., b., c., etc.)
            if re.match(r'^[a-z]\.\s+', text):
                return 3
            
            # Uppercase letters (A., B., C., etc.)
            if re.match(r'^[A-Z]\.\s+', text):
                return 2
            
            # Parenthetical numbering (1), (2), (3), etc.
            if re.match(r'^\(\d+\)\s+', text):
                return 3
                
            # 2. Check for Vietnamese/English document structure keywords
            structure_patterns = [
                (r'^CHƯƠNG\s+[IVX\d]+', 1),     # Chapter
                (r'^PHẦN\s+[IVX\d]+', 1),       # Part
                (r'^MỤC\s+[IVX\d]+', 2),        # Section
                (r'^ĐIỀU\s+\d+', 2),            # Article
                (r'^KHOẢN\s+\d+', 3),           # Clause
                (r'^Chapter\s+[IVX\d]+', 1),    # English
                (r'^Part\s+[IVX\d]+', 1),
                (r'^Section\s+[IVX\d]+', 2),
                (r'^Article\s+\d+', 2),
                (r'^Clause\s+\d+', 3),
            ]
            
            for pattern, level in structure_patterns:
                if re.match(pattern, text, re.IGNORECASE):
                    return level
            
            # 3. Check for ALL CAPS text (often used for headings)
            if text.isupper() and len(text.split()) <= 12:
                # Very short ALL CAPS = level 1
                if len(text) < 50:
                    return 1
                # Longer ALL CAPS = level 2
                return 2
            
            # 4. Font size based detection
            if font_size:
                word_count = len(text.split())
                # Large font + short text = likely heading
                if font_size >= 16 and word_count <= 20:
                    return 1
                elif font_size >= 14 and word_count <= 20:
                    return 2
                elif font_size >= 12 and word_count <= 15 and is_bold:
                    return 3
            
            # 5. Bold text detection (comprehensive check)
            if is_all_bold or (is_bold and len(text) < 100):
                word_count = len(text.split())
                
                # Check if it looks like a paragraph (multiple sentences)
                sentence_count = len(re.findall(r'[.!?]\s+[A-Z]', text))
                has_paragraph_markers = sentence_count > 1
                
                # Check for Vietnamese connecting words (indicates paragraph, not heading)
                vietnamese_connectors = [
                    r'\b(và|hoặc|nhưng|tuy nhiên|do đó|ngoài ra|bởi vì|vì vậy|mặc dù)\b',
                ]
                has_connectors = any(re.search(pattern, text, re.IGNORECASE) for pattern in vietnamese_connectors)
                
                # Bold + short + no paragraph indicators = heading
                if word_count <= 15 and not has_paragraph_markers and not has_connectors:
                    # Check if ends like a title (no period or ends with colon)
                    ends_like_title = not text.endswith(('.', '!', '?')) or text.endswith(':')
                    
                    if ends_like_title:
                        # Use font size to determine level if available
                        if font_size and font_size >= 14:
                            return 1
                        elif font_size and font_size >= 12:
                            return 2
                        else:
                            return 2  # Default for bold headings
            
            # 6. Check for underlined text (sometimes used for headings)
            if has_underline and len(text.split()) <= 15:
                return 3
            
            # 7. Dash or bullet points with short text (sometimes headings in lists)
            if re.match(r'^[-•]\s+', text) and len(text.split()) <= 10:
                return 4
            
        except Exception as e:
            logger.debug(f"Error in potential heading detection: {e}")
        
        return None

class DocumentStructureExtractor:
    """Main class for extracting document structure from DOCX files.
    
    By default, uses Word's native structure (Heading styles and outline levels).
    This respects how the document was structured in Word by the user.
    """
    
    def __init__(self, use_pattern_fallback: bool = False):
        """Initialize the extractor.
        
        Args:
            use_pattern_fallback: If True, use pattern detection when Word structure is missing.
                                 Default False to respect Word's native structure.
        """
        self.use_pattern_fallback = use_pattern_fallback
    
    def extract_structure(self, docx_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
        """Extract structure from DOCX file using Word's native structure.
        
        Args:
            docx_path: Path to the DOCX file
            output_path: Optional path to save JSON output
            
        Returns:
            Dictionary containing document structure and metadata
        """
        processor = DocumentProcessor(docx_path, use_pattern_fallback=self.use_pattern_fallback)
        structured_data = processor.process_document()
        
        result = {
            "document_path": docx_path,
            "total_sections": len(structured_data),
            "structure": structured_data,
            "metadata": {
                "has_structure": len(structured_data) > 0 and any(
                    node.get("level", 0) > 0 for node in structured_data
                ),
                "processing_status": "success" if structured_data else "failed"
            }
        }
        
        if output_path:
            self._save_to_json(result, output_path)
        
        return result
    
    def _save_to_json(self, data: Dict[str, Any], output_path: str) -> None:
        """Save data to JSON file.
        
        Args:
            data: Data to save
            output_path: Path to save the JSON file
        """
        try:
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            logger.info(f"Structured data saved to {output_path}")
        except Exception as e:
            logger.error(f"Failed to save JSON file: {e}")

def main():
    """Main function to demonstrate usage."""
    extractor = DocumentStructureExtractor()
    
    # Process the document
    docx_path = "danh_sach_shop_1.docx"
    output_file = "document_structure.json"
    
    try:
        result = extractor.extract_structure(docx_path, output_file)
        
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        print(f"Error processing document: {e}")

if __name__ == "__main__":
    main()
