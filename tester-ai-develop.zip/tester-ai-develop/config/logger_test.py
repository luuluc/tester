"""
Example usage of ContextLogger
"""
import os
from context_logger_config import setup_context_logger

def main():
    # Initialize logger
    logger = setup_context_logger("logs")
    
    # Test context metrics logging
    logger.log_context_metrics({
        "title": "Test Feature",
        "level": "High",
        "path": "/test/feature",
        "related_sections": ["section1", "section2"],
        "relatedFlows": ["flow1", "flow2"],
        "processing_time": 1.5,
        "test_count": 10,
        "coverage_rate": 85.0,
        "duplication_rate": 5.0,
        "error_count": 0
    })
    
    # Test test case logging
    logger.log_test_case_generation({
        "name": "Test Login Feature",
        "priority": "High",
        "steps": [
            "Open login page",
            "Enter credentials",
            "Click login button"
        ],
        "related_flows": ["Authentication", "User Management"]
    })
    
    # Test error logging
    logger.log_context_error({
        "message": "Failed to process test case",
        "location": "test_processor.py:123",
        "details": "Invalid test case format detected"
    })
    
    # Test warning logging
    logger.log_context_warning({
        "message": "Test coverage below threshold",
        "suggestion": "Add more test cases for edge conditions"
    })
    
    # Test performance metrics logging
    logger.log_performance_metrics({
        "processing_time": 2.5,
        "test_case_count": 15,
        "coverage": 75.5,
        "duplication_rate": 3.0
    })

if __name__ == "__main__":
    main()
    print("Check the logs directory for generated log files!")