# Logger Configuration Guide

This directory contains a centralized logger configuration system for the AI Agent Tester application.

## Overview

The `logger_config.py` module provides a consistent and easy-to-use logging setup across all modules in the project. It eliminates the need to configure loggers manually in each file.

## Features

- ✅ **Centralized Configuration**: Single place to manage all logging settings
- ✅ **Automatic File & Console Output**: Logs to both console and files by default
- ✅ **Date-based Log Files**: Automatically creates daily log files
- ✅ **Custom Log Directories**: Organize logs by module or feature
- ✅ **Predefined Loggers**: Ready-to-use loggers for common use cases
- ✅ **Flexible Configuration**: Customize format, level, and output destinations
- ✅ **UTF-8 Support**: Full Unicode/Vietnamese text support in logs

## Quick Start

### Basic Usage (Recommended)

Add these two lines at the top of any Python module:

```python
from config.logger_config import setup_logger

logger = setup_logger(__name__)
```

Then use the logger throughout your module:

```python
logger.info("This is an info message")
logger.warning("This is a warning")
logger.error("This is an error", exc_info=True)
logger.debug("This is a debug message")
```

## Available Functions

### 1. `setup_logger(name, **options)`

Primary function to create a logger with custom configuration.

**Parameters:**
- `name` (str): Logger name, usually `__name__`
- `log_dir` (str): Directory for log files (default: "logs")
- `log_level` (int): Logging level (default: `logging.INFO`)
- `console_output` (bool): Enable console output (default: `True`)
- `file_output` (bool): Enable file output (default: `True`)
- `log_format` (str): Custom log format (optional)
- `date_format` (str): Custom date format (optional)

**Example:**
```python
logger = setup_logger(
    __name__,
    log_dir="custom_logs",
    log_level=logging.DEBUG,
    log_format='[%(levelname)s] %(message)s'
)
```

### 2. `setup_module_logger(module_name, custom_log_file, **kwargs)`

Create a logger that writes to both default and a custom log file.

**Example:**
```python
logger = setup_module_logger(
    __name__,
    custom_log_file="feedback_analysis.log"
)
```

### 3. `get_logger(name)`

Get an existing logger or create one with defaults.

**Example:**
```python
logger = get_logger(__name__)
```

### 4. `set_log_level(logger, level)`

Change log level for a logger and all its handlers.

**Example:**
```python
set_log_level(logger, logging.DEBUG)
```

## Predefined Loggers

For common use cases, use these predefined logger functions:

### Application Logger
```python
from config.logger_config import get_app_logger

logger = get_app_logger()
logger.info("Application started")
```

### AI Operations Logger
```python
from config.logger_config import get_ai_logger

logger = get_ai_logger()
logger.info("Running AI model")
```

### Feedback Analysis Logger
```python
from config.logger_config import get_feedback_logger

logger = get_feedback_logger()
logger.info("Analyzing feedback")
```

### Database Logger
```python
from config.logger_config import get_database_logger

logger = get_database_logger()
logger.info("Database connected")
```

### API Logger
```python
from config.logger_config import get_api_logger

logger = get_api_logger()
logger.info("Calling external API")
```

## Log Levels

From least to most severe:

- `logging.DEBUG` - Detailed debugging information
- `logging.INFO` - General informational messages (default)
- `logging.WARNING` - Warning messages
- `logging.ERROR` - Error messages
- `logging.CRITICAL` - Critical errors

## Log File Structure

Logs are organized in the `logs/` directory with date-based filenames:

```
logs/
├── ai_feedback_analyzer_20251007.log
├── utils_qdrant_feedback_service_20251007.log
├── app.log
├── ai.log
├── database.log
└── api.log
```

## Log Format

Default format: `%(asctime)s - %(name)s - %(levelname)s - %(message)s`

Example output:
```
2025-10-07 14:30:45 - ai.feedback_analyzer - INFO - Starting feedback analysis
2025-10-07 14:30:46 - ai.feedback_analyzer - DEBUG - Processing 5 feedback items
2025-10-07 14:30:47 - ai.feedback_analyzer - ERROR - Failed to connect to API
```

## Advanced Usage

### Console-Only Logger
```python
logger = setup_logger(
    __name__,
    file_output=False,
    console_output=True
)
```

### File-Only Logger
```python
logger = setup_logger(
    __name__,
    file_output=True,
    console_output=False
)
```

### Custom Format
```python
logger = setup_logger(
    __name__,
    log_format='[%(levelname)s] %(asctime)s - %(message)s',
    date_format='%Y-%m-%d %H:%M:%S'
)
```

### Logger in Classes
```python
class MyService:
    def __init__(self):
        self.logger = setup_logger(f"{__name__}.{self.__class__.__name__}")
    
    def process(self):
        self.logger.info("Processing started")
        try:
            # Your code here
            pass
        except Exception as e:
            self.logger.error(f"Error: {e}", exc_info=True)
```

## Migration Guide

If you have existing logging code, replace it with the new centralized configuration:

### Before (Old Way)
```python
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

file_handler = logging.FileHandler("logs/myfile.log")
console_handler = logging.StreamHandler()

formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

logger.addHandler(file_handler)
logger.addHandler(console_handler)
```

### After (New Way)
```python
from config.logger_config import setup_logger

logger = setup_logger(__name__)
```

## Testing

Run the example file to see all features in action:

```bash
python config/logger_example.py
```

This will demonstrate all usage patterns and create sample log files.

## Files Updated

The following files have been migrated to use the centralized logger:

- ✅ `ai/feedback_analyzer.py`
- ✅ `utils/qdrant_feedback_service.py`
- ✅ `utils/embedding_service.py`
- ✅ `document_processer.py`

## Best Practices

1. **Always use `__name__`** as the logger name for proper module identification
2. **Use appropriate log levels**:
   - `DEBUG` for detailed debugging info
   - `INFO` for general progress updates
   - `WARNING` for unexpected but recoverable issues
   - `ERROR` for errors that need attention
   - `CRITICAL` for severe errors
3. **Include context** in log messages: `logger.info(f"Processing user {user_id}")`
4. **Use `exc_info=True`** for exception logging: `logger.error("Error", exc_info=True)`
5. **Don't log sensitive data** (passwords, API keys, personal info)

## Troubleshooting

### Logs not appearing
- Check if the `logs/` directory exists (it's created automatically)
- Verify the log level is appropriate (DEBUG < INFO < WARNING < ERROR)
- Ensure both `console_output` and `file_output` aren't both `False`

### Permission errors
- Ensure write permissions for the `logs/` directory
- Check if log files are locked by another process

### Duplicate log messages
- Make sure you're not calling `setup_logger()` multiple times for the same logger name
- Use `get_logger()` to retrieve existing loggers

## Environment Variables (Future Enhancement)

Future versions may support environment-based configuration:

```bash
export LOG_LEVEL=DEBUG
export LOG_DIR=/var/log/myapp
export LOG_FORMAT='[%(levelname)s] %(message)s'
```

## Contributing

When adding new modules:
1. Import the logger configuration
2. Set up the logger at module level
3. Use consistent logging throughout
4. Document any custom logging requirements

---

For examples and more details, see `logger_example.py` in this directory.

