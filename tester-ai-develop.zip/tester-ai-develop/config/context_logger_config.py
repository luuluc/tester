"""
Context Awareness Logger Configuration
Provides specialized logging for tracking test case context management.
Integrates with the main logging system while adding context-specific features.
"""

import logging
import os
import json
import csv
from datetime import datetime
from typing import Dict, Any, Optional
from dataclasses import dataclass
import sys

# Add the project root directory to the Python path
sys.path.insert(0, os.path.abspath(os.path.dirname(os.path.dirname(__file__))))

from config.logger_config import setup_logger, setup_module_logger

@dataclass
class ContextMetrics:
    """Class để lưu trữ metrics cho việc xử lý ngữ cảnh"""
    section_name: str
    processing_time: float
    test_case_count: int
    coverage_rate: float
    duplication_rate: float
    related_sections: int
    related_flows: int
    error_count: int

# Màu sắc cho log output
class LogColor:
    SUCCESS = '\033[92m'  # Xanh lá
    WARNING = '\033[93m'  # Vàng
    ERROR = '\033[91m'    # Đỏ
    INFO = '\033[94m'     # Xanh dương
    END = '\033[0m'       # Reset màu

class ContextLogger:
    """Enhanced logger cho việc theo dõi và phân tích ngữ cảnh"""
    
    def __init__(self, base_dir: str = "logs"):
        """Khởi tạo logger với các file output cần thiết"""
        try:
            # Ensure absolute path for base directory
            self.base_dir = os.path.abspath(base_dir)
            self.current_date = datetime.now().strftime('%Y%m%d')
            
            # Tạo thư mục logs nếu chưa tồn tại
            os.makedirs(self.base_dir, exist_ok=True)
            
            # Đường dẫn các file log
            self.metrics_file = os.path.join(self.base_dir, f"context_metrics_{self.current_date}.csv")
            self.error_file = os.path.join(self.base_dir, f"context_errors_{self.current_date}.log")
            self.test_cases_file = os.path.join(self.base_dir, f"test_cases_{self.current_date}.json")
            self.performance_file = os.path.join(self.base_dir, f"performance_metrics_{self.current_date}.json")
            
            # Configure root logger first
            root_logger = logging.getLogger()
            if not root_logger.handlers:
                root_logger.setLevel(logging.DEBUG)
                console_handler = logging.StreamHandler()
                console_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
                root_logger.addHandler(console_handler)
            
            # Khởi tạo base logger
            self.logger = setup_module_logger(
                "context_awareness",
                custom_log_file=f"context_awareness_{self.current_date}.log",
                log_dir=self.base_dir,
                log_level=logging.DEBUG,
                console_output=True,
                file_output=True
            )
            
            # Force logger level to DEBUG
            self.logger.setLevel(logging.DEBUG)
            for handler in self.logger.handlers:
                handler.setLevel(logging.DEBUG)
            
            # Khởi tạo file metrics
            self._init_metrics_file()
            self.logger.info(f"Context logger initialized. Log directory: {self.base_dir}")
            self.logger.debug("All log files initialized successfully")

        except Exception as e:
            # Fallback to console logging if file setup fails
            self.logger = logging.getLogger("context_awareness")
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
            self.logger.addHandler(handler)
            self.logger.error(f"Failed to initialize context logger: {str(e)}")
            raise RuntimeError(f"Failed to initialize context logger: {str(e)}")

    def _init_metrics_file(self):
        """Khởi tạo file CSV cho metrics nếu chưa tồn tại"""
        try:
            if not os.path.exists(self.metrics_file):
                with open(self.metrics_file, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow([
                        'timestamp',
                        'section_name',
                        'processing_time',
                        'test_case_count',
                        'coverage_rate',
                        'duplication_rate',
                        'related_sections',
                        'related_flows',
                        'error_count'
                    ])
                self.logger.debug(f"Created metrics file: {self.metrics_file}")
            else:
                self.logger.debug(f"Metrics file already exists: {self.metrics_file}")
        except Exception as e:
            self.logger.error(f"Error creating metrics file: {str(e)}")
            raise

    def _save_metrics(self, metrics: ContextMetrics):
        """Lưu metrics vào file CSV"""
        if not os.path.exists(self.base_dir):
            os.makedirs(self.base_dir, exist_ok=True)
            
        try:
            with open(self.metrics_file, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    metrics.section_name,
                    metrics.processing_time,
                    metrics.test_case_count,
                    metrics.coverage_rate,
                    metrics.duplication_rate,
                    metrics.related_sections,
                    metrics.related_flows,
                    metrics.error_count
                ])
            self.logger.debug(f"Metrics saved for section: {metrics.section_name}")
        except Exception as e:
            self.logger.error(f"Error saving metrics: {str(e)}")
            raise

    def log_test_case_generation(self, test_case_info: Dict[str, Any]):
        """Ghi log thông tin sinh test case mới"""
        try:
            name = test_case_info.get('name', 'Unknown')
            self.logger.info(f"{LogColor.SUCCESS}✨ Test case mới: {name}{LogColor.END}")
            self.logger.info(f"   └── Độ ưu tiên: {test_case_info.get('priority', 'N/A')}")
            self.logger.info(f"   └── Số bước: {len(test_case_info.get('steps', []))}")
            
            if flows := test_case_info.get('related_flows'):
                self.logger.info(f"   └── Luồng liên quan: {', '.join(flows)}")
            
            # Log chi tiết vào JSON
            os.makedirs(os.path.dirname(self.test_cases_file), exist_ok=True)
            with open(self.test_cases_file, 'a', encoding='utf-8') as f:
                json.dump({
                    'timestamp': datetime.now().isoformat(),
                    'test_case': test_case_info
                }, f, ensure_ascii=False)
                f.write('\n')
            
            self.logger.debug(f"Test case logged: {name}")
        except Exception as e:
            self.logger.error(f"Error logging test case generation: {str(e)}")
            raise

    def log_context_error(self, error_info: Dict[str, str]):
        """Ghi log lỗi xử lý ngữ cảnh"""
        try:
            error_msg = f"{LogColor.ERROR}❌ Lỗi xử lý ngữ cảnh: {error_info.get('message', 'Unknown error')}{LogColor.END}"
            self.logger.error(error_msg)
            self.logger.error(f"   └── Vị trí: {error_info.get('location', 'Unknown')}")
            self.logger.error(f"   └── Chi tiết: {error_info.get('details', 'No details')}")
            
            # Log chi tiết vào file lỗi riêng
            os.makedirs(os.path.dirname(self.error_file), exist_ok=True)
            with open(self.error_file, 'a', encoding='utf-8') as f:
                f.write(f"[{datetime.now()}] {error_info.get('message', 'Unknown error')}\n")
                f.write(f"Location: {error_info.get('location', 'Unknown')}\n")
                f.write(f"Details: {error_info.get('details', 'No details')}\n\n")
            
            self.logger.debug(f"Error logged to file: {self.error_file}")
        except Exception as e:
            self.logger.error(f"Error logging context error: {str(e)}")
            raise

    def log_context_warning(self, warning_info: Dict[str, str]):
        """Ghi log cảnh báo về ngữ cảnh"""
        try:
            self.logger.warning(
                f"{LogColor.WARNING}⚠️ Cảnh báo: {warning_info.get('message', 'Unknown warning')}{LogColor.END}"
            )
            if suggestion := warning_info.get('suggestion'):
                self.logger.warning(f"   └── Gợi ý: {suggestion}")
        except Exception as e:
            self.logger.error(f"Error logging warning: {str(e)}")
            raise

    def log_performance_metrics(self, metrics: Dict[str, float]):
        """Ghi log và lưu metrics hiệu suất"""
        try:
            self.logger.info(f"{LogColor.INFO}📊 Thống kê hiệu suất:{LogColor.END}")
            self.logger.info(f"   ├── Thời gian xử lý: {metrics.get('processing_time', 0.0):.2f}s")
            self.logger.info(f"   ├── Số test case: {metrics.get('test_case_count', 0)}")
            self.logger.info(f"   ├── Độ bao phủ: {metrics.get('coverage', 0.0):.1f}%")
            self.logger.info(f"   └── Tỷ lệ trùng lặp: {metrics.get('duplication_rate', 0.0):.1f}%")

            # Lưu metrics vào file JSON
            os.makedirs(os.path.dirname(self.performance_file), exist_ok=True)
            with open(self.performance_file, 'a', encoding='utf-8') as f:
                json.dump({
                    'timestamp': datetime.now().isoformat(),
                    'metrics': metrics
                }, f, ensure_ascii=False)
                f.write('\n')
            
            self.logger.debug("Performance metrics logged successfully")
        except Exception as e:
            self.logger.error(f"Error logging performance metrics: {str(e)}")
            raise