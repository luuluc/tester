"""
Example usage of the centralized logger configuration.
This file demonstrates different ways to use the logger_config module.
"""

from config.logger_config import (
    setup_logger,
    setup_module_logger,
    get_logger,
    set_log_level,
    get_app_logger,
    get_ai_logger,
    get_feedback_logger,
    get_database_logger,
    get_api_logger
)
import logging


def example_basic_usage():
    """Example 1: Basic logger setup"""
    # Create a logger for your module
    logger = setup_logger(__name__)
    
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.debug("This is a debug message (won't show with default INFO level)")


def example_custom_configuration():
    """Example 2: Custom logger configuration"""
    # Setup logger with custom settings
    logger = setup_logger(
        name=__name__,
        log_dir="custom_logs",          # Custom log directory
        log_level=logging.DEBUG,         # Debug level
        console_output=True,             # Enable console output
        file_output=True,                # Enable file output
        log_format='[%(levelname)s] %(name)s: %(message)s',  # Custom format
        date_format='%H:%M:%S'           # Custom date format
    )
    
    logger.debug("This debug message will now show!")
    logger.info("Custom formatted log message")


def example_module_logger():
    """Example 3: Module-specific logger with custom file"""
    # Create a logger with a specific log file
    logger = setup_module_logger(
        module_name=__name__,
        custom_log_file="my_custom_module.log",
        log_level=logging.INFO
    )
    
    logger.info("This will be logged to both default and custom log files")


def example_predefined_loggers():
    """Example 4: Using predefined logger instances"""
    
    # Application logger
    app_logger = get_app_logger()
    app_logger.info("Application started")
    
    # AI operations logger
    ai_logger = get_ai_logger()
    ai_logger.info("Running AI model inference")
    
    # Feedback analysis logger
    feedback_logger = get_feedback_logger()
    feedback_logger.info("Analyzing user feedback")
    
    # Database operations logger
    db_logger = get_database_logger()
    db_logger.info("Database connection established")
    
    # API calls logger
    api_logger = get_api_logger()
    api_logger.info("Making API request to external service")


def example_get_or_create():
    """Example 5: Get existing logger or create new one"""
    # This will create a logger with defaults if it doesn't exist
    logger = get_logger(__name__)
    logger.info("Logger retrieved or created with defaults")


def example_change_log_level():
    """Example 6: Dynamically change log level"""
    logger = setup_logger(__name__)
    
    logger.info("Initial log level is INFO")
    logger.debug("This won't show initially")
    
    # Change log level to DEBUG
    set_log_level(logger, logging.DEBUG)
    
    logger.debug("Now debug messages will show!")
    logger.info("Still showing info messages")


def example_in_class():
    """Example 7: Using logger in a class"""
    
    class MyService:
        def __init__(self):
            # Setup logger for this class
            self.logger = setup_logger(f"{__name__}.{self.__class__.__name__}")
        
        def do_something(self):
            self.logger.info("Doing something important")
            try:
                # Your code here
                result = 42
                self.logger.debug(f"Result: {result}")
                return result
            except Exception as e:
                self.logger.error(f"Error occurred: {e}", exc_info=True)
                raise
    
    # Use the class
    service = MyService()
    service.do_something()


def example_console_only():
    """Example 8: Console-only logger (no file output)"""
    logger = setup_logger(
        name="console_logger",
        file_output=False,     # Disable file output
        console_output=True    # Only console output
    )
    
    logger.info("This will only appear in console, not in log files")


def example_file_only():
    """Example 9: File-only logger (no console output)"""
    logger = setup_logger(
        name="file_logger",
        file_output=True,      # Enable file output
        console_output=False   # Disable console output
    )
    
    logger.info("This will only appear in log files, not in console")


# Common usage pattern for most modules:
# Simply add these two lines at the top of your module:
# 
# from config.logger_config import setup_logger
# logger = setup_logger(__name__)
#
# Then use logger throughout your module:
# logger.info("Your message here")
# logger.warning("Warning message")
# logger.error("Error message", exc_info=True)


if __name__ == "__main__":
    print("Running logger examples...")
    print("=" * 60)
    
    print("\n1. Basic usage:")
    example_basic_usage()
    
    print("\n2. Custom configuration:")
    example_custom_configuration()
    
    print("\n3. Module logger with custom file:")
    example_module_logger()
    
    print("\n4. Predefined loggers:")
    example_predefined_loggers()
    
    print("\n5. Get or create logger:")
    example_get_or_create()
    
    print("\n6. Change log level:")
    example_change_log_level()
    
    print("\n7. Logger in class:")
    example_in_class()
    
    print("\n8. Console only:")
    example_console_only()
    
    print("\n9. File only:")
    example_file_only()
    
    print("\n" + "=" * 60)
    print("Examples completed! Check the logs/ directory for log files.")

