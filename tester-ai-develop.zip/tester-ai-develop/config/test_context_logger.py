"""
Test module for testing the ContextLogger functionality.
"""

import os
import pytest
from context_logger_config import setup_context_logger, ContextLogger

def test_context_logger_initialization():
    """Test initializing the context logger"""
    test_log_dir = "test_logs"
    logger = setup_context_logger(test_log_dir)
    
    # Verify logger creation
    assert isinstance(logger, ContextLogger)
    assert os.path.exists(test_log_dir)

    # Test logging context metrics
    section_info = {
        "title": "Test Section",
        "level": "Info",
        "path": "/test/path",
        "related_sections": ["section1", "section2"],
        "relatedFlows": ["flow1"],
        "processing_time": 1.5,
        "test_count": 10,
        "coverage_rate": 85.5,
        "duplication_rate": 5.0,
        "error_count": 0
    }
    
    logger.log_context_metrics(section_info)
    
    # Test logging test case
    test_case = {
        "name": "Test Case 1",
        "priority": "High",
        "steps": ["step1", "step2", "step3"],
        "related_flows": ["flow1", "flow2"]
    }
    
    logger.log_test_case_generation(test_case)
    
    # Test logging error
    error_info = {
        "message": "Test error message",
        "location": "test_module.py:123",
        "details": "Test error details"
    }
    
    logger.log_context_error(error_info)
    
    # Test logging warning
    warning_info = {
        "message": "Test warning message",
        "suggestion": "Try this instead"
    }
    
    logger.log_context_warning(warning_info)
    
    # Test logging performance metrics
    perf_metrics = {
        "processing_time": 2.5,
        "test_case_count": 15,
        "coverage": 90.0,
        "duplication_rate": 3.0
    }
    
    logger.log_performance_metrics(perf_metrics)
    
    # Verify that log files were created
    assert os.path.exists(os.path.join(test_log_dir, f"context_metrics_{logger.current_date}.csv"))
    assert os.path.exists(os.path.join(test_log_dir, f"context_errors_{logger.current_date}.log"))
    assert os.path.exists(os.path.join(test_log_dir, f"test_cases_{logger.current_date}.json"))
    assert os.path.exists(os.path.join(test_log_dir, f"performance_metrics_{logger.current_date}.json"))

if __name__ == "__main__":
    test_context_logger_initialization()
    print("Context logger tests completed successfully!")