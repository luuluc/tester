"""
Centralized Logger Configuration for the AI Agent Tester application.
Provides consistent logging setup across all modules.
"""

import logging
import os
from datetime import datetime
from typing import Optional


def setup_logger(
    name: str,
    log_dir: str = "logs",
    log_level: int = logging.INFO,
    console_output: bool = True,
    file_output: bool = True,
    log_format: Optional[str] = None,
    date_format: Optional[str] = None
) -> logging.Logger:
    """
    Setup and configure a logger with file and console handlers.
    
    Args:
        name: Logger name (usually __name__ from calling module)
        log_dir: Directory to store log files (default: "logs")
        log_level: Logging level (default: logging.INFO)
        console_output: Whether to output to console (default: True)
        file_output: Whether to output to file (default: True)
        log_format: Custom log format string (optional)
        date_format: Custom date format string (optional)
        
    Returns:
        Configured logger instance
        
    Example:
        >>> from config.logger_config import setup_logger
        >>> logger = setup_logger(__name__)
        >>> logger.info("This is a log message")
    """
    # Get or create logger
    logger = logging.getLogger(name)
    
    # Avoid adding duplicate handlers if logger already exists
    if logger.handlers:
        return logger
    
    logger.setLevel(log_level)
    
    # Default formats
    if log_format is None:
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    if date_format is None:
        date_format = '%Y-%m-%d %H:%M:%S'
    
    formatter = logging.Formatter(log_format, datefmt=date_format)
    
    # Console handler
    if console_output:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(log_level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    # File handler
    if file_output:
        try:
            # Create logs directory if it doesn't exist
            os.makedirs(log_dir, exist_ok=True)
            
            # Create log filename with current date
            log_filename = os.path.join(
                log_dir, 
                f"{name.replace('.', '_')}_{datetime.now().strftime('%Y%m%d')}.log"
            )
            
            file_handler = logging.FileHandler(log_filename, encoding='utf-8')
            file_handler.setLevel(log_level)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
            
        except Exception as e:
            # If file logging fails, just log to console
            logger.warning(f"Could not setup file logging: {e}")
    
    return logger


def setup_module_logger(
    module_name: str,
    custom_log_file: Optional[str] = None,
    **kwargs
) -> logging.Logger:
    """
    Setup a logger for a specific module with optional custom log file.
    
    Args:
        module_name: Name of the module (usually __name__)
        custom_log_file: Optional custom log filename (without path)
        **kwargs: Additional arguments to pass to setup_logger
        
    Returns:
        Configured logger instance
        
    Example:
        >>> logger = setup_module_logger(__name__, custom_log_file="feedback_analysis.log")
    """
    logger = setup_logger(module_name, **kwargs)
    
    # Add custom file handler if specified
    if custom_log_file:
        try:
            log_dir = kwargs.get('log_dir', 'logs')
            os.makedirs(log_dir, exist_ok=True)
            
            custom_file_path = os.path.join(log_dir, custom_log_file)
            
            # Create custom file handler
            custom_handler = logging.FileHandler(custom_file_path, encoding='utf-8')
            custom_handler.setLevel(kwargs.get('log_level', logging.INFO))
            
            log_format = kwargs.get('log_format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            date_format = kwargs.get('date_format', '%Y-%m-%d %H:%M:%S')
            formatter = logging.Formatter(log_format, datefmt=date_format)
            
            custom_handler.setFormatter(formatter)
            logger.addHandler(custom_handler)
            
        except Exception as e:
            logger.warning(f"Could not setup custom file handler: {e}")
    
    return logger


def get_logger(name: str) -> logging.Logger:
    """
    Get an existing logger or create a new one with default configuration.
    
    Args:
        name: Logger name (usually __name__)
        
    Returns:
        Logger instance
        
    Example:
        >>> from config.logger_config import get_logger
        >>> logger = get_logger(__name__)
    """
    logger = logging.getLogger(name)
    
    # If logger has no handlers, set it up with defaults
    if not logger.handlers:
        return setup_logger(name)
    
    return logger


def set_log_level(logger: logging.Logger, level: int):
    """
    Set log level for a logger and all its handlers.
    
    Args:
        logger: Logger instance
        level: Log level (e.g., logging.DEBUG, logging.INFO)
        
    Example:
        >>> set_log_level(logger, logging.DEBUG)
    """
    logger.setLevel(level)
    for handler in logger.handlers:
        handler.setLevel(level)


# Pre-configured logger instances for common use cases
def get_app_logger() -> logging.Logger:
    """Get logger for main application."""
    return setup_logger("app", custom_log_file="app.log")


def get_ai_logger() -> logging.Logger:
    """Get logger for AI modules."""
    return setup_logger("ai", custom_log_file="ai.log")


def get_feedback_logger() -> logging.Logger:
    """Get logger for feedback analysis."""
    return setup_module_logger(
        "ai.feedback_analyzer",
        custom_log_file=f"feedback_analysis_{datetime.now().strftime('%Y%m%d')}.log"
    )


def get_database_logger() -> logging.Logger:
    """Get logger for database operations."""
    return setup_logger("database", custom_log_file="database.log")


def get_api_logger() -> logging.Logger:
    """Get logger for API calls."""
    return setup_logger("api", custom_log_file="api.log")

