"""
Application configuration and styling for the Document Handler Streamlit app.
"""

import streamlit as st

def configure_page():
    """Configure Streamlit page settings."""
    st.set_page_config(
        page_title="DOCX Structure Extractor",
        page_icon="📄",
        layout="wide",
        initial_sidebar_state="collapsed"
    )

def load_custom_css():
    """Load custom CSS styles for the application."""
    st.markdown("""
    <style>
        .main-header {
            text-align: center;
            padding: 1rem 0;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .upload-section {
            background-color: #f8f9fa;
            padding: 1rem;
            border-radius: 8px;
            border: 2px dashed #dee2e6;
            margin-bottom: 0.5rem;
        }
        
        .structure-section {
            background-color: #fff;
            padding: 0.5rem;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            max-height: 85vh;
            overflow-y: auto;
        }
        
        /* Streaming response styling */
        .streaming-response {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem;
            border-radius: 8px;
            margin: 0.5rem 0;
            border-left: 4px solid #4CAF50;
            animation: pulse 2s infinite;
        }
        
        /* AI Response Area with Auto-Scroll */
        .ai-response-area {
            max-height: 80vh;
            overflow-y: auto;
            scroll-behavior: smooth;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }
        
        .ai-response-area::-webkit-scrollbar {
            width: 8px;
        }
        
        .ai-response-area::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        
        .ai-response-area::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        
        .ai-response-area::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        
        /* Auto-scroll animation for new content */
        .ai-response-content {
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(76, 175, 80, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(76, 175, 80, 0); }
            100% { box-shadow: 0 0 0 0 rgba(76, 175, 80, 0); }
        }
        
        .ai-response-box {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 0.8rem;
            margin: 0.5rem 0;
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
            font-size: 0.85rem;
            line-height: 1.4;
            max-height: 400px;
            overflow-y: auto;
            scroll-behavior: smooth;
        }
        
        .ai-response-streaming {
            background: #f8f9fa;
            border: 1px solid #4CAF50;
            border-radius: 6px;
            padding: 0.8rem;
            margin: 0.5rem 0;
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
            font-size: 0.85rem;
            line-height: 1.4;
            max-height: 400px;
            overflow-y: auto;
            scroll-behavior: smooth;
            animation: border-pulse 2s infinite;
        }
        
        @keyframes border-pulse {
            0% { border-color: #4CAF50; }
            50% { border-color: #81C784; }
            100% { border-color: #4CAF50; }
        }
        
        /* Expander styling for dropdown-like tree */
        .streamlit-expanderHeader {
            font-size: 0.9rem !important;
            padding: 0.4rem 0.8rem !important;
            border-radius: 4px !important;
            background-color: #f8f9fa !important;
            border: 1px solid #e9ecef !important;
            margin: 0.1rem 0 !important;
        }
        
        .streamlit-expanderHeader:hover {
            background-color: #e9ecef !important;
        }
        
        .streamlit-expanderContent {
            padding: 0.8rem !important;
            background-color: #ffffff !important;
            border: 1px solid #e9ecef !important;
            border-top: none !important;
            border-radius: 0 0 4px 4px !important;
            margin-bottom: 0.1rem !important;
        }
        
        /* Content styling */
        .content-area {
            background: #f8f9fa;
            padding: 0.5rem;
            border-radius: 6px;
            border-left: 3px solid #007bff;
            margin: 0.2rem 0;
            font-size: 0.9em;
        }
        
        .stats-card {
            background: linear-gradient(45deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.5rem;
            border-radius: 6px;
            text-align: center;
            margin: 0.2rem 0;
            font-size: 0.85em;
        }
        
        /* Streamlit specific overrides */
        .stExpander {
            margin: 0.1rem 0 !important;
        }
        
        .stExpander > div > div > div {
            padding: 0.6rem;
        }
        
        /* Hide streamlit default spacing - compact layout */
        .block-container {
            padding-top: 0.5rem !important;
            padding-bottom: 0.5rem !important;
        }
        
        .element-container {
            margin-bottom: 0.25rem !important;
        }
        
        /* Remove streamlit default spacing */
        .stMarkdown {
            margin-bottom: 0 !important;
        }
        
        .stButton > button {
            margin-top: 0.25rem;
            margin-bottom: 0.25rem;
        }
        
        /* AI response area compact styling */
        .ai-response-area {
            margin: 0;
            padding: 0;
        }
        
        .ai-response-area h3 {
            margin-top: 0;
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }
        
        /* Compact metrics */
        [data-testid="metric-container"] {
            background-color: transparent;
            border: none;
            padding: 0.2rem;
            margin: 0.1rem 0;
        }
        
        /* Text area styling */
        .stTextArea textarea {
            font-size: 0.85rem !important;
            line-height: 1.4 !important;
        }
        
        /* Collapsed upload section */
        .upload-collapsed {
            background-color: #f8f9fa;
            padding: 0.5rem;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            margin-bottom: 0.5rem;
        }
        
        /* Generation mode layout */
        .function-list-container {
            background-color: #ffffff;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 0.8rem;
            max-height: 75vh;
            overflow-y: auto;
            position: sticky;
            top: 1rem;
        }
        
        /* Generation mode layout - Larger AI response, tabbed right panel */
        .ai-generation-stream {
            background: #f8f9fa;
            padding: 0.5rem;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            max-height: 85vh;
            overflow-y: auto;
            flex: 2; /* Larger AI response area */
        }
        
        .live-logs-container {
            background: #fff;
            padding: 0.25rem;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            max-height: 75vh;
            overflow-y: auto;
            flex: 1;
            margin-left: 1rem;
            margin: 0;
        }
        
        /* Tabbed interface styling */
        .stTabs [data-baseweb="tab-list"] {
            gap: 2px;
        }
        
        .stTabs [data-baseweb="tab"] {
            height: 40px;
            padding: 0 12px;
            border-radius: 4px 4px 0 0;
            font-size: 0.9rem;
        }
        
        .stTabs [aria-selected="true"] {
            background-color: #007bff !important;
            color: white !important;
        }
        
        /* Tab content area with scrolling */
        .stTabs > div > div > div > div {
            max-height: 70vh;
            overflow-y: auto;
            padding: 0.5rem;
        }
            margin-left: 1rem;
        }
        
        .ai-response-center {
            background: white !important;
            color: black !important;
            border: 2px solid #007bff !important;
            border-radius: 8px !important;
            padding: 15px !important;
            margin: 0 !important; /* Remove margin for tighter layout */
            max-height: 75vh !important; /* Larger height for bigger display */
            overflow-y: auto !important;
            font-family: 'Segoe UI', sans-serif !important;
            line-height: 1.5 !important;
            box-shadow: 0 2px 4px rgba(0, 123, 255, 0.1) !important;
            width: 100% !important; /* Full width for larger display */
        }
        
        .ai-response-center::-webkit-scrollbar {
            width: 6px;
        }
        
        .ai-response-center::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }
        
        .ai-response-center::-webkit-scrollbar-thumb {
            background: #007bff;
            border-radius: 3px;
        }
        
        .ai-response-center::-webkit-scrollbar-thumb:hover {
            background: #0056b3;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Responsive layout for generation mode */
        .generation-layout {
            display: flex;
            flex-direction: row;
            gap: 1rem;
            width: 100%;
        }
        
        /* Function item styling */
        .function-item {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 0.6rem;
            margin: 0.3rem 0;
            transition: all 0.2s ease;
        }
        
        .function-item.processing {
            border-color: #ffc107;
            background: #fff3cd;
        }
        
        .function-item.completed {
            border-color: #28a745;
            background: #d4edda;
        }
        
        .function-item.skipped {
            border-color: #6c757d;
            background: #f8f9fa;
            opacity: 0.7;
        }
        
        .function-item.error {
            border-color: #dc3545;
            background: #f8d7da;
        }
        
        /* Auto scroll to bottom */
        .auto-scroll {
            scroll-behavior: smooth;
        }
        
        /* Processing indicator */
        .processing-indicator {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.8rem;
            border-radius: 8px;
            text-align: center;
            margin: 0.5rem 0;
            animation: pulse 2s infinite;
        }
        
        /* Ensure columns display in flex-row layout during generation */
        .block-container .element-container {
            width: 100% !important;
        }
        
        /* Generation mode specific overrides */
        .stColumns {
            display: flex !important;
            flex-direction: row !important;
            gap: 1rem !important;
            width: 100% !important;
        }
        
        .stColumns > div {
            flex: 1 !important;
            min-width: 0 !important;
        }
        
        .stColumns > div:first-child {
            flex: 1.5 !important; /* AI response area - larger */
        }
        
        .stColumns > div:last-child {
            flex: 1 !important; /* Logs area - smaller */
        }
        
        /* Make sure containers fill their flex space */
        .ai-generation-stream,
        .live-logs-container {
            height: 80vh !important;
            display: flex !important;
            flex-direction: column !important;
        }
    </style>
    """, unsafe_allow_html=True)

def initialize_session_state():
    """Initialize all session state variables."""
    if 'document_data' not in st.session_state:
        st.session_state.document_data = None
    
    if 'selected_node' not in st.session_state:
        st.session_state.selected_node = None
    
    if 'processing_status' not in st.session_state:
        st.session_state.processing_status = None
    
    if 'test_cases' not in st.session_state:
        st.session_state.test_cases = []
    
    if 'test_generation_status' not in st.session_state:
        st.session_state.test_generation_status = None
    
    if 'generation_progress' not in st.session_state:
        st.session_state.generation_progress = 0
    
    if 'function_list' not in st.session_state:
        st.session_state.function_list = []
    
    if 'current_processing_function' not in st.session_state:
        st.session_state.current_processing_function = ""
    
    if 'detailed_logs' not in st.session_state:
        st.session_state.detailed_logs = []
    
    if 'live_test_cases' not in st.session_state:
        st.session_state.live_test_cases = []
    
    if 'key_counter' not in st.session_state:
        st.session_state.key_counter = 0
