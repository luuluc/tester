"""
Database configuration and connection utilities.
"""

import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, MetaData
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import psycopg2
from psycopg2.extras import RealDictCursor
from typing import Optional

# Load environment variables
load_dotenv()

# Database configuration
DB_CONFIG = {
    'host': os.getenv('POSTGRES_HOST', '172.16.5.10'),
    'port': os.getenv('POSTGRES_PORT', '5432'),
    'user': os.getenv('POSTGRES_USER', 'postgres'),
    'password': os.getenv('POSTGRES_PASSWORD', '123456aA@'),
    'database': os.getenv('POSTGRES_DB', 'test-db')
}

# SQLAlchemy setup
DATABASE_URL = f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"

engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_database_url() -> str:
    """Get the database URL for SQLAlchemy."""
    return DATABASE_URL

def get_db_config() -> dict:
    """Get database configuration dictionary."""
    return DB_CONFIG.copy()

def create_connection():
    """Create a direct psycopg2 connection."""
    try:
        conn = psycopg2.connect(
            host=DB_CONFIG['host'],
            port=DB_CONFIG['port'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database'],
            cursor_factory=RealDictCursor
        )
        return conn
    except Exception as e:
        print(f"Error creating database connection: {str(e)}")
        return None

def test_connection() -> bool:
    """Test database connection."""
    try:
        conn = create_connection()
        if conn:
            conn.close()
            return True
        return False
    except Exception as e:
        print(f"Database connection test failed: {str(e)}")
        return False

def create_database_if_not_exists():
    """Create the database if it doesn't exist."""
    try:
        # Connect to postgres database to create our target database
        temp_config = DB_CONFIG.copy()
        temp_config['database'] = 'postgres'
        
        conn = psycopg2.connect(
            host=temp_config['host'],
            port=temp_config['port'],
            user=temp_config['user'],
            password=temp_config['password'],
            database=temp_config['database']
        )
        conn.autocommit = True
        
        cursor = conn.cursor()
        
        # Check if database exists
        cursor.execute("SELECT 1 FROM pg_catalog.pg_database WHERE datname = %s", (DB_CONFIG['database'],))
        exists = cursor.fetchone()
        
        if not exists:
            cursor.execute(f'CREATE DATABASE "{DB_CONFIG["database"]}"')
            print(f"Database '{DB_CONFIG['database']}' created successfully")
        else:
            print(f"Database '{DB_CONFIG['database']}' already exists")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"Error creating database: {str(e)}")
        return False
