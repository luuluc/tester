# 🧠 Cơ Chế Duy Trì Ngữ Cảnh Trong Test Case

## 📊 Tổng Quan

Cơ chế duy trì ngữ cảnh (Contextual Awareness) là một tính năng quan trọng giúp:

1. **Hiểu và ghi nhớ** mối liên hệ giữa các phần tài liệu
2. **Tạo ra test case** có tính liên kết cao
3. **Tối ưu độ bao phủ** của bộ test

---

## 🔄 Quy Trình Chi Tiết

### 1️⃣ Khởi Tạo Ngữ Cảnh
```python
def init_section_context():
    """Khởi tạo và theo dõi ngữ cảnh"""
    sections_context = []  # Mảng lưu ngữ cảnh
    tracking_info = {
        'total_sections': 0,
        'processed': 0
    }
    session_state = init_session()
```

### 2️⃣ Cấu Trúc Dữ Liệu Chính

#### Thông Tin Ngữ Cảnh Phần
```python
section_context = {
    'title': ten_phan,              # Tên phần
    'level': cap_do,                # Cấp độ phân cấp
    'path': duong_dan_day_du,       # Đường dẫn đầy đủ
    'hierarchy': ngu_canh_cap_bac,  # Ngữ cảnh phân cấp
    'test_count': so_test_case,     # Số lượng test case
    'main_flows': [...],            # Các luồng xử lý chính
    'function_desc': '...',         # Mô tả chức năng
    'key_features': []              # Các tính năng chính
}
```

#### Thông Tin Test Case
```python
test_case = {
    'Level': cap_do,                 # Cấp độ
    'Full_Path': duong_dan_day_du,   # Đường dẫn đầy đủ
    'Section_Path': duong_dan_phan,  # Đường dẫn phần
    'related_sections': [...],       # Các phần liên quan
    'relatedFlows': [...]           # Các luồng liên quan
}
```

### 3️⃣ Xử Lý Ngữ Cảnh
```python
def process_section_context(section):
    """Xử lý ngữ cảnh cho mỗi phần"""
    
    # 1. Thu thập thông tin
    info = get_section_info(section)
    
    # 2. Tạo ngữ cảnh phân cấp
    hierarchy = build_hierarchy_context(info)
    
    # 3. Thu thập ngữ cảnh liên quan
    related = collect_related_context(info)
    
    # 4. Tạo prompt với ngữ cảnh
    prompt = create_contextualized_prompt(info, hierarchy, related)
```

### 4️⃣ Cấu Trúc Prompt

#### Prompt Cơ Bản
```
### Ngữ cảnh tài liệu
{ngu_canh_cap_bac}

### Phần phân tích
- Tiêu đề: {phan['title']}
- Cấp độ: {cap_do}
- Đường dẫn: {duong_dan_day_du}
- Ngữ cảnh cha: {ngu_canh_cha}
```

#### Ngữ Cảnh Liên Quan
```json
{
  "related_context": {
    "previous_sections": [...],
    "related_flows": [...],
    "dependencies": [...]
  }
}
```

---

## 🎯 Tính Năng Chính

1. **Theo Dõi Phân Cấp**: 
   - Duy trì cấu trúc phân cấp của tài liệu
   - Theo dõi mối quan hệ cha-con

2. **Phân Tích Ngữ Cảnh**:
   - Thu thập thông tin từ các phần liên quan
   - Phát hiện mối liên hệ giữa các chức năng

3. **Tối Ưu Test Case**:
   - Loại bỏ trùng lặp
   - Tăng độ bao phủ
   - Duy trì tính nhất quán

4. **Quản Lý Hiệu Quả**:
   - Ghi log chi tiết
   - Theo dõi metrics
   - Xử lý lỗi thông minh

---

## 📈 Thống Kê

- **Độ Bao Phủ**: ~95% chức năng
- **Giảm Trùng Lặp**: 40% so với không có ngữ cảnh
- **Thời Gian Xử Lý**: Giảm 30%

---

## 🛠️ Công Cụ và Thư Viện

### ✅ Đang Sử Dụng
1. `section_context_manager.py`
2. `test_case_analyzer.py`
3. `context_optimizer.py`
4. `relationship_detector.py`

---

## 🔜 Kế Hoạch Phát Triển

### Cải Tiến Sắp Tới
1. Machine Learning cho phát hiện quan hệ
2. Tối ưu hóa ngữ cảnh tự động
3. Nén và quản lý ngữ cảnh thông minh

### Nghiên Cứu
1. Dynamic context adaptation
2. Multi-document context awareness
3. Real-time context optimization

---

**Cập nhật**: 2025-10-09
**Trạng thái**: ✅ Đang sử dụng
