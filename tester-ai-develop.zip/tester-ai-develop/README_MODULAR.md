# Document Handler - Modular Structure

This project has been refactored from a single large file into a modular structure for better maintainability and organization.

## Project Structure

```
document-handler/
├── streamlit_app_new.py       # New main application file
├── streamlit_app.py           # Original large file (kept for reference)
├── config/
│   ├── __init__.py
│   └── app_config.py          # Streamlit configuration and CSS styles
├── utils/
│   ├── __init__.py
│   └── helpers.py             # Utility functions (key generation, logging)
├── test_case/
│   ├── __init__.py
│   └── analyzer.py            # Test case analysis and generation logic
├── ai/
│   ├── __init__.py
│   └── ollama_client.py       # AI integration with Ollama API
├── data/
│   ├── __init__.py
│   └── processor.py           # Data processing and Excel export
├── ui/
│   ├── __init__.py
│   └── components.py          # UI components and displays
└── document_processer.py      # External dependency (unchanged)
```

## Module Responsibilities

### 1. `config/app_config.py`
- Streamlit page configuration
- Custom CSS styles
- Session state initialization

### 2. `utils/helpers.py`
- Unique key generation for Streamlit components
- Detailed logging functionality
- Function status updates

### 3. `test_case/analyzer.py`
- Test case testability analysis
- Function list extraction
- Test case response parsing
- Live test case table creation

### 4. `ai/ollama_client.py`
- Ollama API integration
- Streaming AI responses
- Prompt generation for test cases

### 5. `data/processor.py`
- Test case generation workflow
- Excel file creation
- Data processing pipelines

### 6. `ui/components.py`
- Tree structure rendering
- Live log displays
- Function status displays
- Test case summary and detailed displays

### 7. `streamlit_app_new.py`
- Main application orchestration
- UI layout and navigation
- Integration of all modules

## Running the Application

### Option 1: Use the new modular version (recommended)
```bash
streamlit run streamlit_app_new.py
```

### Option 2: Use the original single file
```bash
streamlit run streamlit_app.py
```

## Benefits of the New Structure

1. **Better Organization**: Related functionality is grouped together
2. **Easier Maintenance**: Each module has a specific responsibility
3. **Code Reusability**: Functions can be imported and reused
4. **Testing**: Individual modules can be tested separately
5. **Readability**: Smaller files are easier to understand
6. **Collaboration**: Multiple developers can work on different modules

## Migration Notes

- The original `streamlit_app.py` is preserved for reference
- All functionality has been migrated to the new modular structure
- No external dependencies have changed
- The user interface and features remain identical

## Future Improvements

With this modular structure, you can easily:
- Add unit tests for individual modules
- Implement different AI providers
- Add new UI components
- Extend data export formats
- Add configuration files for different environments
