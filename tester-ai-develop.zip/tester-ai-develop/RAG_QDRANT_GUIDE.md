# 🚀 RAG System với Qdrant - Semantic Search cho Feedback

## 📋 Tổng Quan

Hệ thống RAG (Retrieval-Augmented Generation) sử dụng **Qdrant** vector database và **semantic embeddings** để tìm kiếm lessons learned theo **ngữ nghĩa**, không chỉ từ khóa.

### Kiến Trúc Mới

```
User Submit Feedback
       ↓
AI Analysis (feedback_analyzer.py)
   ├─> Domain: authentication
   ├─> Lesson: "Khi test login..."  
   ├─> Score: 0.8
   └─> Tags: ["login", "validation"]
       ↓
Generate Embedding (multilingual-e5-small)
   └─> Vector [0.123, -0.456, ...] (384 dims)
       ↓
Store in Qdrant @ http://172.16.5.10:6333
   ├─> Vector: for semantic search
   └─> Payload: metadata (domain, score, tags, text)
       ↓
When Generate Test Case
   ├─> Detect Domain from Section
   ├─> Build Query: "{title} {content_preview}"
   ├─> Generate Query Embedding
   └─> Semantic Search in Qdrant
       └─> Retrieve Top-K Similar Lessons
           └─> Inject into System Prompt
               ↓
Better Test Cases 🎯
```

---

## 🔧 Setup

### 1. Install Dependencies

```bash
pip install qdrant-client sentence-transformers
```

Dependencies trong `requirements.txt`:
- `qdrant-client>=1.7.0` - Qdrant Python client
- `sentence-transformers>=2.2.0` - Embedding models

### 2. Qdrant Server

**Configured**: `http://172.16.5.10:6333`

Kiểm tra connection:
```bash
curl http://172.16.5.10:6333/collections
```

### 3. Initialize Service

```bash
python scripts/init_qdrant_service.py
```

Output expected:
```
✅ Embedding service loaded
   Model: intfloat/multilingual-e5-small
   Dimension: 384
✅ Connected to Qdrant
   Collection: feedback_lessons
✅ All tests passed!
```

---

## 🧠 Embedding Model

### Model: `intfloat/multilingual-e5-small`

**Lý do chọn:**
- ✅ **Multilingual**: Support tốt cả tiếng Việt và tiếng Anh
- ✅ **Small & Fast**: 384 dimensions, inference nhanh
- ✅ **State-of-the-art**: Model mới nhất (2023) từ Microsoft
- ✅ **Proven**: Top performance trên MTEB benchmark

**Alternatives:**
- `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` - Older, still good
- `all-MiniLM-L6-v2` - English only, faster
- `intfloat/multilingual-e5-base` - 768d, better quality, slower

### Embedding Process

```python
from utils.embedding_service import get_embedding_service

embedding_svc = get_embedding_service()

# Text → Vector
text = "Khi test đăng nhập cần kiểm tra email không hợp lệ"
vector = embedding_svc.embed_text(text)
# → [0.123, -0.456, 0.789, ...] (384 numbers)
```

**E5 Model Prefix:**
Với E5 models, text tự động được prefix `"query: "` để improve performance.

---

## 🗄️ Qdrant Storage

### Collection: `feedback_lessons`

**Vector Config:**
- **Size**: 384 dimensions (from embedding model)
- **Distance**: Cosine similarity (best for semantic search)
- **Index**: IVF for fast search

**Payload Schema (Metadata):**

```json
{
  "feedback_text": "Original user feedback",
  "processed_feedback": "AI-extracted lesson",
  "lessons_learned": "Same as processed_feedback",
  "domain": "authentication",
  "relevance_score": 0.85,
  "tags": ["login", "email_validation"],
  "category": "learning",
  "priority": 1,
  "is_active": true,
  "created_at": "2025-10-05T10:30:00",
  "updated_at": "2025-10-05T10:30:00"
}
```

**Indexes Created:**
- `domain` (keyword) - Fast domain filtering
- `relevance_score` (float) - Score range filtering
- `is_active` (bool) - Active/inactive filter

---

## 🔍 Semantic Search

### How It Works

1. **User submits query** (e.g., section title + content preview)
2. **Generate query embedding** using same model
3. **Qdrant finds similar vectors** using cosine similarity
4. **Filter by domain + score** for relevance
5. **Return Top-K lessons** sorted by similarity

### Example

```python
from utils.qdrant_feedback_service import get_qdrant_feedback_service

qdrant_svc = get_qdrant_feedback_service()

# Semantic search
lessons = qdrant_svc.get_relevant_lessons_semantic(
    query_text="kiểm tra email đúng định dạng khi người dùng nhập",
    domain="authentication",
    limit=5,
    min_score=0.4,  # Metadata filter: relevance_score >= 0.4
    relevance_threshold=0.5  # Vector similarity >= 0.5
)

# Results
for lesson in lessons:
    print(f"Similarity: {lesson['similarity_score']:.3f}")
    print(f"Lesson: {lesson['processed_feedback']}")
    print(f"Domain: {lesson['domain']}, Score: {lesson['relevance_score']}")
```

**Tìm thấy ngay cả khi dùng từ đồng nghĩa:**
- Query: "kiểm tra email **đúng định dạng**"
- Finds: "Cần validation email **hợp lệ**"
- Why: Semantic similarity, không cần exact match!

---

## 🎯 Integration với Test Case Generation

### 1. Detect Domain

```python
# In ai/ollama_client.py
domain = detect_domain_from_section(
    section_title="Chức năng đăng nhập hệ thống",
    content_preview="User nhập email và password..."
)
# → "authentication"
```

### 2. Build Query

```python
query_text = f"{section_title} {content_preview[:200]}"
# → "Chức năng đăng nhập hệ thống User nhập email và password..."
```

### 3. Retrieve Relevant Lessons

```python
lessons_summary = qdrant_svc.get_lessons_by_domain_summary(
    domain=detected_domain,
    query_text=query_text,  # Semantic search
    limit=5
)
```

### 4. Inject into Prompt

```
=== 🎓 KINH NGHIỆM ĐÃ HỌC CHO DOMAIN: AUTHENTICATION ===
1. [0.9⭐ | sim:0.87] Khi test đăng nhập, phải kiểm tra email validation
2. [0.8⭐ | sim:0.82] Test case cần cover cả trường hợp password sai format
3. [0.7⭐ | sim:0.78] Đảm bảo test session timeout sau khi login
...
```

---

## 📊 API Reference

### QdrantFeedbackService

#### `add_feedback()`
```python
point_id = qdrant_svc.add_feedback(
    feedback_text="User feedback text",
    processed_feedback="Lesson learned by AI",
    domain="authentication",
    relevance_score=0.85,
    tags=["login", "validation"],
    category="learning",
    priority=1,
    metadata={"custom_field": "value"}
)
# Returns: UUID string
```

**Auto-generates embedding** for `processed_feedback` and stores in Qdrant.

#### `get_relevant_lessons_semantic()`
```python
lessons = qdrant_svc.get_relevant_lessons_semantic(
    query_text="User query or section description",
    domain="authentication",  # Optional filter
    limit=10,
    min_score=0.4,  # Min relevance_score (metadata)
    relevance_threshold=0.5  # Min cosine similarity (vector)
)
```

**Returns:** List of dicts with:
- `id` - Point ID
- `similarity_score` - Cosine similarity (0-1)
- `processed_feedback` - Lesson text
- `domain`, `relevance_score`, `tags`, etc. - All metadata

#### `get_lessons_by_domain_summary()`
```python
summary = qdrant_svc.get_lessons_by_domain_summary(
    domain="payment",
    query_text="credit card validation",  # Optional for semantic ranking
    limit=5
)
```

**Returns:** Formatted string for prompt injection.

#### `get_all_active_feedback()`
```python
all_lessons = qdrant_svc.get_all_active_feedback()
# Returns: List of all active feedback with metadata
```

#### `delete_feedback()` / `deactivate_feedback()`
```python
# Hard delete
qdrant_svc.delete_feedback(point_id)

# Soft delete (set is_active=False)
qdrant_svc.deactivate_feedback(point_id)
```

---

## 🚀 Usage Flow

### 1. User Submits Feedback (UI)

```python
# In streamlit_app.py
feedback_text = st.text_area("Your feedback")

if st.button("Submit"):
    from ai.feedback_analyzer import feedback_analyzer
    
    result = feedback_analyzer.process_and_store_feedback(
        feedback_text=feedback_text,
        ai_config={...},
        metadata={'source': 'ui'}
    )
```

### 2. AI Analysis & Storage

```python
# In ai/feedback_analyzer.py
analysis = self.analyze_feedback(new_feedback, ai_config)
# → {
#     "lesson": "When testing login...",
#     "domain": "authentication",
#     "score": 0.8,
#     "tags": ["login", "validation"]
# }

# Store in Qdrant (auto-embedding)
qdrant_service.add_feedback(
    feedback_text=feedback_text,
    processed_feedback=analysis['lesson'],
    domain=analysis['domain'],
    relevance_score=analysis['score'],
    tags=analysis['tags']
)
```

### 3. Retrieval During Test Case Generation

```python
# In ai/ollama_client.py
def generate_hierarchical_test_case_prompt(section, ...):
    # ...
    
    # Get relevant lessons via semantic search
    feedback_enhancement = get_feedback_enhancement(
        section_title=section['title'],
        content_preview=all_content_text[:500]
    )
    
    if feedback_enhancement:
        prompt += feedback_enhancement
    
    # Continue with prompt...
```

---

## 🎓 Benefits vs Keyword Search

| Aspect | Keyword Search | Semantic Search (RAG) |
|--------|---------------|----------------------|
| **Match Type** | Exact text match | Meaning-based |
| **Synonyms** | ❌ Missed | ✅ Found |
| **Language** | One language | Multilingual |
| **Relevance** | Boolean (match/no match) | Scored (0-1) |
| **Speed** | Fast for exact | Fast with vector index |
| **Quality** | Low recall | High recall + precision |

### Example: Synonyms

**Query**: "kiểm tra email đúng định dạng"

**Keyword Search** finds:
- ✓ "kiểm tra email đúng định dạng" (exact match)
- ✗ "validation email hợp lệ" (missed - synonyms)
- ✗ "verify email format" (missed - English)

**Semantic Search** finds:
- ✓ "kiểm tra email đúng định dạng" (sim=0.95)
- ✓ "validation email hợp lệ" (sim=0.87)
- ✓ "verify email format" (sim=0.82)
- ✓ "đảm bảo email có @ và domain" (sim=0.76)

---

## 🐛 Troubleshooting

### Issue: "Failed to connect to Qdrant"

**Check:**
```bash
curl http://172.16.5.10:6333/health
```

**Expected**: `{"status":"ok"}`

### Issue: "Embedding model download slow"

**Why**: First time downloads ~130MB model from HuggingFace

**Solution**: 
- Wait for download to complete
- Model is cached in `~/.cache/huggingface/`
- Subsequent runs are instant

### Issue: "No lessons found"

**Debug:**
```python
# Check total lessons in Qdrant
stats = qdrant_svc.get_feedback_stats()
print(f"Total lessons: {stats['total']}")

# Check if embeddings are generated
lessons = qdrant_svc.get_all_active_feedback()
for lesson in lessons[:1]:
    print(f"Has processed_feedback: {bool(lesson.get('processed_feedback'))}")
```

### Issue: "Semantic search returns irrelevant results"

**Tune parameters:**
```python
lessons = qdrant_svc.get_relevant_lessons_semantic(
    query_text="...",
    relevance_threshold=0.7,  # Increase from 0.5 → stricter
    min_score=0.6  # Increase metadata score filter
)
```

---

## 📈 Performance

### Embedding Generation
- **Speed**: ~50-100 texts/sec on CPU
- **Latency**: ~10-20ms per text on CPU
- **GPU**: 10x faster if available

### Qdrant Search
- **Speed**: <10ms for search in 100K vectors
- **Scalability**: Millions of vectors with IVF index
- **Memory**: ~1.5KB per vector (384 dims)

### Overall
- **Add feedback**: ~30-50ms (embedding + insert)
- **Search**: ~20-30ms (embed query + search + filter)
- **Total overhead**: <100ms per test case generation

---

## 🔧 Configuration

### Change Embedding Model

Edit `utils/embedding_service.py`:

```python
def get_embedding_service(model_name: str = "YOUR_MODEL_HERE"):
    ...
```

**Popular choices:**
- `intfloat/multilingual-e5-small` (384d, multilingual)
- `intfloat/multilingual-e5-base` (768d, better, slower)
- `all-MiniLM-L6-v2` (384d, English only, fastest)

### Change Qdrant URL

Edit `utils/qdrant_feedback_service.py`:

```python
def __init__(self, qdrant_url: str = "http://YOUR_IP:6333"):
    ...
```

Or pass when initializing:
```python
qdrant_svc = QdrantFeedbackService(qdrant_url="http://localhost:6333")
```

### Adjust Search Parameters

```python
# In ai/ollama_client.py
domain_lessons = qdrant_service.get_lessons_by_domain_summary(
    domain=detected_domain,
    query_text=query_text,
    limit=10  # Get more lessons
)

# Or directly
lessons = qdrant_svc.get_relevant_lessons_semantic(
    query_text=query,
    limit=20,
    min_score=0.3,  # Lower threshold
    relevance_threshold=0.4  # Lower similarity threshold
)
```

---

## 📚 References

- **Qdrant Docs**: https://qdrant.tech/documentation/
- **Sentence Transformers**: https://www.sbert.net/
- **E5 Model Paper**: https://arxiv.org/abs/2212.03533
- **MTEB Leaderboard**: https://huggingface.co/spaces/mteb/leaderboard

---

## ✅ Migration Checklist

- [x] Install `qdrant-client` and `sentence-transformers`
- [x] Create `utils/embedding_service.py`
- [x] Create `utils/qdrant_feedback_service.py`
- [x] Update `ai/feedback_analyzer.py` to use Qdrant
- [x] Update `ai/ollama_client.py` for semantic retrieval
- [x] Create init script `scripts/init_qdrant_service.py`
- [x] Test connection and embedding generation
- [ ] Submit first feedback through UI
- [ ] Verify feedback stored in Qdrant
- [ ] Generate test case and verify lessons injected
- [ ] Monitor search relevance and tune parameters

---

🎉 **RAG System with Qdrant is READY!**

Semantic search will find relevant lessons by meaning, handling synonyms and multilingual queries automatically!
