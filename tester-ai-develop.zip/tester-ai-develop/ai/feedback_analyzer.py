"""
AI Feedback Analyzer for processing and categorizing user feedback.
"""

import json
import requests
import logging
from datetime import datetime
from typing import Dict, List, Optional
from utils.qdrant_feedback_service import get_qdrant_feedback_service

# Initialize Qdrant service
qdrant_service = get_qdrant_feedback_service()

# Setup detailed logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Create file handler for feedback analysis logs
log_filename = f"logs/feedback_analysis_{datetime.now().strftime('%Y%m%d')}.log"
try:
    import os
    os.makedirs("logs", exist_ok=True)
    file_handler = logging.FileHandler(log_filename, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    
    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    # Add handlers
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
except Exception as e:
    print(f"Warning: Could not setup file logging: {e}")

class FeedbackAnalyzer:
    def __init__(self):
        """Initialize feedback analyzer."""
        self.categories = [
            "format",      # Formatting issues
            "content",     # Content quality issues  
            "structure",   # Test case structure
            "coverage",    # Test coverage issues
            "clarity",     # Clarity and readability
            "accuracy",    # Accuracy of generated tests
            "general"      # General feedback
        ]
    
    def analyze_feedback(self, new_feedback: str, ai_config: Dict) -> Dict:
        """
        Analyze new feedback with AI and existing feedback context.
        
        Args:
            new_feedback: New user feedback text
            ai_config: AI configuration dict containing provider, api_url, model_name, api_key
            
        Returns:
            Dict with analysis results
        """
        logger.info("="*80)
        logger.info("🚀 BẮT ĐẦU PHÂN TÍCH FEEDBACK MỚI")
        logger.info("="*80)
        logger.info(f"📝 Feedback từ user:\n{new_feedback}\n")
        
        # STEP 1: Detect domain and optimize query from user feedback
        logger.info("🔍 Step 1: Analyzing feedback to detect domain and optimize search query...")
        try:
            feedback_analysis = self._analyze_feedback_for_search(new_feedback, ai_config)
            detected_domains = feedback_analysis.get('domains', ['general'])
            optimized_query = feedback_analysis.get('optimized_query', new_feedback)
            key_concepts = feedback_analysis.get('key_concepts', [])
            
            logger.info(f"📍 Detected domains: {detected_domains}")
            logger.info(f"🔑 Key concepts: {key_concepts}")
            logger.info(f"🎯 Optimized query: {optimized_query[:100]}...")
            
        except Exception as e:
            logger.warning(f"⚠️ Could not analyze feedback for search: {e}, using raw feedback")
            detected_domains = ['general']
            optimized_query = new_feedback
            key_concepts = []
        
        # STEP 2: Search RELEVANT existing lessons using optimized query
        logger.info("🔍 Step 2: Searching for similar existing lessons...")
        try:
            similar_lessons = qdrant_service.get_relevant_lessons_semantic(
                query_text=optimized_query,  # Use optimized query instead of raw feedback
                domain=None,  # No domain filter - pure semantic search
                limit=15,  # Limit to top 15 most similar
                min_score=0.0,  # Include all quality levels
                relevance_threshold=0.6  # Only moderately similar or higher
            )
            
            # Filter to prioritize lessons from detected domains
            if detected_domains and detected_domains != ['general']:
                # Separate into matching and non-matching domains
                matching_lessons = [l for l in similar_lessons if l.get('domain') in detected_domains]
                other_lessons = [l for l in similar_lessons if l.get('domain') not in detected_domains]
                
                # Combine: matching first, then others
                similar_lessons = matching_lessons + other_lessons
                logger.info(f"📚 Found {len(matching_lessons)} lessons matching detected domains, {len(other_lessons)} from other domains")
            else:
                logger.info(f"📚 Found {len(similar_lessons)} similar lessons (domain: general)")
            
            if similar_lessons:
                logger.info(f"🔍 Top 5 most similar existing lessons:")
                for i, fb in enumerate(similar_lessons[:5], 1):
                    learned = fb.get('processed_feedback', '')[:100]
                    similarity = fb.get('similarity_score', 0)
                    fb_domain = fb.get('domain', 'unknown')
                    match_indicator = "🎯" if fb_domain in detected_domains else ""
                    logger.info(f"  {i}. {match_indicator}[sim:{similarity:.2f}|{fb_domain}] {learned}...")
            
            # Use similar lessons as context instead of all
            existing_feedback = similar_lessons[:10]  # Limit to top 10 for prompt
            
        except Exception as e:
            logger.warning(f"⚠️ Could not search similar lessons: {e}, using empty context")
            existing_feedback = []
        
        # Create analysis prompt
        analysis_prompt = self._create_analysis_prompt(new_feedback, existing_feedback)
        logger.info(f"\n📤 Prompt gửi đến AI:\n{analysis_prompt}\n")
        
        try:
            # Call AI API with new config format
            logger.info(f"🤖 Đang gọi AI API ({ai_config.get('provider', 'Unknown')}/{ai_config.get('model_name', 'Unknown')})...")
            response = self._call_ai_api(analysis_prompt, ai_config)
            
            if response:
                logger.info(f"✅ Nhận được response từ AI")
                logger.info(f"📥 AI Response (RAW):\n{response}\n")
                
                # Parse AI response
                analysis_result = self._parse_ai_response(response)
                logger.info(f"🔄 Kết quả sau khi parse:")
                logger.info(f"  - Has Learning: {analysis_result.get('has_learning', False)}")
                logger.info(f"  - Should Update: {analysis_result.get('should_update', False)}")
                logger.info(f"  - Learning Insight: {analysis_result.get('learning_insight', 'N/A')}\n")
                
                return analysis_result
            else:
                logger.warning("⚠️ Không nhận được response từ AI, sử dụng fallback analysis")
                # Fallback analysis
                return self._fallback_analysis(new_feedback)
                
        except Exception as e:
            logger.error(f"❌ Lỗi trong quá trình phân tích AI: {str(e)}", exc_info=True)
            return self._fallback_analysis(new_feedback)
    
    def _analyze_feedback_for_search(self, feedback_text: str, ai_config: Dict) -> Dict:
        """
        Analyze user feedback to extract:
        1. Domains (which areas this feedback relates to)
        2. Key concepts (main topics)
        3. Optimized query (better query for searching existing lessons)
        
        This helps find more relevant existing lessons for deduplication.
        
        Args:
            feedback_text: User feedback text
            ai_config: AI configuration
            
        Returns:
            Dict with domains, key_concepts, optimized_query
        """
        prompt = f"""Phân tích feedback sau để chuẩn bị tìm kiếm lessons liên quan:

**Feedback:**
"{feedback_text}"

**NHIỆM VỤ:**
1. Xác định 1-3 DOMAINS liên quan (authentication, authorization, payment, file_upload, file_download, data_validation, form_submission, api_integration, database, security, performance, ui_interaction, notification, reporting, workflow, general)

2. Trích xuất KEY CONCEPTS chính (3-5 từ khóa quan trọng nhất)

3. Tạo OPTIMIZED QUERY để tìm kiếm lessons tương tự (viết lại ngắn gọn, focus vào vấn đề chính)

**VÍ DỤ:**
Input: "Test case đăng nhập thiếu kiểm tra email không hợp lệ, cần thêm validation cho format email và domain"
Output:
```json
{{
  "domains": ["authentication", "data_validation"],
  "key_concepts": ["email validation", "login", "format check", "domain verification"],
  "optimized_query": "kiểm tra validation email format khi đăng nhập"
}}
```

**YÊU CẦU:**
- Trả về JSON object thuần (không markdown fence)
- domains: array of strings
- key_concepts: array of strings
- optimized_query: string (ngắn gọn, focus)

**OUTPUT (JSON only):**"""

        try:
            response = self._call_ai_api(prompt, ai_config)
            
            if response:
                # Parse JSON
                content_clean = response.strip()
                
                # Remove markdown fences if present
                if content_clean.startswith('```'):
                    content_clean = content_clean.split('\n', 1)[1] if '\n' in content_clean else content_clean[3:]
                if content_clean.endswith('```'):
                    content_clean = content_clean.rsplit('\n', 1)[0] if '\n' in content_clean else content_clean[:-3]
                content_clean = content_clean.strip()
                
                result = json.loads(content_clean)
                
                return {
                    'domains': result.get('domains', ['general']),
                    'key_concepts': result.get('key_concepts', []),
                    'optimized_query': result.get('optimized_query', feedback_text)
                }
            else:
                # Fallback
                return {
                    'domains': ['general'],
                    'key_concepts': [],
                    'optimized_query': feedback_text
                }
                
        except Exception as e:
            logger.warning(f"⚠️ Error analyzing feedback for search: {e}")
            return {
                'domains': ['general'],
                'key_concepts': [],
                'optimized_query': feedback_text
            }
    
    def _create_analysis_prompt(self, new_feedback: str, existing_feedback: List[Dict]) -> str:
        """Create prompt for AI analysis with domain classification and scoring."""
        
        # Summarize existing learned experiences (now with similarity scores)
        existing_summary = ""
        if existing_feedback:
            existing_summary = "\n=== KINH NGHIỆM TƯƠNG TỰ ĐÃ CÓ (Sorted by Similarity) ===\n"
            for i, feedback in enumerate(existing_feedback[:10], 1):  # Top 10 most similar
                # Get learning insights and similarity
                learned_experience = feedback.get('processed_feedback', '')
                domain = feedback.get('domain', 'unknown')
                score = feedback.get('relevance_score', 0.5)
                similarity = feedback.get('similarity_score', 0)  # Semantic similarity
                
                if learned_experience and learned_experience != feedback.get('feedback_text', ''):
                    # Show up to 200 chars of each learned experience
                    learned_display = learned_experience[:200] + "..." if len(learned_experience) > 200 else learned_experience
                    
                    # Display with similarity score for AI to understand relevance
                    if similarity > 0:
                        existing_summary += f"{i}. [sim:{similarity:.2f}|{domain}|{score:.1f}★] {learned_display}\n"
                    else:
                        existing_summary += f"{i}. [{domain}|{score:.1f}★] {learned_display}\n"
        
        prompt = f"""
Bạn là AI assistant giúp phân tích feedback để xây dựng knowledge base cải thiện test case generation.

## Kinh nghiệm tương tự đã có (sorted by similarity, format: [sim:X.XX|domain|score★]):
{existing_summary if existing_summary else "(Không tìm thấy kinh nghiệm tương tự)"}

**Chú thích:**
- sim:X.XX = Độ tương tự semantic (0.0-1.0). Cao = rất giống với feedback mới
- Nếu sim >= 0.85: Có thể là DUPLICATE (cùng ý)
- Nếu sim 0.70-0.84: Liên quan nhưng có thể có góc nhìn mới
- Nếu sim < 0.70: Khác biệt, nhiều khả năng là insight mới

## Feedback mới từ user:
"{new_feedback}"

## NHIỆM VỤ CỦA BẠN:

**Bước 1: Kiểm tra duplicate**
- So sánh feedback mới với các kinh nghiệm có similarity cao (>= 0.80)
- Nếu feedback mới chỉ NHẮC LẠI nội dung đã có → SKIP
- Nếu feedback mới có GÓC NHÌN MỚI hoặc THÔNG TIN BỔ SUNG → ACCEPT

**Bước 2: Đánh giá giá trị**
- Feedback có insight cụ thể, hành động được không?
- Có đủ rõ ràng để trích xuất lesson không?

**Bước 3: Phân tích (chỉ khi có giá trị)**
Nếu feedback CÓ GIÁ TRỊ, trả về CHÍNH XÁC format JSON sau:
```json
{{
  "status": "ACCEPT",
  "lesson": "Kinh nghiệm học được (ngắn gọn, hành động được, từ góc nhìn AI)",
  "domain": "tên domain phù hợp",
  "score": 0.8,
  "tags": ["tag1", "tag2"]
}}
```

**DOMAIN phổ biến**: authentication, authorization, payment, file_upload, file_download, 
data_validation, form_submission, api_integration, database, security, performance, 
ui_interaction, notification, reporting, workflow, general

**SCORE (0.0-1.0)**:
- 0.9-1.0: Kinh nghiệm cực kỳ quan trọng, áp dụng rộng
- 0.7-0.8: Kinh nghiệm quan trọng, specific domain
- 0.5-0.6: Kinh nghiệm hữu ích, niche case
- 0.3-0.4: Kinh nghiệm tham khảo, edge case

**TAGS**: 2-5 keywords mô tả kinh nghiệm (lowercase, underscore_separated)

**Nếu KHÔNG có giá trị mới**: Trả về:
```json
{{
  "status": "SKIP"
}}
```

## QUY TẮC:

✅ **BẮT BUỘC:**
- Trả về JSON hợp lệ (không thêm markdown code fence)
- Lesson phải ngắn gọn (< 300 chars), cụ thể, hành động được
- Domain chọn từ list trên hoặc tự đặt nếu phù hợp
- Score phản ánh tầm quan trọng và độ áp dụng

❌ **KHÔNG:**
- Tổng hợp lại kinh nghiệm cũ
- Viết lesson chung chung
- Trả về format khác ngoài JSON

## OUTPUT: JSON object thuần (không code fence, không text thừa)
"""
        return prompt
    
    def _call_ai_api(self, prompt: str, ai_config: Dict) -> Optional[str]:
        """Call AI API for feedback analysis with support for multiple providers."""
        try:
            provider = ai_config.get('provider', 'Ollama')
            api_url = ai_config.get('api_url', '')
            model_name = ai_config.get('model_name', 'gemma3:latest')
            api_key = ai_config.get('api_key', '')
            
            logger.info(f"🔧 API Config: Provider={provider}, Model={model_name}, URL={api_url[:50]}...")
            
            # Prepare headers
            headers = {"Content-Type": "application/json"}
            
            # Configure payload and headers based on provider
            if provider == "OpenAI":
                if not api_key:
                    logger.error("❌ OpenAI API key is required but not provided")
                    return None
                
                headers["Authorization"] = f"Bearer {api_key}"
                
                payload = {
                    "model": model_name,
                    "messages": [
                        {
                            "role": "system",
                            "content": "Bạn là một AI assistant chuyên tạo test cases. Nhiệm vụ của bạn là học hỏi và tích lũy kinh nghiệm từ feedback của người dùng để liên tục cải thiện chất lượng công việc."
                        },
                        {
                            "role": "user", 
                            "content": prompt
                        }
                    ],
                    "stream": False,
                    "temperature": 0.3,  # Lower temperature for more consistent analysis
                    "top_p": 0.9,
                    "max_tokens": 1000
                }
                
            elif provider == "Ollama":
                payload = {
                    "model": model_name,
                    "messages": [
                        {
                            "role": "system",
                            "content": "Bạn là AI bot tự học từ feedback để cải thiện test case. Trả về kinh nghiệm học được dưới dạng text thuần, hoặc 'SKIP' nếu không có gì mới."
                        },
                        {
                            "role": "user", 
                            "content": prompt
                        }
                    ],
                    "stream": False,
                    "options": {
                        "temperature": 0.3,  # Lower temperature for more consistent analysis
                        "top_p": 0.9
                    }
                }
                
            else:  # Custom provider
                # Add API key if provided
                if api_key:
                    headers["Authorization"] = f"Bearer {api_key}"
                
                payload = {
                    "model": model_name,
                    "messages": [
                        {
                            "role": "system",
                            "content": "Bạn là AI bot tự học từ feedback để cải thiện test case. Trả về kinh nghiệm học được dưới dạng text thuần, hoặc 'SKIP' nếu không có gì mới."
                        },
                        {
                            "role": "user", 
                            "content": prompt
                        }
                    ],
                    "stream": False,
                    "temperature": 0.3,
                    "top_p": 0.9,
                    "max_tokens": 1000
                }
            
            logger.info(f"📤 Sending request to API...")
            logger.info(f"📦 Payload overview:")
            logger.info(f"  - Model: {payload.get('model', 'N/A')}")
            logger.info(f"  - Messages count: {len(payload.get('messages', []))}")
            logger.info(f"  - Stream: {payload.get('stream', 'N/A')}")
            
            # Log first 1000 chars of full payload for debugging
            payload_str = json.dumps(payload, ensure_ascii=False)
            logger.info(f"📦 Full payload preview: {payload_str[:1000]}...")
            
            response = requests.post(api_url, json=payload, headers=headers, timeout=30)
            
            logger.info(f"📨 Response Status Code: {response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                logger.info(f"✅ API call successful")
                logger.info(f"📦 Raw response JSON: {json.dumps(result, ensure_ascii=False)[:500]}...")
                
                # Handle different response formats
                if provider == "OpenAI":
                    content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                    logger.info(f"🔍 OpenAI format detected, extracted from: choices[0].message.content")
                else:
                    # Try different possible response structures
                    content = result.get('message', {}).get('content', '')
                    
                    # If content is empty, try alternative keys
                    if not content:
                        logger.warning("⚠️ 'message.content' is empty, trying alternatives...")
                        
                        # Try response key (some APIs use this)
                        if 'response' in result:
                            content = result.get('response', '')
                            logger.info(f"✓ Found content in 'response' key")
                        
                        # Try text key
                        elif 'text' in result:
                            content = result.get('text', '')
                            logger.info(f"✓ Found content in 'text' key")
                        
                        # Try choices array (OpenAI-like format)
                        elif 'choices' in result and len(result['choices']) > 0:
                            content = result['choices'][0].get('message', {}).get('content', '')
                            logger.info(f"✓ Found content in 'choices[0].message.content'")
                        
                        # Log available keys for debugging
                        logger.warning(f"📋 Available keys in response: {list(result.keys())}")
                    else:
                        logger.info(f"🔍 Standard format detected, extracted from: message.content")
                
                logger.info(f"📥 Response content length: {len(content)} characters")
                
                if not content:
                    logger.error("❌ Content is empty after trying all extraction methods!")
                
                return content
            else:
                logger.error(f"❌ API Error: {response.status_code}")
                logger.error(f"Response text: {response.text[:500]}...")
                return None
                
        except Exception as e:
            logger.error(f"❌ Exception calling AI API: {str(e)}", exc_info=True)
            return None
    
    def _call_ollama_api(self, prompt: str, api_url: str, model_name: str) -> Optional[str]:
        """Backward compatibility function for _call_ollama_api."""
        ai_config = {
            'provider': 'Ollama',
            'api_url': api_url,
            'model_name': model_name,
            'api_key': ''
        }
        return self._call_ai_api(prompt, ai_config)
    
    def _parse_ai_response(self, response: str) -> Dict:
        """Parse AI JSON response for learning insights with domain and scoring."""
        try:
            # Clean the response - remove markdown code fences if present
            response_clean = response.strip()
            if response_clean.startswith("```json"):
                response_clean = response_clean[7:]  # Remove ```json
            if response_clean.startswith("```"):
                response_clean = response_clean[3:]  # Remove ```
            if response_clean.endswith("```"):
                response_clean = response_clean[:-3]  # Remove trailing ```
            response_clean = response_clean.strip()
            
            # Try to parse as JSON
            try:
                parsed = json.loads(response_clean)
                
                # Check status
                status = parsed.get("status", "").upper()
                
                if status == "SKIP":
                    logger.info("🚫 AI decided to SKIP - no new valuable insight")
                    return {
                        "has_learning": False,
                        "learning_insight": "",
                        "should_update": False,
                        "domain": None,
                        "relevance_score": 0.0,
                        "tags": []
                    }
                
                elif status == "ACCEPT":
                    # Extract structured data
                    lesson = parsed.get("lesson", "").strip()
                    domain = parsed.get("domain", "general").strip().lower()
                    score = float(parsed.get("score", 0.5))
                    tags = parsed.get("tags", [])
                    
                    # Validate
                    if not lesson or len(lesson) < 10:
                        logger.warning("⚠️ Lesson too short, treating as SKIP")
                        return {
                            "has_learning": False,
                            "learning_insight": "",
                            "should_update": False,
                            "domain": None,
                            "relevance_score": 0.0,
                            "tags": []
                        }
                    
                    # Limit lesson length
                    if len(lesson) > 500:
                        lesson = lesson[:497] + "..."
                    
                    # Ensure score is in valid range
                    score = max(0.0, min(1.0, score))
                    
                    # Convert tags to JSON string
                    tags_json = json.dumps(tags) if isinstance(tags, list) else "[]"
                    
                    logger.info(f"✅ AI ACCEPTED - Domain: {domain}, Score: {score:.2f}")
                    logger.info(f"   Tags: {tags}")
                    
                    return {
                        "has_learning": True,
                        "learning_insight": lesson,
                        "should_update": True,
                        "domain": domain,
                        "relevance_score": score,
                        "tags": tags_json
                    }
                
                else:
                    logger.warning(f"⚠️ Unknown status: {status}, treating as SKIP")
                    return {
                        "has_learning": False,
                        "learning_insight": "",
                        "should_update": False,
                        "domain": None,
                        "relevance_score": 0.0,
                        "tags": []
                    }
                    
            except json.JSONDecodeError as je:
                logger.warning(f"⚠️ Failed to parse JSON response: {str(je)}")
                logger.warning(f"   Response was: {response_clean[:200]}...")
                
                # Fallback: treat as plain text if it looks valuable
                if len(response_clean) >= 20 and "skip" not in response_clean.lower():
                    logger.info("   Falling back to plain text parsing")
                    return {
                        "has_learning": True,
                        "learning_insight": response_clean[:500],
                        "should_update": True,
                        "domain": "general",
                        "relevance_score": 0.5,
                        "tags": "[]"
                    }
                else:
                    return {
                        "has_learning": False,
                        "learning_insight": "",
                        "should_update": False,
                        "domain": None,
                        "relevance_score": 0.0,
                        "tags": []
                    }
            
        except Exception as e:
            logger.error(f"❌ Error parsing AI response: {str(e)}", exc_info=True)
            return {
                "has_learning": False,
                "learning_insight": "",
                "should_update": False,
                "domain": None,
                "relevance_score": 0.0,
                "tags": []
            }
    
    def _fallback_analysis(self, feedback_text: str) -> Dict:
        """Fallback analysis when AI analysis fails - includes knowledge base fields."""
        # Simple fallback - just check if there's meaningful content
        if len(feedback_text.strip()) < 10:
            return {
                "has_learning": False,
                "learning_insight": "",
                "should_update": False,
                "domain": None,
                "relevance_score": 0.0,
                "tags": "[]"
            }
        
        # Create a basic learning insight
        learning_insight = f"Cần xem xét feedback: {feedback_text[:300]}..."
        
        return {
            "has_learning": True,
            "learning_insight": learning_insight,
            "should_update": True,
            "domain": "general",  # Default domain for fallback
            "relevance_score": 0.3,  # Low score for fallback
            "tags": json.dumps(["manual_review", "fallback"])  # Tags indicating fallback
        }
    
    def _get_default_value(self, field: str):
        """Get default value for missing fields."""
        defaults = {
            "processed_feedback": "User feedback needs processing",
            "category": "general",
            "priority": 1,
            "is_duplicate": False,
            "actionable_points": [],
            "system_prompt_addition": "",
            "reasoning": "Default value"
        }
        return defaults.get(field, "")
    
    def process_and_store_feedback(self, feedback_text: str, ai_config: Dict, metadata: Dict = None) -> Dict:
        """
        Complete feedback processing pipeline with learning experience update.
        
        Args:
            feedback_text: User feedback
            ai_config: AI configuration dict containing provider, api_url, model_name, api_key
            metadata: Optional metadata dict with feedback_type, priority, category, source etc.
            
        Returns:
            Dict with processing results
        """
        try:
            logger.info("\n" + "="*80)
            logger.info("📊 BẮT ĐẦU PIPELINE XỬ LÝ VÀ LƯU FEEDBACK")
            logger.info("="*80)
            
            # Analyze feedback with AI to get updated learning experience
            analysis = self.analyze_feedback(feedback_text, ai_config)
            
            # Check if there's new learning to update
            if not analysis.get("should_update", False) or not analysis.get("has_learning", False):
                logger.warning("⚠️ Không có kinh nghiệm mới để học từ feedback này")
                logger.warning(f"  - should_update: {analysis.get('should_update', False)}")
                logger.warning(f"  - has_learning: {analysis.get('has_learning', False)}")
                return {
                    "success": False,
                    "message": "Không có kinh nghiệm mới để học từ feedback này.",
                    "analysis": analysis
                }
            
            learning_insight = analysis.get("learning_insight", "")
            domain = analysis.get("domain", "general")
            relevance_score = analysis.get("relevance_score", 0.5)
            tags = analysis.get("tags", "[]")
            
            logger.info("💡 KINH NGHIỆM MỚI ĐÃ HỌC:")
            logger.info(f"📝 Lesson: {learning_insight}")
            logger.info(f"🏷️  Domain: {domain}")
            logger.info(f"⭐ Score: {relevance_score:.2f}")
            logger.info(f"🔖 Tags: {tags}")
            logger.info("")
            
            # Store in Qdrant with automatic embedding generation
            logger.info("💾 Đang lưu vào Qdrant...")
            
            # Parse tags from JSON string to list
            tags_list = []
            try:
                if isinstance(tags, str):
                    tags_list = json.loads(tags)
                elif isinstance(tags, list):
                    tags_list = tags
            except:
                tags_list = []
            
            feedback_id = qdrant_service.add_feedback(
                feedback_text=feedback_text,
                processed_feedback=learning_insight,  # The lesson learned
                domain=domain,
                relevance_score=relevance_score,
                tags=tags_list,
                category="learning",
                priority=1,
                metadata={
                    "learning_updated": True,
                    "user_metadata": metadata or {},
                    "timestamp": datetime.now().isoformat(),
                    "ai_analysis_details": {
                        "domain": domain,
                        "score": relevance_score,
                        "tags": tags_list
                    }
                }
            )
            
            logger.info(f"✅ Lưu thành công! Feedback ID: {feedback_id}")
            logger.info("="*80)
            logger.info("🎉 HOÀN TẤT XỬ LÝ FEEDBACK")
            logger.info("="*80 + "\n")
            
            return {
                "success": True,
                "message": f"Kinh nghiệm đã được cập nhật và lưu thành công",
                "feedback_id": feedback_id,
                "analysis": analysis,
                "learning_experience": learning_insight  # Add this for UI display
            }
            
        except Exception as e:
            logger.error(f"❌ LỖI XỬ LÝ FEEDBACK: {str(e)}", exc_info=True)
            return {
                "success": False,
                "message": f"Lỗi xử lý feedback: {str(e)}",
                "analysis": None
            }

# Global instance
feedback_analyzer = FeedbackAnalyzer()
