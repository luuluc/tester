# Simplified prompt version - shorter and more focused
# This is a backup/reference file

