"""
Excel Template Analyzer for Test Case Structure
Analyzes Excel templates and creates standardized test case structure mapping
"""

import json
from typing import Dict, Any, List


def generate_template_analysis_prompt(excel_columns: List[str], sample_data: List[Dict] = None) -> str:
    """
    Generate prompt for AI to analyze Excel template and create test case structure mapping.
    
    Args:
        excel_columns: List of column names from Excel template
        sample_data: Optional sample data from Excel for better analysis
        
    Returns:
        Formatted prompt for AI analysis
    """
    
    prompt = f"""
# EXCEL TEMPLATE ANALYSIS FOR TEST CASE STRUCTURE

Bạn là chuyên gia phân tích cấu trúc test case. Nhiệm vụ của bạn là phân tích template Excel và tạo ra bộ khung chuẩn cho test case.

## THÔNG TIN TEMPLATE EXCEL:
**Các cột trong template:**
{chr(10).join([f"- {col}" for col in excel_columns])}

## YÊU CẦU PHÂN TÍCH:

### 1. LỌC CỘT LIÊN QUAN ĐẾN TEST CASE
- Scan tất cả columns
- Loại bỏ metadata/info columns (như "Current Result", "Profile", "Auto/Manual" nếu không phải test case info)
- Chỉ giữ lại các cột liên quan đến test case description:
  * Tên/Mã test case
  * Các bước test (test steps, content, flow)
  * Kết quả mong đợi (expected result, expected)
  * Mức độ ưu tiên (priority)
  * Mô tả chức năng (function description, section)
  * Input/Output nếu là phần của test case description

### 2. TẠO BỘ KHUNG TEST CASE CHUẨN
Chỉ từ các cột đã được lọc, tạo ra một JSON structure với:
- **Key**: Tên field dạng camelCase tiếng Anh (ví dụ: testCaseCode, testCaseName, testSteps)
- **Value**: Tên cột Excel GỐC (giữ nguyên tên cột trong Excel, không đổi)
- Mapping phải logic: 
  * "Test data Name" hoặc "Test Case Name" → testCaseName
  * "Content" hoặc "Test Steps" → testSteps  
  * "Expected" hoặc "Expected Result" → expectedResult
  * "Priority" → priority
  * "Flow Testcase" hoặc "Section" → section hoặc functionDescription
- Các cột được chọn phải giống 100% với tên cột trong Excel (Value phải là tên cột gốc)

### 3. OUTPUT FORMAT:
Trả về kết quả theo định dạng XML với cấu trúc động dựa trên các cột Excel được cung cấp:

```xml
<template_analysis>
<test_case_structure>
{{
  "field1_camelCase": "Mô tả bằng tiếng Việt cho field này",
  "field2_camelCase": "Mô tả bằng tiếng Việt cho field này",
  "fieldN_camelCase": "Mô tả bằng tiếng Việt cho field này"
}}
</test_case_structure>

<analysis_notes>
- Đã phân tích và lọc các cột liên quan test case
- Ghi chú về cách phân tích và mapping
- Lý do chọn tên field cụ thể
</analysis_notes>
</template_analysis>
```


## VÍ DỤ MINH HỌA:
Nếu Excel có cột: ["Tên dự án", "Người tạo", "Mã TC", "Tên Test Case", "Các bước test", "Mức độ", "Kết quả mong đợi", "Ghi chú chung"]

Kết quả phân tích sẽ là:
```xml
<template_analysis>
<test_case_structure>
{{
  "testCaseCode": "Mã định danh test case",
  "testCaseName": "Tên test case",
  "testSteps": "Các bước thực hiện test", 
  "priority": "Mức độ ưu tiên",
  "expectedResult": "Kết quả mong đợi"
}}
</test_case_structure>

<analysis_notes>
- Đã lọc và phân tích 5 cột liên quan test case, bỏ qua 3 cột thông tin chung
- Chọn "testCaseCode" thay vì "testCaseId" vì cột gốc là "Mã TC"
- Tất cả field names đã được chuyển sang camelCase chuẩn
</analysis_notes>
</template_analysis>
```
- 
BẮT ĐẦU PHÂN TÍCH TEMPLATE:
"""

    # Add sample data if available
    if sample_data and len(sample_data) > 0:
        prompt += f"""
        
## DỮ LIỆU MẪU TỪ EXCEL:
```json
{json.dumps(sample_data[:3], indent=2, ensure_ascii=False)}
```

Sử dụng dữ liệu mẫu này để hiểu rõ hơn về cấu trúc và nội dung của từng cột.
"""

    return prompt


def parse_template_analysis_response(response: str) -> Dict[str, Any]:
    """
    Parse AI response and extract template analysis results.
    
    Args:
        response: Raw response from AI
        
    Returns:
        Dictionary containing test case structure and field mapping
    """
    
    try:
        # Extract test case structure
        structure_start = response.find('<test_case_structure>')
        structure_end = response.find('</test_case_structure>')
        
        if structure_start != -1 and structure_end != -1:
            structure_json = response[structure_start + len('<test_case_structure>'):structure_end].strip()
            # Clean up JSON formatting
            structure_json = structure_json.replace('{{', '{').replace('}}', '}')
            test_case_structure = json.loads(structure_json)
        else:
            test_case_structure = {}
        
        # Extract analysis notes
        notes_start = response.find('<analysis_notes>')
        notes_end = response.find('</analysis_notes>')
        
        if notes_start != -1 and notes_end != -1:
            analysis_notes = response[notes_start + len('<analysis_notes>'):notes_end].strip()
        else:
            analysis_notes = "Không có ghi chú phân tích"
        
        return {
            'test_case_structure': test_case_structure,
            'analysis_notes': analysis_notes,
            'success': True
        }
        
    except Exception as e:
        # Fallback parsing if XML format fails
        return {
            'test_case_structure': {},
            'analysis_notes': f"Lỗi phân tích: {str(e)}",
            'success': False,
            'raw_response': response
        }


def create_default_test_case_structure() -> Dict[str, Any]:
    """
    Create default test case structure when no template is provided.
    
    Returns:
        Default test case structure and mapping
    """
    
    return {
        'test_case_structure': {
            "testCaseId": "Mã định danh test case",
            "testCaseName": "Tên test case", 
            "testSteps": "Các bước thực hiện test",
            "priority": "Mức độ ưu tiên",
            "expectedResult": "Kết quả mong đợi",
            "section": "Phần tài liệu",
            "functionDescription": "Mô tả chức năng được test",
            "category": "Loại test case"
        },
        'excel_columns': [
            "Test_Case_ID", "Test_Case_Name", "Test_Steps", "Priority", 
            "Result", "Section", "Function_Description", "Category"
        ],
        'analysis_notes': "Cấu trúc mặc định cho test case",
        'success': True
    }


def validate_template_structure(template_analysis: Dict[str, Any], original_excel_columns: List[str] = None) -> Dict[str, Any]:
    """
    Validate and enhance template structure analysis.
    Only validates the structure without modifying fields since AI has already analyzed.
    
    Args:
        template_analysis: Result from parse_template_analysis_response
        original_excel_columns: Original Excel column names (optional, for validation)
        
    Returns:
        Validated template structure with excel_columns added
    """
    
    if not template_analysis.get('success', False):
        return create_default_test_case_structure()
    
    structure = template_analysis.get('test_case_structure', {})
    
    # Basic validation - ensure we have some structure and mapping
    if not structure:
        return create_default_test_case_structure()
    
    # Get Excel columns - use values from structure (which should be original Excel column names)
    # If original_excel_columns provided, validate that structure values match
    excel_columns = list(structure.values())
    
    # Validate that all structure values are actual Excel columns
    if original_excel_columns:
        # Filter to only include columns that exist in original Excel
        validated_columns = [col for col in excel_columns if col in original_excel_columns]
        if validated_columns:
            excel_columns = validated_columns
    
    # Don't modify the AI-analyzed structure, just add excel_columns and return
    return {
        'test_case_structure': structure,
        'excel_columns': excel_columns,  # Excel column names from structure values
        'analysis_notes': template_analysis.get('analysis_notes', ''),
        'success': True
    }


def generate_test_case_template_info(template_analysis: Dict[str, Any]) -> str:
    """
    Generate human-readable template information for display.
    
    Args:
        template_analysis: Validated template analysis
        
    Returns:
        Formatted template information string
    """
    
    if not template_analysis.get('success', False):
        return "❌ Không thể phân tích template"
    
    structure = template_analysis.get('test_case_structure', {})
    notes = template_analysis.get('analysis_notes', '')
    
    info = "### 📊 Cấu trúc Test Case từ Template\n\n"
    
    info += "**Các trường dữ liệu:**\n"
    for key, description in structure.items():
        excel_column = structure.get(key, 'N/A')
        info += f"- **{key}**: {description} ← `{excel_column}`\n"
    
    if notes:
        info += f"\n**Ghi chú phân tích:**\n{notes}\n"
    
    return info
