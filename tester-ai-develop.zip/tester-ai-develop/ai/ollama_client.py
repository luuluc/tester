"""
AI integration for test case generation using configurable LLM providers.
"""

import requests
import streamlit as st
import os
import json
import uuid
from datetime import datetime
from typing import List, Dict, Any, Callable
from utils.helpers import log_detailed_message
from utils.qdrant_feedback_service import get_qdrant_feedback_service
from services.llm_service import get_llm_service

# Lazy load Qdrant service to avoid CUDA memory issues on import
_qdrant_service = None

def get_qdrant_service():
    """Get Qdrant service with lazy loading."""
    global _qdrant_service
    if _qdrant_service is None:
        try:
            _qdrant_service = get_qdrant_feedback_service()
        except Exception as e:
            log_detailed_message(f"⚠️ Failed to initialize Qdrant service: {e}", "warning")
            _qdrant_service = None
    return _qdrant_service


def detect_domains_with_llm(section_title: str, content_preview: str = "", ai_config: dict = None) -> Dict[str, Any]:
    """
    Detect multiple related domains and generate optimized query using LLM analysis.
    LLM can understand context better than keyword matching.
    
    Args:
        section_title: Title of the section
        content_preview: Preview of content (first 500 chars)
        ai_config: Optional AI config, will use default from session if not provided
        
    Returns:
        Dict with:
            - domains: List of detected domains (1-3 items)
            - optimized_query: Optimized query string for searching lessons
    """
    try:
        # Get AI config
        if not ai_config:
            llm_service = get_llm_service()
            ai_config = llm_service.get_current_config() if llm_service else None
        
        if not ai_config:
            log_detailed_message("⚠️ No AI config available, using fallback domain detection", "warning")
            return {'domains': ['general'], 'optimized_query': section_title}
        
        # Build prompt for domain detection AND query optimization
        prompt = f"""Phân tích section sau để tìm kinh nghiệm liên quan trong knowledge base:

**Section Title:** {section_title}

**Content Preview:**
{content_preview[:300]}

**DANH SÁCH DOMAINS:**
- authentication: Đăng nhập, xác thực người dùng
- authorization: Phân quyền, access control
- payment: Thanh toán, billing, invoice
- file_upload: Upload file, import dữ liệu
- file_download: Download, export dữ liệu
- data_validation: Validation dữ liệu đầu vào
- form_submission: Submit form, nhập liệu
- api_integration: Tích hợp API, REST, HTTP
- database: Database operations, query, lưu trữ
- security: Bảo mật, encryption, token
- performance: Hiệu năng, tối ưu, speed
- ui_interaction: Tương tác UI, button, click
- notification: Thông báo, alert, email, sms
- reporting: Báo cáo, thống kê, dashboard
- workflow: Quy trình, process, luồng xử lý
- general: Chung chung, không thuộc domain cụ thể

**NHIỆM VỤ:**
1. **Domains**: Xác định 1-3 domains liên quan (sắp xếp theo độ liên quan)
2. **Optimized Query**: Tạo query tìm kiếm tốt để tìm lessons liên quan (bao gồm từ khóa chính, các khái niệm liên quan, lỗi thường gặp)

**VÍ DỤ:**
Input: "Đăng nhập hệ thống - User nhập email và password"
Output:
```json
{{
  "domains": ["authentication", "data_validation", "security"],
  "optimized_query": "đăng nhập authentication login email password validation session token security lỗi thường gặp"
}}
```

**OUTPUT (JSON only):**"""

        # Call LLM
        provider = ai_config.get('provider', 'Ollama')
        api_url = ai_config.get('api_url', '')
        model_name = ai_config.get('model_name', 'gemma3:latest')
        api_key = ai_config.get('api_key', '')
        
        headers = {"Content-Type": "application/json"}
        
        if provider == "OpenAI":
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"
            payload = {
                "model": model_name,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.3,
                "max_tokens": 100
            }
        else:  # Ollama or custom
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"
            payload = {
                "model": model_name,
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
                "options": {"temperature": 0.3}
            }
        
        response = requests.post(api_url, json=payload, headers=headers, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            
            # Extract content
            if provider == "OpenAI":
                content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
            else:
                content = result.get('message', {}).get('content', '')
                if not content:
                    content = result.get('response', '')
            
            # Parse JSON response - extract JSON from text if needed
            content_clean = content.strip()
            
            # Try to extract JSON from response
            json_content = None
            
            # Method 1: Remove markdown code fences
            if content_clean.startswith('```'):
                lines = content_clean.split('\n')
                # Remove first line (```json or ```) and last line (```)
                if lines[0].strip().startswith('```'):
                    lines = lines[1:]
                if lines and lines[-1].strip() == '```':
                    lines = lines[:-1]
                json_content = '\n'.join(lines).strip()
            else:
                json_content = content_clean
            
            # Method 2: If direct parse fails, try to find JSON object in text
            try:
                result = json.loads(json_content)
            except json.JSONDecodeError:
                # Try to extract JSON object from text
                import re
                # Find first { and last } to extract JSON
                json_match = re.search(r'\{.*\}', json_content, re.DOTALL)
                if json_match:
                    json_str = json_match.group(0)
                    try:
                        result = json.loads(json_str)
                        log_detailed_message(f"✅ Extracted JSON from text response for domain detection", "info")
                    except json.JSONDecodeError as e:
                        log_detailed_message(f"⚠️ Failed to parse extracted JSON: {e}. Content: '{json_content[:100]}'", "warning")
                        return {'domains': ['general'], 'optimized_query': section_title}
                else:
                    log_detailed_message(f"⚠️ No JSON found in response: '{json_content[:100]}'", "warning")
                    return {'domains': ['general'], 'optimized_query': section_title}
            
            if isinstance(result, dict):
                domains = result.get('domains', ['general'])
                optimized_query = result.get('optimized_query', section_title)
                
                # Validate
                if not isinstance(domains, list) or len(domains) == 0:
                    domains = ['general']
                
                domains = domains[:3]  # Limit to top 3
                
                log_detailed_message(f"✅ LLM detected: domains={domains}, query={optimized_query[:50]}...", "info")
                return {
                    'domains': domains,
                    'optimized_query': optimized_query
                }
            else:
                log_detailed_message("⚠️ LLM returned invalid format, using fallback", "warning")
                return {'domains': ['general'], 'optimized_query': section_title}
                
        else:
            log_detailed_message(f"⚠️ LLM API error: {response.status_code}", "warning")
            return {'domains': ['general'], 'optimized_query': section_title}
            
    except Exception as e:
        log_detailed_message(f"⚠️ Error detecting domains with LLM: {e}, using fallback", "warning")
        return {'domains': ['general'], 'optimized_query': section_title}


def get_feedback_enhancement(section_title: str = None, content_preview: str = "") -> str:
    """Get feedback content to enhance system prompts with SEMANTIC SEARCH from Qdrant.
    Uses LLM to detect multiple relevant domains and pure semantic search (no domain filter).
    
    Args:
        section_title: Optional section title to detect domain
        content_preview: Optional content preview for better domain detection
    
    Returns:
        Formatted feedback string to include in prompts
    """
    try:
        # If section info provided, use semantic search
        if section_title:
            # Detect domains and get optimized query using LLM
            detection_result = detect_domains_with_llm(section_title, content_preview)
            detected_domains = detection_result.get('domains', ['general'])
            optimized_query = detection_result.get('optimized_query', section_title)
            
            log_detailed_message(f"📍 LLM detected domains: {detected_domains}, optimized query: {optimized_query[:50]}...", "info")
            
            # Use PURE SEMANTIC SEARCH with optimized query (no domain filter)
            # Domain is only used for logging/display, not filtering
            qdrant_service = get_qdrant_service()
            if qdrant_service is None:
                log_detailed_message("⚠️ Qdrant service not available, skipping feedback enhancement", "warning")
                return ""
            
            lessons = qdrant_service.get_relevant_lessons_semantic(
                query_text=optimized_query,  # Use optimized query from LLM
                domain=None,  # No domain filter - pure semantic search
                limit=10,  # Get more results
                min_score=0.3,  # Lower metadata score threshold
                relevance_threshold=0.5  # Semantic similarity threshold
            )
            
            if lessons and len(lessons) > 0:
                log_detailed_message(f"✅ Retrieved {len(lessons)} relevant lessons using pure semantic search", "info")
                
                # Format lessons for prompt
                summary_lines = [f"\n=== KINH NGHIỆM ĐÃ HỌC LIÊN QUAN ==="]
                
                for i, lesson in enumerate(lessons[:5], 1):  # Top 5
                    processed = lesson.get('processed_feedback', '')
                    relevance_score = lesson.get('relevance_score', 0.5)
                    similarity = lesson.get('similarity_score', 0)
                    lesson_domain = lesson.get('domain', 'general')
                    
                    if processed:
                        summary_lines.append(
                            f"{i}. [{relevance_score:.1f} | sim:{similarity:.2f} | {lesson_domain}] {processed}"
                        )
                
                summary_lines.append("=" * 80)
                domain_lessons = "\n".join(summary_lines)
                
                return f"""

{domain_lessons}

**LƯU Ý:** Hãy áp dụng những kinh nghiệm học được ở trên để tạo ra test case chất lượng cao hơn.
"""
            else:
                log_detailed_message("ℹ️ No relevant lessons found", "info")
                return ""
        
        # Fallback: No section info, return empty
        log_detailed_message("ℹ️ No section info provided, skipping feedback enhancement", "info")
        return ""
            
    except Exception as e:
        log_detailed_message(f"⚠️ Lỗi khi lấy feedback cho system prompt: {e}", "warning")
        return ""


def save_prompt_and_response(prompt: str, response: str, section_path: str = None):
    """Save prompt and response to file for debugging.
    
    Args:
        prompt: The prompt sent to AI
        response: The response from AI
        section_path: Full path of the section (optional)
    """
    try:
        # Create prompt directory if it doesn't exist
        prompt_dir = "prompt"
        if not os.path.exists(prompt_dir):
            os.makedirs(prompt_dir)
        
        # Create filename using UUID
        unique_id = str(uuid.uuid4())
        filename = f"{unique_id}.json"
        filepath = os.path.join(prompt_dir, filename)
        
        # Prepare data to save
        data = {
            "timestamp": datetime.now().isoformat(),
            "section_path": section_path,
            "prompt": prompt,
            "response": response,
            "metadata": {
                "prompt_length": len(prompt),
                "response_length": len(response),
                "model_used": st.session_state.get('selected_model', 'unknown')
            }
        }
        
        # Save to JSON file
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        log_detailed_message(f"💾 Đã lưu prompt và response vào: {filepath}")
        
    except Exception as e:
        log_detailed_message(f"⚠️ Lỗi khi lưu prompt: {str(e)}", "error")


def call_ai_api(prompt: str, model: str = "gemma3:latest", stream_placeholder=None, section_path: str = None, stream: bool = True) -> str:
    """Call AI API for LLM inference using the configured LLM service.
    
    Args:
        prompt: The prompt to send to the model
        model: The model name to use (deprecated - now read from config)
        stream_placeholder: Streamlit placeholder for streaming output
        section_path: Full path of the section
        stream: Whether to use streaming response
        
    Returns:
        Generated response text
    """
    try:
        # Get the LLM service
        llm_service = get_llm_service()
        
        # Check if we have a valid configuration
        current_config = llm_service.get_current_config()
        if not current_config:
            raise Exception("No LLM configuration found. Please set up LLM configurations first.")
        
        # Create system prompt format
        system_prompt = f"""System: {prompt}

User: Thực hiện task theo hướng dẫn trên"""
        
        # Call the LLM service
        response = llm_service.call_ai_api(
            prompt=system_prompt,
            stream_placeholder=stream_placeholder,
            stream=stream
        )
        
        # Save prompt and response for debugging
        save_prompt_and_response(prompt, response, section_path)
        
        return response
        
    except Exception as e:
        error_msg = f"Lỗi khi gọi AI API: {str(e)}"
        print(f"❌ {error_msg}")
        log_detailed_message(error_msg, "error")
        
        if stream_placeholder:
            stream_placeholder.error(f"❌ {error_msg}")
        
        # Return empty string or raise exception based on your preference
        # For now, we'll raise the exception to maintain existing behavior
        raise e


def call_ollama_api(prompt: str, model: str = "gemma3:latest", stream_placeholder=None, section_title: str = None, section_path: str = None, stream: bool = True) -> str:
    """Backward compatibility function for call_ollama_api.
    
    This function maintains compatibility with existing code that calls call_ollama_api.
    It internally uses the new call_ai_api function which supports multiple providers.
    
    Args:
        prompt: The prompt to send to the model
        model: The model name to use
        stream_placeholder: Streamlit placeholder for streaming output
        section_title: Title of the section being processed (deprecated, ignored)
        section_path: Full path of the section
        stream: Whether to use streaming response
        
    Returns:
        Generated response text
    """
    return call_ai_api(prompt, model, stream_placeholder, section_path, stream)


def generate_hierarchical_test_case_prompt(section: dict, hierarchy_context: str, template_analysis: dict = None, focus: str = "comprehensive") -> str:
    """Generate an optimized prompt for hierarchical test case creation with comprehensive analysis.
    
    Args:
        section: Section dictionary with title, content, level info
        hierarchy_context: Hierarchical context string
        template_analysis: Optional analyzed template structure for output formatting
        focus: Generation focus - "comprehensive", "functional", "negative", "boundary", "security"
        
    Returns:
        Formatted prompt for the LLM using advanced techniques
    """
    # Build full path display
    full_path = section.get('full_path', section.get('full_context', section['title']))
    parent_context = section.get('parent_context', '')
    
    # Extract test case structure from template analysis if available
    test_case_structure = {}
    if template_analysis and template_analysis.get('success', False):
        test_case_structure = template_analysis.get('test_case_structure', {})
    
    # Build simple content structure - just wrap all content in one XML tag
    all_content_text = ""
    content = section.get('content', [])
    
    # Process all content items simply
    for i, item in enumerate(content, 1):
        try:
            if isinstance(item, dict):
                # Extract content from different types
                if 'markdown' in item:
                    all_content_text += f"\n{item['markdown']}\n"
                elif 'list' in item:
                    list_items = item.get('list', [])
                    for list_item in list_items:
                        if isinstance(list_item, dict):
                            item_content = str(list_item.get('content', list_item.get('text', str(list_item))))
                        else:
                            item_content = str(list_item)
                        all_content_text += f"- {item_content}\n"
                elif 'table' in item:
                    table_data = item['table']
                    if isinstance(table_data, list) and table_data:
                        for row in table_data:
                            if isinstance(row, list):
                                all_content_text += f"{' | '.join([str(cell) for cell in row])}\n"
                            else:
                                all_content_text += f"{str(row)}\n"
                    else:
                        all_content_text += f"{str(table_data)}\n"
                elif 'text' in item:
                    all_content_text += f"\n{item['text']}\n"
                else:
                    # Extract all values from unknown dict structure
                    for key, value in item.items():
                        if key not in ['type', 'level', 'id']:
                            all_content_text += f"{str(value)}\n"
            else:
                # Simple string content
                all_content_text += f"{str(item)}\n"
                
        except Exception as e:
            # Fallback for any processing errors
            log_detailed_message(f"⚠️ Lỗi xử lý content item {i}: {e}", "warning")
            all_content_text += f"{str(item)}\n"


    # Main prompt - SIMPLIFIED VERSION (shorter, more focused)
    prompt = f"""
Bạn là chuyên gia kiểm thử phần mềm. Nhiệm vụ: Phân tích và tạo test cases CHI TIẾT, TOÀN DIỆN nhất có thể.

## THÔNG TIN ĐẦU VÀO

### Ngữ cảnh tài liệu:
{hierarchy_context}

### Phần cần phân tích:
- Tiêu đề: {section['title']}
- Cấp độ: {section.get('level', 1)}
- Đường dẫn: {full_path}
- Ngữ cảnh cha: {parent_context if parent_context else 'Không có'}

### Nội dung:
<document_content>
{all_content_text}
</document_content>

## QUY TRÌNH PHÂN TÍCH

**Hãy phân tích:**
1. **Inputs**: Tất cả fields/parameters với kiểu dữ liệu, ràng buộc, validation
2. **Outputs**: Kết quả thành công và lỗi
3. **Business Rules**: Các quy tắc nghiệp vụ và điều kiện
4. **Flows**: Luồng chính, luồng phụ, luồng lỗi
5. **States**: Trạng thái và chuyển đổi (nếu có)

## KỸ THUẬT TẠO TEST CASE

**Áp dụng các kỹ thuật:**
1. **Equivalence Partitioning**: Chia inputs thành valid/invalid classes
2. **Boundary Value Analysis**: Test min, max, min-1, max+1
3. **Decision Table**: Test các combinations của business rules
4. **State Transition**: Test chuyển đổi trạng thái (nếu có)
5. **Error Guessing**: Test SQL injection, XSS, null, timeout, permission errors
6. **Combinatorial**: Test combinations của nhiều inputs

## YÊU CẦU SỐ LƯỢNG TEST CASE

**Tạo CÀNG NHIỀU test cases CÀNG TỐT - DỰA TRÊN TÀI LIỆU:**
- **Section đơn giản**: Tối thiểu 15-25 test cases (nếu tài liệu có đủ thông tin)
- **Section phức tạp**: 30-50+ test cases (nếu tài liệu có đủ thông tin)
- **Bao gồm**: Happy path, positive, negative, boundary, error, security cases
- **Lưu ý**: Số lượng phụ thuộc vào độ chi tiết của tài liệu. Nếu tài liệu chi tiết → tạo NHIỀU test case hơn. Nếu tài liệu sơ sài → tạo ÍT test case nhưng CHÍNH XÁC

## CẤU TRÚC TEST CASE

Mỗi test case cần có:
- **Test Case ID**: Mã duy nhất
- **Test Case Name**: Tên rõ ràng, cụ thể
- **Test Steps**: Các bước chi tiết (array of strings)
- **Expected Result**: Kết quả mong đợi cụ thể
- **Priority**: Cao/Trung bình/Thấp
- **Category**: Functional/Negative/Boundary/Security

## ⚠️ QUY TẮC NGHIÊM NGẶT - KHÔNG ĐƯỢC BỊA TEST CASE ⚠️

🚫 **NGHIÊM CẤM TUYỆT ĐỐI - BỊA ĐẶT SẼ BỊ TỪ CHỐI:**

1. **CHỈ DỰA VÀO TÀI LIỆU - KHÔNG CÓ NGOẠI LỆ:**
   - ✅ ĐƯỢC PHÉP: Chỉ tạo test case dựa trên thông tin CÓ SẴN trong `<document_content>`
   - ❌ CẤM TUYỆT ĐỐI: Suy đoán, bịa đặt, hoặc thêm bất kỳ thông tin nào KHÔNG có trong tài liệu
   - ❌ CẤM TUYỆT ĐỐI: Tạo test case cho chức năng/tính năng KHÔNG được mô tả trong tài liệu
   - ❌ CẤM TUYỆT ĐỐI: Giả định các trường dữ liệu, validation rules, business rules KHÔNG có trong tài liệu
   - ❌ CẤM TUYỆT ĐỐI: "Điền vào chỗ trống" bằng kiến thức bên ngoài hoặc suy đoán

2. **QUY TRÌNH BẮT BUỘC TRƯỚC KHI TẠO MỖI TEST CASE:**
   ```
   BƯỚC 1: Đọc lại tài liệu và tìm thông tin liên quan
   BƯỚC 2: Xác định chính xác phần nào trong tài liệu mô tả test case này
   BƯỚC 3: Kiểm tra: Mỗi test step có nguồn gốc từ tài liệu không?
   BƯỚC 4: Kiểm tra: Expected result có được mô tả trong tài liệu không?
   BƯỚC 5: Nếu KHÔNG tìm thấy nguồn gốc rõ ràng → KHÔNG TẠO TEST CASE ĐÓ
   ```

3. **PHÂN TÍCH KỸ TÀI LIỆU ĐỂ TẠO NHIỀU TEST CASE:**
   - Đọc KỸ từng câu, từng đoạn, từng bảng trong `<document_content>`
   - Tìm TẤT CẢ các inputs, outputs, business rules, flows được đề cập TRỰC TIẾP trong tài liệu
   - Tạo test case cho MỌI luồng, MỌI quy tắc, MỌI trường hợp được mô tả RÕ RÀNG trong tài liệu
   - Phân tích từ nhiều góc độ: happy path, negative, boundary, error, security - NHƯNG CHỈ DỰA VÀO TÀI LIỆU

4. **CÁCH TẠO NHIỀU TEST CASE TỪ TÀI LIỆU (CHỈ KHI TÀI LIỆU CÓ THÔNG TIN):**
   - Nếu tài liệu mô tả input field → tạo test case cho valid, invalid, boundary values (nếu tài liệu có mô tả)
   - Nếu tài liệu mô tả business rule → tạo test case cho rule đó pass và fail
   - Nếu tài liệu mô tả luồng xử lý → tạo test case cho happy path và error path (nếu tài liệu có mô tả)
   - Nếu tài liệu mô tả output case → tạo test case để verify output đó
   - **QUAN TRỌNG**: Chỉ tạo khi tài liệu CÓ MÔ TẢ, không tự suy đoán

5. **XỬ LÝ CÁC TRƯỜNG KHÔNG CÓ THÔNG TIN:**
   - ✅ **ĐƯỢC PHÉP**: Nếu một field/trường không có thông tin trong tài liệu → ĐỂ TRỐNG (empty string "" hoặc null)
   - ❌ **CẤM TUYỆT ĐỐI**: Điền giá trị suy đoán, giả định, hoặc bịa đặt vào các trường không có thông tin
   - ❌ **CẤM TUYỆT ĐỐI**: Tạo giá trị mặc định cho các trường không được mô tả trong tài liệu
   - **Ví dụ**: Nếu tài liệu không mô tả "Priority" → để trống "", KHÔNG được điền "Trung bình" hay bất kỳ giá trị nào
   - **Ví dụ**: Nếu tài liệu không mô tả "Category" → để trống "", KHÔNG được điền "Functional" hay bất kỳ giá trị nào

5. **KIỂM TRA CUỐI CÙNG - TỰ VALIDATE:**
   - Với MỖI test case, tự hỏi: "Tôi có thể chỉ ra chính xác câu/đoạn nào trong tài liệu mô tả test case này không?"
   - Nếu KHÔNG thể chỉ ra → XÓA test case đó ngay lập tức
   - Chỉ giữ lại những test case có nguồn gốc RÕ RÀNG từ tài liệu

## QUY TẮC

**SKIP nếu:** Nội dung quá ngắn (< 15 từ), chỉ là link/định nghĩa, thông tin tác giả, hoặc KHÔNG có đủ thông tin để tạo test case chính xác

**TẠO TEST CASE nếu có:** Hành động user, quy tắc xử lý, chức năng, workflow, giao diện, API được mô tả trong tài liệu

**Nguyên tắc:** 
- 📊 **Với tài liệu CHI TIẾT**: TẠO CÀNG NHIỀU TEST CASE CÀNG TỐT (15-50+ test cases) - Phân tích kỹ tài liệu để tìm TẤT CẢ các test case có thể
- 📝 **Với tài liệu SƠ SÀI**: Tạo ÍT test case hơn (5-15 test cases) nhưng CHÍNH XÁC theo tài liệu
- ⚠️ **QUAN TRỌNG**: Luôn PHẢI DỰA 100% VÀO TÀI LIỆU. Chất lượng (chính xác) quan trọng hơn số lượng (nhiều nhưng bịa đặt)!

## ĐỊNH DẠNG XUẤT CHUẨN

### Khi SKIP:
```
SKIP: [Lý do cụ thể tại sao không phải chức năng]
```

### Khi tạo Test Case:

""" + (f"""

**OUTPUT FORMAT**: 
- Ngôn ngữ: Tiếng Việt
- Sử dụng JSON structure theo template đã phân tích cho testcase
Ví dụ: 

```json
{{
  "test_cases": [
    {{
      {', '.join([f'"{key}": "{description}"' for key, description in test_case_structure.items()])}
    }},
    {{
      {', '.join([f'"{key}": "{description}"' for key, description in test_case_structure.items()])}
    }}
  ]
}}
```

**LƯU Ý cho JSON OUTPUT:**
- Sử dụng CHÍNH XÁC các field names từ template đã phân tích
- Không được thay đổi tên fields
- Các bước của testcase (test steps) phải viết trong list string ví dụ ["1. Mở ứng dụng", "2. Nhập thông tin đăng nhập", "3. Click nút Login", "4. Kiểm tra kết quả hiển thị"]
- JSON phải valid và không có ký tự đặc biệt gây lỗi
- Wrap toàn bộ test cases trong array "test_cases"
- **QUAN TRỌNG**: Nếu một field không có thông tin trong tài liệu → để trống "" (empty string), KHÔNG được điền giá trị suy đoán

""" 
if template_analysis and template_analysis.get('success', False) and test_case_structure 

else f"""

**OUTPUT FORMAT**: Sử dụng JSON structure mặc định

```json
{{
  "test_cases": [
    {{
      "testCaseId": "Mã test case duy nhất",
      "testCaseName": "Tên cụ thể, rõ ràng cho kịch bản test",
      "testSteps": ["1. Mở ứng dụng", "2. Nhập thông tin đăng nhập", "3. Click nút Login", "4. Kiểm tra kết quả hiển thị"],
      "priority": "Cao/Trung bình/Thấp",
      "expectedResult": "Kết quả mong đợi cụ thể",
      "section": "{section['title']}",
      "functionDescription": "Mô tả chức năng được test",
      "category": "Loại test case"
    }},
    {{
      "testCaseId": "Mã test case duy nhất khác",
      "testCaseName": "Tên test case khác",
      "testSteps": ["1. Bước thực hiện đầu tiên", "2. Bước thực hiện thứ hai", "3. Bước thực hiện cuối"],
      "priority": "Cao/Trung bình/Thấp",
      "expectedResult": "Kết quả mong đợi khác",
      "section": "{section['title']}",
      "functionDescription": "Mô tả chức năng được test",
      "category": "Loại test case"
    }}
  ]
}}
```

**LƯU Ý cho JSON OUTPUT:**
- JSON phải valid và có đúng syntax
- testSteps PHẢI là array (list) của strings: ["Bước 1", "Bước 2", "Bước 3"]
- Mỗi step trong testSteps phải là 1 string riêng biệt trong array
- Không sử dụng markdown hay HTML trong JSON values
- Escape ký tự đặc biệt như quotes
- **QUAN TRỌNG**: Nếu một field không có thông tin trong tài liệu → để trống "" (empty string), KHÔNG được điền giá trị suy đoán hoặc mặc định

""") + f"""

---
**Bắt đầu phân tích theo FLOW trên và TRẢ VỀ JSON:**

⚠️ **KIỂM TRA CUỐI CÙNG TRƯỚC KHI TRẢ VỀ:**
1. Đọc lại TẤT CẢ test cases đã tạo
2. Với mỗi test case, xác nhận: "Tôi có thể chỉ ra chính xác phần nào trong `<document_content>` mô tả test case này"
3. Nếu không thể chỉ ra → XÓA test case đó
4. Chỉ trả về những test case có nguồn gốc RÕ RÀNG từ tài liệu

**Quan trọng**: Nếu tạo test case, phải trả về JSON với format chính xác như hướng dẫn ở trên. JSON phải valid và parseable. TẤT CẢ test cases PHẢI dựa 100% vào `<document_content>` - KHÔNG CÓ NGOẠI LỆ!"""

    # Add feedback enhancement before the final instructions with section context
    section_title = section.get('title', '')
    content_preview = all_content_text[:500] if len(all_content_text) > 0 else ""
    feedback_enhancement = get_feedback_enhancement(section_title, content_preview)
    if feedback_enhancement:
        prompt += feedback_enhancement
    
    return prompt


def generate_test_cases_multi_pass(
    section: dict,
    hierarchy_context: str,
    template_analysis: dict = None,
    stream_placeholder=None,
    model_name: str = "gemma3:latest",
    pass_callback: Callable[[List[dict]], None] = None
) -> list:
    """Generate test cases using multiple passes with different focuses.
    This ensures comprehensive coverage from multiple angles.
    
    Args:
        section: Section dictionary
        hierarchy_context: Hierarchical context
        template_analysis: Optional template analysis
        stream_placeholder: Streamlit placeholder for streaming output
        model_name: Model name to use
        pass_callback: Optional callback executed after each pass with newly generated test cases
        
    Returns:
        Combined list of all test cases from all passes
    """
    from test_case.analyzer import parse_test_case_response
    
    all_test_cases = []
    section_title = section.get('title', 'Unknown')
    full_path = section.get('full_path', section_title)
    
    # Thiết lập khu vực streaming duy nhất để hiển thị nội dung pass hiện tại
    if stream_placeholder:
        streaming_placeholder = stream_placeholder.empty()
    else:
        streaming_placeholder = st.empty()
    
    # Define passes with different focuses
    passes = [
        {
            "name": "Functional & Happy Path",
            "focus": "comprehensive",
            "instruction": "Tập trung vào các luồng chức năng chính, happy path, positive cases. Tạo test cases cho tất cả các luồng thành công."
        },
        {
            "name": "Negative & Validation",
            "focus": "negative",
            "instruction": "Tập trung vào validation, error handling, negative scenarios, invalid inputs. Tạo test cases cho TẤT CẢ các trường hợp lỗi có thể xảy ra."
        },
        {
            "name": "Boundary & Edge Cases",
            "focus": "boundary",
            "instruction": "Tập trung vào boundary values, edge cases, extreme inputs, limit testing. Tạo test cases cho min, max, min-1, max+1, và các giá trị đặc biệt."
        },
        {
            "name": "Security & Integration",
            "focus": "security",
            "instruction": "Tập trung vào security testing (SQL injection, XSS, authorization), integration scenarios, error handling, performance. Tạo test cases cho các lỗ hổng bảo mật và tích hợp."
        }
    ]
    
    log_detailed_message(f"🔄 Starting multi-pass generation for: {section_title}")
    
    for i, pass_config in enumerate(passes, 1):
        log_detailed_message(f"📝 Pass {i}/{len(passes)}: {pass_config['name']}")
        
        # Mỗi pass reset nội dung streaming để chỉ hiển thị test case mới nhất
        streaming_placeholder.empty()
        
        try:
            # Generate prompt with specific focus
            prompt = generate_hierarchical_test_case_prompt(
                section, 
                hierarchy_context, 
                template_analysis,
                focus=pass_config['focus']
            )
            
            # Add pass-specific instruction
            prompt += f"\n\n## HƯỚNG DẪN ĐẶC BIỆT CHO PASS NÀY\n{pass_config['instruction']}\n"
            prompt += f"\n**Lưu ý:** Tạo test cases cho góc nhìn '{pass_config['name']}'. Không cần lặp lại test cases đã tạo ở pass trước, nhưng nếu cần thiết có thể tạo thêm variations.\n"
            
            # Call AI với streaming hiển thị trực tiếp nội dung test case đang sinh
            response = call_ai_api(
                prompt, 
                model=model_name,
                stream_placeholder=streaming_placeholder,
                section_path=full_path,
                stream=True  # Enable streaming!
            )
            
            # Parse response
            test_cases = parse_test_case_response(response, section_title, template_analysis)
            
            if test_cases:
                # Add pass metadata
                for tc in test_cases:
                    tc['generation_pass'] = pass_config['name']
                    tc['pass_number'] = i
                
                all_test_cases.extend(test_cases)
                
                if pass_callback:
                    try:
                        pass_callback(test_cases)
                    except Exception as callback_error:
                        log_detailed_message(
                            f"⚠️ Pass callback error: {callback_error}",
                            "warning"
                        )
                
                log_detailed_message(f"✅ Pass {i} generated {len(test_cases)} test cases")
            else:
                log_detailed_message(f"⚠️ Pass {i} generated 0 test cases", "warning")
                
        except Exception as e:
            log_detailed_message(f"❌ Error in pass {i}: {str(e)}", "error")
            continue
    
    # Remove duplicates based on test case name and content similarity
    seen_names = set()
    seen_content_hashes = set()  # Track content to catch duplicates with different names
    unique_test_cases = []
    duplicate_count = 0
    
    for tc in all_test_cases:
        tc_name = tc.get('testCaseName', tc.get('Test_Case_Name', ''))
        
        # Check by name first (fast check)
        is_duplicate = False
        if tc_name and tc_name in seen_names:
            is_duplicate = True
        else:
            # Check by content similarity (normalized test steps)
            test_steps = tc.get('testSteps', tc.get('Test_Steps', []))
            if isinstance(test_steps, str):
                test_steps = [test_steps]
            if not isinstance(test_steps, list):
                test_steps = []
            
            # Check by content similarity (normalized test steps)
            # Only consider duplicate if steps are IDENTICAL (same order, same content)
            # This is less strict - allows variations while catching true duplicates
            if test_steps:
                # Normalize steps: lowercase, remove numbers/bullets (but keep order)
                normalized_steps = []
                for step in test_steps:
                    step_str = str(step).strip().lower()
                    # Remove leading numbers, bullets, punctuation
                    step_str = step_str.lstrip('0123456789.-) ')
                    if step_str and len(step_str) > 5:  # Only meaningful steps
                        normalized_steps.append(step_str)
                
                # Create hash from normalized steps (KEEP ORDER - don't sort)
                # This way, test cases with same steps but different order are NOT considered duplicates
                if normalized_steps:
                    content_hash = hash(tuple(normalized_steps))  # Keep order, don't sort
                    if content_hash in seen_content_hashes:
                        is_duplicate = True
                    else:
                        seen_content_hashes.add(content_hash)
        
        if is_duplicate:
            duplicate_count += 1
            log_detailed_message(
                f"⚠️ Skipping duplicate test case: '{tc_name or 'Unknown'}'",
                "warning"
            )
        else:
            if tc_name:
                seen_names.add(tc_name)
            unique_test_cases.append(tc)
    
    if duplicate_count > 0:
        log_detailed_message(
            f"🔄 Removed {duplicate_count} duplicate test case(s) from {len(all_test_cases)} total",
            "info"
        )
    
    log_detailed_message(
        f"🎉 Multi-pass complete: {len(unique_test_cases)} unique test cases (from {len(all_test_cases)} total, removed {duplicate_count} duplicates)"
    )
    
    return unique_test_cases


