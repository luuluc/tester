# Document Structure Extractor

A clean, object-oriented Python library for extracting structured content from DOCX files with proper error handling and JSON output formatting.

## Features

- **Clean Class-Based Architecture**: Well-organized classes with single responsibilities
- **Robust Error Handling**: Gracefully handles missing files, corrupted documents, and unstructured content
- **Structured JSON Output**: Clean, properly formatted JSON with metadata
- **Unstructured Document Support**: Automatically handles documents without proper heading hierarchy
- **Comprehensive Logging**: Detailed logging for debugging and monitoring
- **Type Hints**: Full type annotations for better code maintainability
- **Dataclasses**: Modern Python patterns for data structures

## Installation

Ensure you have the required dependencies:

```bash
pip install python-docx
```

## Quick Start

### Basic Usage

```python
from test3 import DocumentStructureExtractor

# Initialize the extractor
extractor = DocumentStructureExtractor()

# Extract structure from a DOCX file
result = extractor.extract_structure("document.docx", "output.json")

print(f"Sections found: {result['total_sections']}")
print(f"Has structure: {result['metadata']['has_structure']}")
print(f"Status: {result['metadata']['processing_status']}")
```

### Advanced Usage

```python
from test3 import DocumentProcessor

# Direct processor usage for more control
processor = DocumentProcessor("document.docx")
structure = processor.process_document()

# Process the structure as needed
for section in structure:
    print(f"Section: {section['title']} (Level {section['level']})")
    print(f"Content items: {len(section['content'])}")
    print(f"Tables: {len(section['tables'])}")
    print(f"Subsections: {len(section['children'])}")
```

## Classes Overview

### DocumentStructureExtractor
Main entry point for document processing.

**Methods:**
- `extract_structure(docx_path, output_path=None)`: Extract and optionally save structure

### DocumentProcessor
Core processing engine for DOCX documents.

**Methods:**
- `process_document()`: Process entire document and return structure
- Private methods for handling different document elements

### DocumentNode
Data class representing a document section.

**Attributes:**
- `title`: Section title
- `level`: Heading level (1-6)
- `content`: List of paragraphs and lists
- `tables`: List of HTML-formatted tables
- `children`: List of subsections

### ListItem
Data class representing list structures.

**Attributes:**
- `items`: List of text items
- `list_type`: Either 'bullet' or 'number'

## JSON Output Structure

```json
{
  "document_path": "path/to/document.docx",
  "total_sections": 4,
  "structure": [
    {
      "title": "Section Title",
      "level": 1,
      "content": [
        "Paragraph text...",
        {
          "list": ["Item 1", "Item 2"],
          "type": "bullet"
        }
      ],
      "tables": ["<table>...</table>"],
      "children": [
        {
          "title": "Subsection",
          "level": 2,
          "content": [],
          "tables": [],
          "children": []
        }
      ]
    }
  ],
  "metadata": {
    "has_structure": true,
    "processing_status": "success"
  }
}
```

## Handling Different Document Types

### Structured Documents
Documents with proper heading hierarchy (Heading 1, Heading 2, etc.) are processed naturally, maintaining the original structure.

### Unstructured Documents
Documents without proper headings automatically get a default root node called "Document Content" to ensure all content is captured.

### Error Cases
- **Missing files**: Returns empty structure with failed status
- **Corrupted files**: Logs errors and returns partial structure if possible
- **Non-DOCX files**: Gracefully fails with appropriate error messages

## Error Handling Examples

```python
extractor = DocumentStructureExtractor()

# Test with non-existent file
result = extractor.extract_structure("missing.docx")
print(result['metadata']['processing_status'])  # 'failed'

# Test with wrong file format
result = extractor.extract_structure("document.pdf")
print(result['total_sections'])  # 0
```

## Logging

The library uses Python's standard logging module. Configure logging level as needed:

```python
import logging
logging.basicConfig(level=logging.INFO)
```

Log levels used:
- `INFO`: Successful operations and general information
- `WARNING`: Non-critical issues (e.g., parsing errors for individual elements)
- `ERROR`: Serious errors (e.g., file not found, document loading failed)

## Content Types Supported

- **Headings**: All heading levels (1-6)
- **Paragraphs**: Regular text content
- **Lists**: Both bullet and numbered lists
- **Tables**: Converted to HTML format
- **Mixed content**: Combinations of the above

## Best Practices

1. **Always check processing status** before using the structure
2. **Use appropriate logging levels** for your application
3. **Handle empty structures gracefully** in your application
4. **Validate file existence** before processing if needed
5. **Use type hints** when working with the returned structures

## Examples

See the following example files:
- `usage_examples.py`: Comprehensive usage examples
- `test_unstructured.py`: Testing with different document types

## Requirements

- Python 3.7+
- python-docx
- Standard library modules: json, logging, typing, dataclasses

## License

This code is provided as-is for educational and development purposes.
