"""
Data processing functions for test case generation and export.
Cleaned version - only hierarchical generation supported.
"""

import pandas as pd
import streamlit as st
import os
import traceback
from io import BytesIO
from typing import List, Dict, Any
from test_case.analyzer import extract_function_list, parse_test_case_response, create_live_test_case_table
from ai.ollama_client import call_ollama_api, generate_hierarchical_test_case_prompt
# Import multi-pass function - will be checked at runtime
try:
    from ai.ollama_client import generate_test_cases_multi_pass
except (ImportError, AttributeError):
    generate_test_cases_multi_pass = None
from ai.template_analyzer import (
    generate_template_analysis_prompt, 
    parse_template_analysis_response,
    validate_template_structure,
    create_default_test_case_structure,
    generate_test_case_template_info
)
from utils.helpers import log_detailed_message, update_function_status
from utils.database import get_template_cache


def analyze_excel_template_structure(excel_file, force_reanalyze: bool = False) -> Dict[str, Any]:
    """
    Analyze Excel template and create standardized test case structure using AI.
    Uses SQLite cache to avoid re-analyzing the same files.
    
    Args:
        excel_file: Uploaded Excel file
        force_reanalyze: If True, skip cache and force AI analysis
        
    Returns:
        Dictionary containing analyzed template structure and field mapping
    """
    try:
        # Get template cache instance
        cache = get_template_cache()
        
        # Debug: Print cache info
        # Try to load from cache first (unless forced to reanalyze)
        if not force_reanalyze:
            log_detailed_message("🔍 Kiểm tra cache cho template...")
            cached_analysis = cache.load_template_analysis(excel_file)
            
            if cached_analysis:
                log_detailed_message(f"✅ Tìm thấy template trong cache: {cached_analysis.get('cached_filename', 'Unknown')}")
                log_detailed_message(f"📅 Cached lúc: {cached_analysis.get('cached_at', 'Unknown')}")
                
                # Verify cache integrity
                if cached_analysis.get('success', False):
                    log_detailed_message("🚀 Sử dụng template analysis từ cache")
                    return cached_analysis
                else:
                    log_detailed_message("⚠️ Template cached nhưng không thành công, sẽ phân tích lại")
    
        
        # Read Excel file to get column information
        df = pd.read_excel(excel_file, nrows=10)  # Read only first 5 rows for analysis
        excel_columns = df.columns.tolist()
        
        # Convert sample data to list of dictionaries
        sample_data = []
        for _, row in df.iterrows():
            sample_row = {}
            for col in excel_columns:
                sample_row[col] = str(row[col]) if pd.notna(row[col]) else ""
            sample_data.append(sample_row)
        
        
        # Generate AI prompt for template analysis
        analysis_prompt = generate_template_analysis_prompt(excel_columns, sample_data)
        
        
        # Call AI to analyze template structure
        response = call_ollama_api(analysis_prompt, stream=False, section_title="Template Analysis", section_path="Excel Template")
        
        if not response:
            log_detailed_message("❌ AI không trả lời, sử dụng cấu trúc mặc định", "error")
            default_structure = create_default_test_case_structure()
            # Save failed analysis to cache
            cache.save_template_analysis(excel_file, default_structure)
            return default_structure
        
        log_detailed_message("✅ AI đã phân tích xong template")
        
        # Parse AI response
        template_analysis = parse_template_analysis_response(response)
        
        # Validate and enhance the analysis (pass original Excel columns for validation)
        validated_analysis = validate_template_structure(template_analysis, excel_columns)
        
        if validated_analysis.get('success', False):
            log_detailed_message("✅ Template được phân tích thành công")
            
            # Store additional info for later use
            validated_analysis['excel_columns'] = excel_columns
            validated_analysis['sample_data'] = sample_data[:2]  # Keep only 2 samples
            
            log_detailed_message("💾 Lưu kết quả phân tích vào cache...")
            cache_saved = cache.save_template_analysis(excel_file, validated_analysis)
            if cache_saved:
                log_detailed_message("✅ Đã lưu template analysis vào cache")
            else:
                log_detailed_message("⚠️ Không thể lưu vào cache, nhưng analysis vẫn khả dụng")
            
            return validated_analysis
        else:
            print(f"🔍 DEBUG - FLOW: Analysis failed, saving default structure to cache")
            log_detailed_message("⚠️ Phân tích template thất bại, sử dụng cấu trúc mặc định", "warning")
            default_structure = create_default_test_case_structure()
            # Save failed analysis to cache
            cache.save_template_analysis(excel_file, default_structure)
            return default_structure
        
    except Exception as e:
        print(f"🔍 DEBUG - FLOW: Exception during template analysis: {str(e)}")
        return create_default_test_case_structure()


def create_excel_file(test_cases: list, template_analysis: dict = None) -> BytesIO:
    """Create Excel file from test cases data using analyzed template structure.
    
    Args:
        test_cases: List of test case dictionaries
        template_analysis: Analyzed template structure from analyze_excel_template_structure
        
    Returns:
        BytesIO object containing Excel file
    """
    try:
        # Check if we have analyzed template structure
        if template_analysis and template_analysis.get('success', False):
            test_case_structure = template_analysis.get('test_case_structure', {})
            # Get original Excel columns from template_analysis, not from test_case_structure values
            excel_columns = template_analysis.get('excel_columns', list(test_case_structure.values()))
            
            print(f'test_case_structure:\n {test_case_structure}')
            print(f'excel_columns:\n {excel_columns}')
            formatted_data = []
            
            for tc in test_cases:
                formatted_tc = {}
                
                # Map test case data using analyzed field mapping
                # test_case_structure maps: JSON key (camelCase) -> Excel column name (description)
                # We need to map: JSON key -> Excel column name
                
                for json_key, excel_col in test_case_structure.items():
                    # Try to get value using JSON key first
                    value = tc.get(json_key, "")
                    
                    # If not found, try common variations
                    if not value or value == "":
                        # Try camelCase variations
                        if json_key == "testCaseName":
                            value = tc.get("Test_Case_Name", tc.get("testCaseName", ""))
                        elif json_key == "testSteps":
                            value = tc.get("Test_Steps", tc.get("testSteps", ""))
                        elif json_key == "priority":
                            value = tc.get("Priority", tc.get("priority", ""))
                        elif json_key == "expectedResult":
                            value = tc.get("Result", tc.get("expectedResult", ""))
                        elif json_key == "section":
                            value = tc.get("Section", tc.get("section", ""))
                    
                    # If still empty, keep it empty (don't fill with default values)
                    if not value or value == "":
                        formatted_tc[excel_col] = ""  # Keep empty if no information
                        continue
                    
                    # Handle list values (like testSteps)
                    if isinstance(value, list):
                        if len(value) > 0:
                            value = "\n".join([f"{i+1}. {step}" if not str(step).startswith(f"{i+1}") else str(step) 
                                              for i, step in enumerate(value)])
                        else:
                            value = ""  # Empty list = empty string
                    
                    formatted_tc[excel_col] = value
                
                formatted_data.append(formatted_tc)
            
            # Ensure column order matches original Excel template
            df = pd.DataFrame(formatted_data, columns=excel_columns)
            
        else:
            # No template analysis - use default structure
            formatted_data = []
            
            for tc in test_cases:
                formatted_tc = {}
                
                # Use test case keys as-is for columns
                for key, value in tc.items():
                    formatted_tc[key] = value
                
                formatted_data.append(formatted_tc)
            
            # Create DataFrame with all available columns
            df = pd.DataFrame(formatted_data)
        
        # Create Excel file in memory
        output = BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, sheet_name='Test_Cases', index=False)
            
            # Get the xlsxwriter workbook and worksheet objects
            workbook = writer.book
            worksheet = writer.sheets['Test_Cases']
            
            # Add formatting for headers
            header_format = workbook.add_format({
                'bold': True,
                'text_wrap': True,
                'valign': 'top',
                'align': 'center',
                'fg_color': '#D7E4BC',
                'border': 1,
                'font_size': 11
            })
            
            # Add formatting for data cells
            data_format = workbook.add_format({
                'text_wrap': True,
                'valign': 'top',
                'align': 'left',
                'border': 1,
                'font_size': 10
            })
            
            # Add formatting for list/steps cells (for better readability)
            steps_format = workbook.add_format({
                'text_wrap': True,
                'valign': 'top',
                'align': 'left',
                'border': 1,
                'font_size': 10,
                'bg_color': '#F8F9FA'
            })
            
            # Write headers with formatting
            for col_num, value in enumerate(df.columns.values):
                worksheet.write(0, col_num, value, header_format)
            
            # Apply data formatting to all cells
            for row_num in range(1, len(df) + 1):
                for col_num in range(len(df.columns)):
                    cell_value = df.iloc[row_num-1, col_num]
                    
                    # Convert list values to readable text
                    if isinstance(cell_value, list):
                        cell_value = '\n'.join([f"• {str(item)}" for item in cell_value if str(item).strip()])
                        worksheet.write(row_num, col_num, cell_value, steps_format)
                    else:
                        worksheet.write(row_num, col_num, str(cell_value), data_format)
            
            # Auto-adjust column widths based on content with reasonable limits
            for col_num, column in enumerate(df.columns):
                # Calculate optimal width based on content
                max_width = 15  # Minimum width
                
                # Check header width
                header_width = len(str(column)) + 2
                max_width = max(max_width, header_width)
                
                # Check content width (sample first 10 rows for performance)
                sample_rows = min(10, len(df))
                for row_num in range(sample_rows):
                    cell_value = df.iloc[row_num, col_num]
                    if isinstance(cell_value, list):
                        # For lists, consider average line length
                        if cell_value:
                            avg_line_length = sum(len(str(item)) for item in cell_value) / len(cell_value)
                            content_width = min(avg_line_length + 5, 50)
                        else:
                            content_width = 15
                    else:
                        # For strings, consider line breaks
                        lines = str(cell_value).split('\n')
                        content_width = max(len(line) for line in lines) if lines else 15
                    
                    max_width = max(max_width, min(content_width, 60))  # Cap at 60 chars
                
                # Set reasonable limits
                if max_width < 20:
                    max_width = 20
                elif max_width > 80:
                    max_width = 80
                
                worksheet.set_column(col_num, col_num, max_width)
            
            # Set row heights for better readability
            for row_num in range(len(df) + 1):
                if row_num == 0:
                    # Header row
                    worksheet.set_row(row_num, 25)
                else:
                    # Data rows - calculate height based on content
                    max_lines = 1
                    for col_num in range(len(df.columns)):
                        cell_value = df.iloc[row_num-1, col_num]
                        if isinstance(cell_value, list):
                            lines = len(cell_value)
                        else:
                            lines = len(str(cell_value).split('\n'))
                        max_lines = max(max_lines, lines)
                    
                    # Set row height (15 points per line + padding)
                    row_height = max(20, min(max_lines * 15 + 5, 150))
                    worksheet.set_row(row_num, row_height)
            
            # Freeze the header row
            worksheet.freeze_panes(1, 0)
        
        output.seek(0)
        return output
        
    except Exception as e:
        st.error(f"Lỗi tạo file Excel: {e}")
        return None


def generate_test_cases_from_sections(selected_sections: list, progress_placeholder, model_name: str = "gemma3:latest", template_analysis: dict = None) -> list:
    """Generate test cases from pre-selected sections using hierarchical approach.
    This is the primary and only generation method.
    
    Args:
        selected_sections: List of analyzed sections selected for test generation
        progress_placeholder: Streamlit placeholder for progress updates
        model_name: AI model name to use
        template_analysis: Optional analyzed template structure for output formatting
        
    Returns:
        List of generated test cases
    """
    from ai.ollama_client import generate_hierarchical_test_case_prompt
    
    all_test_cases = []
    
    # Initialize progress tracking
    total_sections = len(selected_sections)
    current_section = 0
    skipped_sections = 0
    
    # Initialize session state
    st.session_state.live_test_cases = []
    if 'test_cases' not in st.session_state:
        st.session_state.test_cases = []
    
    def refresh_generation_monitor(status_override: str = None):
        placeholders = st.session_state.get('generation_monitor_placeholders')
        if not placeholders:
            return
        
        selected_sections_state = st.session_state.get('selected_sections_for_generation') or []
        live_cases = st.session_state.get('live_test_cases', [])
        current_status = status_override or ("Đang chạy" if st.session_state.get('test_generation_status') == "running" else "Hoàn tất")
        
        try:
            placeholders['sections_metric'].metric("Sections đã chọn", len(selected_sections_state))
            placeholders['testcase_metric'].metric("Test case đã tạo", len(live_cases))
            placeholders['status_metric'].metric("Trạng thái", current_status)
        except Exception as placeholder_error:
            log_detailed_message(f"⚠️ Generation monitor update error: {placeholder_error}", "warning")
    
    refresh_generation_monitor("Đang chuẩn bị")
    
    # Validate input
    if not selected_sections or len(selected_sections) == 0:
        log_detailed_message("❌ ERROR: No sections provided for generation!", "error")
        st.error("❌ Không có sections nào để generate test cases!")
        return []
    
    log_detailed_message(f"🚀 Bắt đầu generate test case cho {total_sections} sections đã chọn với hierarchical approach")
    
    # Process each selected section
    for section in selected_sections:
        current_section += 1
        section_title = section.get('title', f'Section {current_section}')
        level = section.get('level', 1)
        full_path = section.get('full_path', section_title)
        
        # Update progress
        progress_percentage = (current_section / total_sections) * 100
        
        with progress_placeholder.container():
            # Overall progress: Section X / Total
            st.markdown(f"### 🔄 Processing Section {current_section}/{total_sections}")
            st.progress(progress_percentage / 100, text=f"Section {current_section}/{total_sections}: {section_title}")
            
            # Current section details
            content_count = len(section.get('content', []))
            children_merged = section.get('merged', False)
            
            st.markdown(f"**📋 Section:** {section_title}")
            st.markdown(f"**📊 Level:** {level}")
            if full_path != section_title:
                st.markdown(f"**🗂️ Full Path:** {full_path}")
            st.markdown(f"**📝 Content Items:** {content_count}")
            if children_merged:
                merged_titles = section.get('merged_children_titles', [])
                st.markdown(f"**🔗 AI Merged:** {len(merged_titles)} children sections")
            
            # Auto-scroll trigger for progress updates
            st.markdown("""
            <script>
            setTimeout(function() {
                const aiArea = document.querySelector('.ai-response-area');
                if (aiArea) {
                    aiArea.scrollTop = aiArea.scrollHeight;
                    // Add smooth animation
                    aiArea.scrollIntoView({ behavior: 'smooth', block: 'end' });
                }
            }, 100);
            </script>
            """, unsafe_allow_html=True)
            
            # Current section progress bar (will be updated during processing)
            section_progress_placeholder = st.empty()
            
            st.markdown("---")
        
        # Update function status
        update_function_status(section_title, "processing")
        
        try:
            log_detailed_message(f"🤖 Đang tạo prompt cho section: {section_title} (Level {level})")
            
            # Create hierarchical context
            parent_context = section.get('parent_context', '')
            hierarchy_context = f"Level {level}: {section_title}"
            if parent_context:
                hierarchy_context = f"{parent_context} > Level {level}: {section_title}"
            
            # OPTION: Use multi-pass generation for maximum coverage
            use_multi_pass = st.session_state.get('use_multi_pass_generation', False)
            
            if use_multi_pass and generate_test_cases_multi_pass is not None:
                # Focus-based multi-pass
                log_detailed_message(f"🔄 Using FOCUS-BASED MULTI-PASS generation for: {section_title}")
                with section_progress_placeholder.container():
                    st.info("🔄 Multi-pass theo góc nhìn: Functional, Negative, Boundary, Security")
                
                def enrich_case_metadata(cases: list):
                    for tc in cases:
                        tc['Level'] = level
                        tc['Full_Path'] = full_path
                        tc['Section_Path'] = hierarchy_context
                        tc['completed'] = True
                
                def handle_pass_update(pass_cases: list):
                    if not pass_cases:
                        return
                    enrich_case_metadata(pass_cases)
                    st.session_state.live_test_cases.extend(pass_cases)
                
                try:
                    multi_pass_stream_placeholder = st.empty()
                    test_cases = generate_test_cases_multi_pass(
                        section, 
                        hierarchy_context, 
                        template_analysis,
                        stream_placeholder=multi_pass_stream_placeholder,
                        model_name=model_name,
                        pass_callback=handle_pass_update
                    )
                except Exception as e:
                    log_detailed_message(f"❌ Focus-based multi-pass error for {section_title}: {str(e)}", "error")
                    update_function_status(section_title, "error")
                    skipped_sections += 1
                    continue
                
                if test_cases and len(test_cases) > 0:
                    log_detailed_message(f"✅ Multi-pass generated {len(test_cases)} test cases for {section_title}")
                    
                    # Ensure metadata present (in case callback didn't run)
                    enrich_case_metadata(test_cases)
                    
                    all_test_cases.extend(test_cases)
                    update_function_status(section_title, "completed")
                    
                    with section_progress_placeholder.container():
                        st.progress(1.0, text=f"✅ Multi-pass completed: {len(test_cases)} test cases")
                    
                    refresh_generation_monitor()
                else:
                    log_detailed_message(f"⚠️ Multi-pass generated 0 test cases for {section_title}", "warning")
                    update_function_status(section_title, "skipped")
                    skipped_sections += 1
                    refresh_generation_monitor()
            
            else:
                # Single-pass generation: Improved prompt with comprehensive analysis
                log_detailed_message(f"📝 Using SINGLE-PASS generation (improved) for: {section_title}")
                
                # Generate hierarchical prompt with template analysis support
                prompt = generate_hierarchical_test_case_prompt(section, hierarchy_context, template_analysis)
                
                # Retry logic for AI processing with max 3 attempts
                max_retries = 3
                test_cases = None
                last_error = None
                
                for attempt in range(1, max_retries + 1):
                    try:
                        log_detailed_message(f"📝 Attempt {attempt}/{max_retries} - Đang gửi prompt cho {section_title} tới AI...")
                        
                        # Update current section progress bar (bottom one)
                        step_progress = (attempt - 1) / max_retries
                        step_text = f"Attempt {attempt}/{max_retries}: Sending AI request..."
                        if attempt > 1:
                            step_text = f"Retry {attempt}/{max_retries}: Sending AI request..."
                        
                        with section_progress_placeholder.container():
                            st.progress(step_progress, text=step_text)
                            if attempt > 1:
                                st.warning(f"🔄 Retry {attempt}/{max_retries} for: {section_title}")
                        
                        # Create streaming placeholder for AI response
                        stream_placeholder = st.empty()
                        
                        # Update progress: AI processing
                        with section_progress_placeholder.container():
                            st.progress((attempt - 0.5) / max_retries, text=f"Attempt {attempt}/{max_retries}: AI processing...")
                        
                        # Call AI with streaming
                        response = call_ollama_api(prompt, model_name, stream_placeholder, section_title, full_path)
                        
                        # Update progress: Parsing response
                        with section_progress_placeholder.container():
                            st.progress(attempt / max_retries, text=f"Attempt {attempt}/{max_retries}: Parsing response...")
                        
                        # Clear streaming display
                        stream_placeholder.empty()
                        
                        # Check for REAL API errors (not JSON content with "error" field names)
                        # Only treat as error if response starts with error keywords or is very short
                        response_stripped = response.strip()
                        is_real_error = (
                            response_stripped.startswith("Error:") or 
                            response_stripped.startswith("API Error:") or
                            response_stripped.startswith("Failed:") or
                            (len(response_stripped) < 50 and "error" in response_stripped.lower() and "{" not in response_stripped)
                        )
                        
                        if is_real_error:
                            log_detailed_message(f"❌ API Error on attempt {attempt} for {section_title}: {response[:200]}", "error")
                            last_error = f"API Error: {response[:200]}"
                            if attempt == max_retries:
                                # Final attempt failed with API error
                                update_function_status(section_title, "error")
                                skipped_sections += 1
                                
                                # Update section progress: API error
                                with section_progress_placeholder.container():
                                    st.progress(1.0, text=f"❌ API Error after {max_retries} attempts")
                                    st.error(f"🔍 API Error: {response[:200]}")
                                break
                            else:
                                # Wait a bit before retry for API errors
                                import time
                                time.sleep(1)
                                continue
                        
                        # Check if AI wants to skip this section
                        elif "SKIP:" in response.upper():
                            log_detailed_message(f"⏭️ AI bỏ qua: {section_title} - Không phải chức năng", "info")
                            update_function_status(section_title, "skipped")
                            skipped_sections += 1
                            
                            # Update section progress: Skipped
                            with section_progress_placeholder.container():
                                st.progress(1.0, text="⏭️ Skipped: Not a testable function")
                            
                            break
                        
                        else:
                            # Try to parse test cases from AI response
                            try:
                                test_cases = parse_test_case_response(response, section_title, template_analysis)
                                
                                if test_cases and len(test_cases) > 0:
                                    # Successfully parsed test cases
                                    log_detailed_message(f"✅ Successfully parsed {len(test_cases)} test cases for {section_title} on attempt {attempt}")
                                    
                                    # Update section progress: Completed
                                    with section_progress_placeholder.container():
                                        st.progress(1.0, text=f"✅ Completed: {len(test_cases)} test cases generated")
                                    
                                    # Add metadata to test cases
                                    for tc in test_cases:
                                        tc['Level'] = level
                                        tc['Full_Path'] = full_path
                                        tc['Section_Path'] = hierarchy_context
                                        tc['completed'] = True
                                        tc['attempt_number'] = attempt  # Track which attempt succeeded
                                    
                                    all_test_cases.extend(test_cases)
                                    
                                    # Update live test cases in session state
                                    st.session_state.live_test_cases.extend(test_cases)
                                    refresh_generation_monitor()
                                    
                                    update_function_status(section_title, "completed")
                                    log_detailed_message(f"✅ Hoàn thành {section_title}: {len(test_cases)} test case (attempt {attempt})")
                                    
                                    # Show success message but don't duplicate progress info
                                    success_msg = f"✅ Completed: {len(test_cases)} test cases"
                                    if attempt > 1:
                                        success_msg += f" (succeeded on attempt {attempt})"
                                        
                                    break  # Successfully processed, exit retry loop
                                
                                else:
                                    # Parsed but no test cases found
                                    last_error = f"No test cases parsed from response"
                                    log_detailed_message(f"⚠️ Attempt {attempt}: Parsed response but no test cases found for {section_title}", "warning")
                                    log_detailed_message(f"🔍 Response preview (first 500 chars): {response[:500]}", "debug")
                                    log_detailed_message(f"🔍 Response length: {len(response)} chars", "debug")
                                    
                                    # Show response preview in UI for debugging
                                    if attempt == max_retries:
                                        with section_progress_placeholder.container():
                                            st.warning(f"⚠️ No test cases parsed from response")
                                            with st.expander("🔍 Debug: View AI Response", expanded=False):
                                                st.text_area("AI Response:", response[:2000], height=300, key=f"debug_response_{section_title}")
                                    
                                    if attempt == max_retries:
                                        # Final attempt - treat as skip
                                        update_function_status(section_title, "skipped")
                                        skipped_sections += 1
                                        log_detailed_message(f"⏭️ Bỏ qua {section_title}: Không tạo được test case sau {max_retries} attempts")
                                        
                                        # Update section progress: Failed after retries
                                        with section_progress_placeholder.container():
                                            st.progress(1.0, text=f"⚠️ No test cases after {max_retries} attempts")
                                    else:
                                        continue  # Try again
                            
                            except Exception as parse_error:
                                # Parsing error - log and retry
                                last_error = f"Parse error: {str(parse_error)}"
                                log_detailed_message(f"❌ Parse error on attempt {attempt} for {section_title}: {str(parse_error)}", "error")
                                log_detailed_message(f"🔍 AI Response that failed to parse: {response[:500]}{'...' if len(response) > 500 else ''}", "debug")
                                
                                # Show parse error in UI for debugging
                                if attempt == max_retries:
                                    with section_progress_placeholder.container():
                                        st.error(f"❌ Parse error: {str(parse_error)}")
                                        with st.expander("🔍 Debug: View AI Response & Error", expanded=False):
                                            st.text_area("AI Response:", response[:2000], height=300, key=f"parse_error_response_{section_title}")
                                            st.code(f"Error: {str(parse_error)}\n{traceback.format_exc()}")
                                
                                if attempt == max_retries:
                                    # Final attempt failed
                                    update_function_status(section_title, "error")
                                    skipped_sections += 1
                                    
                                    # Update section progress: Parse error
                                    with section_progress_placeholder.container():
                                        st.progress(1.0, text=f"❌ Parse error after {max_retries} attempts")
                                        st.error(f"🔍 Parse error: {str(parse_error)}")
                                else:
                                    # Wait a bit before retry for parse errors
                                    import time
                                    time.sleep(1)
                                    continue  # Try again
                    
                    except Exception as api_error:
                        # General API call error
                        last_error = f"API call error: {str(api_error)}"
                        log_detailed_message(f"❌ API call error on attempt {attempt} for {section_title}: {str(api_error)}", "error")
                        
                        if attempt == max_retries:
                            # Final attempt failed
                            update_function_status(section_title, "error")
                            skipped_sections += 1
                            
                            # Update section progress: API error
                            with section_progress_placeholder.container():
                                st.progress(1.0, text=f"❌ API error after {max_retries} attempts")
                                st.error(f"🔍 API error: {str(api_error)}")
                        else:
                            # Wait before retry for API call errors
                            import time
                            time.sleep(2)
                            continue  # Try again
                    
        except Exception as e:
            log_detailed_message(f"❌ Unexpected error when processing {section_title}: {str(e)}", "error")
            update_function_status(section_title, "error")
            skipped_sections += 1
            
            with progress_placeholder.container():
                st.error(f"❌ Unexpected error: {section_title} - {str(e)}")
    
    # Show final summary
    with progress_placeholder.container():
        st.success(f"🎉 Hoàn thành tạo test case cho các sections đã chọn!")
        st.info(f"📊 Đã xử lý {current_section} sections")
        st.info(f"⏭️ Bỏ qua {skipped_sections} sections không cần test")
        st.info(f"📝 Tổng số test case đã tạo: {len(all_test_cases)}")
        
        # Summary by level
        by_level = {}
        for tc in all_test_cases:
            level = tc.get('Level', 1)
            by_level[level] = by_level.get(level, 0) + 1
        
        if by_level:
            level_summary = ", ".join([f"Level {level}: {count}" for level, count in sorted(by_level.items())])
            st.info(f"📊 Phân bố theo cấp độ: {level_summary}")
    
    log_detailed_message(f"🎉 Hoàn thành! Tổng cộng {len(all_test_cases)} test case được tạo từ {total_sections} sections đã chọn")
    
    # Store final results in session state to ensure they display
    st.session_state.test_cases = all_test_cases
    st.session_state.test_generation_status = "completed"
    
    # Log final summary
    log_detailed_message(f"🎉 FINAL SUMMARY: Generated {len(all_test_cases)} test cases from {total_sections} sections")
    
    # Show warning if no test cases generated
    if len(all_test_cases) == 0:
        log_detailed_message("⚠️ WARNING: No test cases were generated!", "warning")
        with progress_placeholder.container():
            st.warning("⚠️ Không có test case nào được tạo. Có thể do:")
            st.markdown("""
            - Sections không phải là chức năng testable
            - AI không trả về đúng format JSON
            - Lỗi trong quá trình parsing
            - Xem logs để biết chi tiết
            """)
    
    refresh_generation_monitor("Hoàn tất")
    # Force UI refresh to show results
    st.rerun()
    
    return all_test_cases


# Alias for backward compatibility
def generate_hierarchical_test_cases(structure: list, progress_placeholder, model_name: str = "gemma3:latest", template_analysis: dict = None) -> list:
    """Generate test cases using hierarchical approach with template structure analysis.
    
    Args:
        structure: Document structure from JSON
        progress_placeholder: Streamlit placeholder for progress updates
        model_name: AI model to use for generation
        template_analysis: Optional analyzed template structure from analyze_excel_template_structure
        
    Returns:
        List of all generated test cases
    """
    from test_case.analyzer import extract_all_sections_by_level
    
    # Extract all sections with AI merge enabled
    log_detailed_message("🚀 Extracting sections with AI merge enabled...")
    all_sections = extract_all_sections_by_level(structure, merge_children_content=True)
    
    # Filter only testable sections
    testable_sections = [s for s in all_sections if s.get('is_testable', True)]
    
    # Use the main generation function
    return generate_test_cases_from_sections(testable_sections, progress_placeholder, model_name, template_analysis)


# Remove legacy functions - only keep hierarchical
