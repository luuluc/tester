# 🧠 Feedback Learning System - Flow và Logging

## 📋 Tổng Quan

Hệ thống feedback được thiết kế để AI tự học và cải thiện từ góp ý của người dùng. Mỗi lần bạn gửi feedback, AI sẽ:

1. **Phân tích feedback mới** và kiểm tra với kinh nghiệm đã học
2. **Tạo kinh nghiệm mới** (chỉ khi feedback có giá trị, không tổng hợp lại tất cả)
3. **Lưu vào database** dưới dạng một kinh nghiệm độc lập
4. **Log chi tiết toàn bộ quá trình** để bạn có thể theo dõi

**Lưu ý quan trọng:** AI sẽ KHÔNG tổng hợp lại tất cả feedback cũ. Mỗi feedback sẽ tạo ra MỘT kinh nghiệm mới và độc lập.

## 🔄 Flow Chi Tiết

### 1️⃣ Khi Click "Gửi Feedback"

```
[User] Nhập feedback
   ↓
[streamlit_app.py] Nhận feedback + AI config
   ↓
[FeedbackAnalyzer.process_and_store_feedback()]
   ↓
[FeedbackAnalyzer.analyze_feedback()]
   ├── Lấy kinh nghiệm cũ từ DB
   ├── Tạo prompt phân tích
   ├── Gọi AI API
   ├── Parse response từ AI
   └── Trả về analysis result
   ↓
[Lưu vào database]
   ├── feedback_text: Feedback gốc từ user
   ├── processed_feedback: Kinh nghiệm đã học (learning insight)
   └── ai_analysis: Metadata JSON
   ↓
[Hiển thị kết quả cho user]
```

### 2️⃣ Khi AI Tạo Test Case

```
[User] Chọn section để tạo test case
   ↓
[generate_test_case_prompt()] hoặc [generate_hierarchical_test_case_prompt()]
   ↓
[get_feedback_enhancement()]
   ├── Gọi feedback_db.get_feedback_for_system_prompt()
   ├── Lấy top 10 kinh nghiệm (processed_feedback)
   └── Format: "[CATEGORY] Learning insight"
   ↓
[Thêm vào System Prompt]
   ↓
[AI tạo test case với kinh nghiệm đã học]
```

## 📊 Logging Chi Tiết

### Log File Location

Tất cả logs được lưu tại: `logs/feedback_analysis_YYYYMMDD.log`

Ví dụ: `logs/feedback_analysis_20251005.log`

### Nội Dung Log

#### 1. **Bắt đầu phân tích**
```
================================================================================
🚀 BẮT ĐẦU PHÂN TÍCH FEEDBACK MỚI
================================================================================
📝 Feedback từ user:
[Nội dung feedback từ user]

📚 Số lượng kinh nghiệm hiện có: X
🔍 5 kinh nghiệm gần nhất:
  1. [Kinh nghiệm 1]...
  2. [Kinh nghiệm 2]...
  ...
```

#### 2. **Prompt gửi đến AI**
```
📤 Prompt gửi đến AI:
[Toàn bộ prompt bao gồm kinh nghiệm cũ và feedback mới]
```

#### 3. **Thông tin API Call**
```
🤖 Đang gọi AI API (Provider/Model)...
🔧 API Config: Provider=Ollama, Model=gemma3:latest, URL=http://...
📤 Sending request to API...
📦 Payload overview:
  - Model: gemma3:latest
  - Messages count: 2
  - Stream: False
📦 Full payload preview: {...}
```

#### 4. **Response từ AI**
```
📨 Response Status Code: 200
✅ API call successful
📦 Raw response JSON: {...}
🔍 Standard format detected, extracted from: message.content
📥 Response content length: XXX characters
📥 AI Response (RAW):
[Response đầy đủ từ AI]
```

#### 5. **Kết quả Parse**
```
🔄 Kết quả sau khi parse:
  - Has Learning: True/False
  - Should Update: True/False
  - Learning Insight: [Kinh nghiệm MỚI được tạo từ feedback này]
```

**Lưu ý:** Nếu AI trả về "SKIP", nghĩa là feedback không có giá trị mới hoặc trùng lặp với kinh nghiệm đã có.

#### 6. **Lưu vào Database**
```
================================================================================
📊 BẮT ĐẦU PIPELINE XỬ LÝ VÀ LƯU FEEDBACK
================================================================================

💡 KINH NGHIỆM MỚI ĐÃ HỌC:
📝 [Nội dung kinh nghiệm]

💾 Đang lưu vào database...
✅ Lưu thành công! Feedback ID: XXX
================================================================================
🎉 HOÀN TẤT XỬ LÝ FEEDBACK
================================================================================
```

## 🔍 Debug Issues

### Issue 1: Response content length = 0

**Triệu chứng:**
```
📨 Response Status Code: 200
📥 Response content length: 0 characters
⚠️ Không nhận được response từ AI
```

**Nguyên nhân:** API trả về JSON với structure khác so với expected

**Giải pháp:** 
- Kiểm tra log `📦 Raw response JSON` để xem structure thực tế
- Kiểm tra log `📋 Available keys in response` để biết các keys có sẵn
- Code đã tự động thử nhiều format: `message.content`, `response`, `text`, `choices[0].message.content`

### Issue 2: Không có kinh nghiệm mới

**Triệu chứng:**
```
⚠️ Không có kinh nghiệm mới để học từ feedback này
```

**Nguyên nhân:** 
- AI trả về "SKIP" (feedback không có giá trị mới hoặc trùng lặp)
- Feedback quá ngắn (< 10 ký tự)
- Feedback đã tồn tại trong danh sách kinh nghiệm

**Giải pháp:**
- Kiểm tra `📥 AI Response (RAW)` để xem AI response thực tế
- Feedback cần cung cấp thông tin cụ thể, có giá trị MỚI
- Xem danh sách kinh nghiệm hiện có để tránh trùng lặp

### Issue 3: Chức năng xóa không hoạt động

**Đã sửa!** Function `delete_feedback()` đã được thêm vào `utils/feedback_db.py`

**Cách sử dụng:**
- Click nút "🗑️ Delete" bên cạnh mỗi feedback
- Click lần 2 để xác nhận xóa
- Feedback sẽ bị xóa vĩnh viễn khỏi database (hard delete)

## 📁 Database Schema

### Table: feedback

| Column | Type | Description |
|--------|------|-------------|
| id | SERIAL | Primary key |
| feedback_text | TEXT | Feedback gốc từ user |
| processed_feedback | TEXT | **Kinh nghiệm MỚI được tạo từ feedback này** |
| ai_analysis | TEXT | Metadata JSON |
| category | VARCHAR | Loại feedback (mặc định: "learning") |
| priority | INTEGER | Độ ưu tiên (mặc định: 1) |
| is_active | BOOLEAN | Trạng thái active |
| created_at | TIMESTAMP | Thời gian tạo |
| updated_at | TIMESTAMP | Thời gian cập nhật |

**Lưu ý quan trọng:** 
- `processed_feedback` chứa **kinh nghiệm MỚI** được tạo từ feedback cụ thể đó
- Mỗi feedback tạo ra MỘT kinh nghiệm độc lập, KHÔNG tổng hợp lại tất cả
- Đây là nội dung được AI sử dụng khi tạo test case
- `feedback_history` table đã bị xóa - không còn tracking lịch sử thay đổi

## 🎯 Xem Logs Khi Debug

### 1. Xem log realtime khi chạy app:

```bash
# Trên Linux/Mac
tail -f logs/feedback_analysis_*.log

# Trên Windows PowerShell
Get-Content logs\feedback_analysis_*.log -Wait -Tail 50
```

### 2. Xem toàn bộ log của ngày hôm nay:

```bash
# Linux/Mac
cat logs/feedback_analysis_$(date +%Y%m%d).log

# Windows PowerShell
type logs\feedback_analysis_$(Get-Date -Format "yyyyMMdd").log
```

### 3. Tìm lỗi trong log:

```bash
# Tìm các dòng ERROR
grep "ERROR" logs/feedback_analysis_*.log

# Tìm các dòng WARNING
grep "WARNING" logs/feedback_analysis_*.log
```

## 🚀 Tips để AI học tốt hơn

1. **Feedback cụ thể:** 
   - ❌ "Test case không tốt"
   - ✅ "Test case thiếu bước kiểm tra validation đầu vào"

2. **Feedback có hướng dẫn:**
   - ❌ "Cần cải thiện"
   - ✅ "Cần thêm test case negative (invalid input) cho mỗi chức năng"

3. **Feedback có context:**
   - ❌ "Thêm edge cases"
   - ✅ "Với chức năng tìm kiếm, cần test: input rỗng, input quá dài (>1000 ký tự), ký tự đặc biệt"

4. **Feedback không trùng lặp:**
   - AI sẽ merge với kinh nghiệm cũ
   - Nếu feedback mới không có gì bổ sung, AI sẽ trả về "SKIP"

## 📞 Support

Nếu gặp vấn đề, hãy:
1. Kiểm tra log file tại `logs/feedback_analysis_YYYYMMDD.log`
2. Tìm section bắt đầu bằng `🚀 BẮT ĐẦU PHÂN TÍCH FEEDBACK MỚI`
3. Xem chi tiết từng bước để tìm lỗi
4. Đặc biệt chú ý: `📦 Raw response JSON` và `📋 Available keys in response`

