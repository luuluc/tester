# 📊 Hướng Dẫn Context Logging

## 🎯 Mục Đích

Context Logging giúp bạn theo dõi chi tiết quá trình xử lý ngữ cảnh giữa các session khi sinh test case tự động, bao gồm:
- Khi context được tạo từ các phần trước
- Khi context được đẩy vào prompt của phần sau
- Khi context được lưu lại để sử dụng cho các phần tiếp theo
- Thông tin test case được sinh ra có liên kết với context như thế nào

## 📁 Cấu Trúc File Log

Tất cả log được lưu trong thư mục `logs/` với định dạng tên file theo ngày:

### 1. `context_awareness_YYYYMMDD.log`
**File log chính** chứa toàn bộ thông tin chi tiết về quá trình xử lý context.

**Nội dung:**
- 🚀 Khởi tạo: Log khi bắt đầu xử lý context
- 📝 Tạo context: Log khi tạo context từ các section trước
- ✅ Đẩy context: Log khi context được đẩy vào section hiện tại
- 💾 Lưu context: Log khi lưu summary của section để dùng cho sau
- 📊 Tổng kết: Thống kê tổng thể

**Ví dụ:**
```
2025-10-09 15:54:29 - context_awareness - INFO - ================================================================================
2025-10-09 15:54:29 - context_awareness - INFO - 🚀 BẮT ĐẦU XỬ LÝ CONTEXT - Tổng 5 sections
2025-10-09 15:54:29 - context_awareness - INFO - ================================================================================

2025-10-09 15:54:30 - context_awareness - INFO - 📝 TẠO CONTEXT cho section: Quản lý tài khoản
2025-10-09 15:54:30 - context_awareness - INFO -    └── Số lượng sections trước đó: 1
2025-10-09 15:54:30 - context_awareness - INFO -    └── Context bao gồm:
2025-10-09 15:54:30 - context_awareness - INFO -        • Đăng nhập (Level 1) - 2 flows

2025-10-09 15:54:30 - context_awareness - INFO - ✅ CONTEXT ĐÃ ĐƯỢC ĐẨY VÀO section: Quản lý tài khoản

2025-10-09 15:54:35 - context_awareness - INFO - 💾 LƯU CONTEXT từ section: Quản lý tài khoản
2025-10-09 15:54:35 - context_awareness - INFO -    ├── Test cases: 3
2025-10-09 15:54:35 - context_awareness - INFO -    ├── Main flows: 3
2025-10-09 15:54:35 - context_awareness - INFO -    └── Tổng sections trong context hiện tại: 2
```

### 2. `test_cases_YYYYMMDD.json`
**File JSON** chứa thông tin chi tiết về từng test case được sinh ra.

**Format:**
```json
{
  "timestamp": "2025-10-09T15:54:29.807095",
  "test_case": {
    "name": "TC001 - Xem thông tin tài khoản",
    "priority": "High",
    "steps": ["Đăng nhập", "Vào trang profile", "Kiểm tra thông tin"],
    "related_flows": ["Xem thông tin"],
    "related_sections": ["Đăng nhập"]
  }
}
```

**Ý nghĩa:**
- `related_sections`: Các section trước đó có liên quan (từ context)
- `related_flows`: Các luồng nghiệp vụ liên quan

### 3. `context_metrics_YYYYMMDD.csv`
**File CSV** chứa metrics định lượng cho mỗi section.

**Cột:**
- `timestamp`: Thời gian xử lý
- `section_name`: Tên section
- `processing_time`: Thời gian xử lý (giây)
- `test_case_count`: Số lượng test case sinh ra
- `coverage_rate`: Tỷ lệ bao phủ (%)
- `duplication_rate`: Tỷ lệ trùng lặp (%)
- `related_sections`: Số section liên quan
- `related_flows`: Số luồng liên quan
- `error_count`: Số lỗi gặp phải

### 4. `context_errors_YYYYMMDD.log`
**File log lỗi riêng** để dễ dàng tìm kiếm và phân tích lỗi.

**Format:**
```
[2025-10-09 15:54:29] Không thể parse context từ section trước
Location: Section: Dashboard > Reports
Details: Missing required field: main_flows
```

### 5. `performance_metrics_YYYYMMDD.json`
**File JSON** chứa metrics hiệu suất tổng thể.

**Format:**
```json
{
  "timestamp": "2025-10-09T15:54:29.809456",
  "metrics": {
    "processing_time": 45.5,
    "test_case_count": 15,
    "coverage": 95.5,
    "duplication_rate": 5.2,
    "total_sections": 5,
    "processed_sections": 5,
    "skipped_sections": 0,
    "context_chain_length": 5
  }
}
```

## 🔍 Cách Sử Dụng

### Trong Code Chính

Context logging đã được tích hợp vào `data/processor.py`. Khi bạn chạy quá trình sinh test case thông qua UI (Streamlit), logging sẽ tự động hoạt động.

### Kiểm Tra Log

#### 1. **Theo dõi luồng context**
```bash
# Xem log chính
cat logs/context_awareness_20251009.log

# Lọc chỉ xem phần tạo context
grep "TẠO CONTEXT" logs/context_awareness_20251009.log

# Lọc chỉ xem phần đẩy context
grep "ĐÃ ĐƯỢC ĐẨY VÀO" logs/context_awareness_20251009.log

# Lọc chỉ xem phần lưu context
grep "LƯU CONTEXT" logs/context_awareness_20251009.log
```

#### 2. **Phân tích test case**
```python
import json

# Đọc tất cả test cases
with open('logs/test_cases_20251009.json', 'r', encoding='utf-8') as f:
    for line in f:
        tc = json.loads(line)
        print(f"{tc['test_case']['name']} -> Related sections: {tc['test_case']['related_sections']}")
```

#### 3. **Phân tích metrics**
```python
import pandas as pd

# Đọc metrics
df = pd.read_csv('logs/context_metrics_20251009.csv')

# Tính trung bình
print(f"Trung bình test cases mỗi section: {df['test_case_count'].mean():.2f}")
print(f"Coverage trung bình: {df['coverage_rate'].mean():.2f}%")
print(f"Duplication rate trung bình: {df['duplication_rate'].mean():.2f}%")
```

#### 4. **Kiểm tra lỗi**
```bash
# Xem tất cả lỗi
cat logs/context_errors_20251009.log

# Đếm số lỗi
wc -l logs/context_errors_20251009.log
```

## 🧪 Test Logging

Chạy script test để kiểm tra logging hoạt động:

```bash
python test_context_logging.py
```

Script này sẽ:
- Tạo context logger
- Simulate xử lý 2 sections
- Log test cases, warnings, errors
- Tạo đầy đủ các file log mẫu

## 📈 Các Điểm Logging Quan Trọng

### 1. **Khởi tạo (Start)**
```python
context_logger.logger.info("🚀 BẮT ĐẦU XỬ LÝ CONTEXT - Tổng X sections")
```
- Cho biết bắt đầu xử lý
- Tổng số sections cần xử lý

### 2. **Tạo Context (Context Creation)**
```python
context_logger.logger.info("📝 TẠO CONTEXT cho section: [section_name]")
context_logger.logger.info("   └── Số lượng sections trước đó: X")
```
- Cho biết section nào đang được xử lý
- Context được tạo từ bao nhiêu section trước đó
- Danh sách các section trong context

### 3. **Đẩy Context (Context Injection)**
```python
context_logger.logger.info("✅ CONTEXT ĐÃ ĐƯỢC ĐẨY VÀO section: [section_name]")
```
- Xác nhận context đã được đẩy vào prompt thành công
- Log DEBUG level hiển thị nội dung context đầy đủ

### 4. **Lưu Context (Context Storage)**
```python
context_logger.logger.info("💾 LƯU CONTEXT từ section: [section_name]")
context_logger.logger.info("   ├── Test cases: X")
context_logger.logger.info("   ├── Main flows: X")
context_logger.logger.info("   └── Tổng sections trong context hiện tại: X")
```
- Cho biết context summary được lưu
- Thông tin về test cases và flows
- Độ dài chain hiện tại

### 5. **Test Case Generation**
```python
context_logger.log_test_case_generation({
    'name': 'TC001 - Test name',
    'priority': 'High',
    'steps': [...],
    'related_flows': [...],
    'related_sections': [...]
})
```
- Log mỗi khi test case được sinh ra
- Bao gồm thông tin liên kết với context

### 6. **Tổng Kết (Summary)**
```python
context_logger.logger.info("📊 TỔNG KẾT XỬ LÝ CONTEXT")
context_logger.logger.info("✅ Sections đã xử lý: X/Y")
context_logger.logger.info("📝 Tổng test cases: Z")
context_logger.logger.info("🔗 Context chain length: N sections")
```
- Thống kê tổng thể
- Performance metrics

## 🎨 Log Levels

- **DEBUG**: Chi tiết kỹ thuật (nội dung context đầy đủ, file paths)
- **INFO**: Thông tin chính về luồng xử lý
- **WARNING**: Cảnh báo (context quá dài, performance issues)
- **ERROR**: Lỗi xử lý context

## 💡 Tips

### 1. **Kiểm tra context có được truyền đúng không**
Tìm kiếm trong log:
```bash
grep "ĐÃ ĐƯỢC ĐẨY VÀO" logs/context_awareness_*.log
```

### 2. **Xem chain của context**
Tìm các dòng "LƯU CONTEXT" và "Tổng sections trong context hiện tại":
```bash
grep -A 4 "LƯU CONTEXT" logs/context_awareness_*.log
```

### 3. **Phân tích test case có liên kết**
```python
import json

with open('logs/test_cases_20251009.json', 'r', encoding='utf-8') as f:
    for line in f:
        tc = json.loads(line)
        if tc['test_case'].get('related_sections'):
            print(f"✅ {tc['test_case']['name']} có context từ: {tc['test_case']['related_sections']}")
        else:
            print(f"⚠️ {tc['test_case']['name']} không có context liên kết")
```

## 🐛 Troubleshooting

### Không thấy log file được tạo
- Kiểm tra folder `logs/` có tồn tại không
- Kiểm tra quyền ghi vào thư mục
- Xem console có lỗi khởi tạo logger không

### Log bị duplicate
- Logger có thể được khởi tạo nhiều lần
- Kiểm tra code có tạo nhiều ContextLogger instance không

### Context không có trong log
- Kiểm tra level log (phải DEBUG để thấy chi tiết)
- Kiểm tra sections_context có được populate không
- Xem log ERROR để tìm lỗi

## 📞 Hỗ Trợ

Nếu gặp vấn đề:
1. Kiểm tra `logs/context_errors_YYYYMMDD.log`
2. Chạy `test_context_logging.py` để verify logging hoạt động
3. Kiểm tra console output khi chạy generation

---

**Cập nhật:** 2025-10-09  
**Version:** 1.0
