# 🔍 Hướng dẫn Debug khi không gen được test cases

## Các bước kiểm tra

### 1. Kiểm tra AI Response
Khi generation fail, mở expander "🔍 Debug: View AI Response" để xem:
- AI có trả về JSON không?
- JSON có đúng format không?
- Có lỗi gì trong response không?

### 2. Kiểm tra Logs
Xem logs trong console/terminal để thấy:
- Response length
- Parse errors
- JSON extraction attempts

### 3. Các nguyên nhân thường gặp

#### A. AI không trả về JSON
**Triệu chứng:** Response là text thuần, không có JSON
**Giải pháp:** 
- Prompt đã được cải thiện để yêu cầu rõ ràng hơn
- Nếu vẫn lỗi, có thể do model không đủ mạnh → Thử model khác

#### B. JSON không đúng format
**Triệu chứng:** Có JSON nhưng không có key "test_cases"
**Giải pháp:**
- Parser đã được cải thiện để tìm test cases trong nhiều keys khác nhau
- Sẽ tự động tìm trong các keys như: "testCases", "tests", etc.

#### C. Parse error
**Triệu chứng:** JSONDecodeError hoặc parse exception
**Giải pháp:**
- Parser đã được cải thiện để fix common JSON issues (trailing commas, etc.)
- Xem error message để biết vấn đề cụ thể

### 4. Cải thiện đã thực hiện

✅ **Improved JSON Parsing:**
- Tìm JSON trong nhiều patterns khác nhau
- Fix common JSON syntax errors
- Tìm test cases trong nhiều keys khác nhau
- Validate test cases có đúng fields không

✅ **Better Error Handling:**
- Debug UI để xem response
- Detailed logging
- Last resort extraction từ text

✅ **Clearer Prompt:**
- Yêu cầu rõ ràng về JSON format
- Nhấn mạnh phải trả về JSON
- Ví dụ cụ thể về format

## Cách test

1. Chạy generation với 1 section đơn giản
2. Nếu fail, xem debug info trong UI
3. Check logs để xem response thực tế
4. Nếu cần, có thể xem file trong `prompt/` folder để xem prompt/response

---

**Lưu ý:** Nếu vẫn không gen được, có thể do:
- Model AI không đủ mạnh để xử lý prompt phức tạp
- Response quá dài bị cắt
- Network/timeout issues

Hãy thử với model mạnh hơn hoặc giảm số lượng test cases yêu cầu trong prompt.

