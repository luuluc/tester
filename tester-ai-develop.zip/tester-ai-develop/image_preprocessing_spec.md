# 📋 Đặc tả chức năng: Tiền xử lý hình ảnh sexy

## 📊 Bảng thông tin chức năng

| **Thành phần** | **Chi tiết** |
|----------------|--------------|
| **Tên chức năng** | Tiền xử lý hình ảnh sexy |
| **Mô tả** | Tính năng này thực hiện việc xử lý hình ảnh trước khi cho vào model để nhận diện. Chức năng này rất quan trọng trong việc xử lý ảnh cho đúng chuẩn đầu vào của model. |
| **Đường dẫn** | `/sensitive-detection/detect-url` |
| **Tác nhân** | Quản trị hệ thống / Lập trình viên |

## 🔄 Luồng xử lý

### 📋 Luồng cơ bản

| **Bước** | **Mô tả** | **Chi tiết kỹ thuật** |
|----------|-----------|----------------------|
| **1. API tiếp nhận hình ảnh** | Kiểm tra và xác thực input | • Validate file format (JPG, PNG, WEBP)<br/>• Kiểm tra MIME type<br/>• Validate file size (< 10MB) |
| | **Điều kiện phân nhánh:** | • Nếu là file ảnh → Chuyển bước tiếp theo<br/>• Nếu không phải file ảnh → Trả về lỗi định dạng |
| **2. Chuẩn hóa kích thước, tỉ lệ ảnh** | Resize ảnh về kích thước chuẩn | • Sử dụng hàm resize<br/>• Đưa ảnh về cùng kích thước (224x224 hoặc 299x299)<br/>• Maintain aspect ratio |
| **3. Chuẩn hóa pixel** | Xử lý giá trị pixel | • Convert ảnh về dạng tensor<br/>• Chuyển giá trị pixel từ [0, 255] → [0, 1]<br/>• Normalize theo mean và std chuẩn |
| **4. Augmentation nhẹ** | Tăng cường dữ liệu nhẹ | • Random horizontal flip (50%)<br/>• Random rotation (±5°)<br/>• Color jittering nhẹ<br/>• Mục đích: Giảm noise trước khi đưa vào model |
| **5. Biến đổi thành tensor batch** | Chuẩn bị input cho model | • Convert numpy array → PyTorch tensor<br/>• Add batch dimension<br/>• Transpose từ HWC → CHW |
| **6. Model nhận diện ảnh sexy** | Chạy inference | • Load pre-trained model<br/>• Forward pass<br/>• Trả về confidence score |

### 🔀 Luồng thay thế

| **Điều kiện** | **Hành động** | **Lý do** |
|---------------|---------------|-----------|
| **Ảnh đầu vào đã đúng kích thước** | Bỏ qua bước resize | Tối ưu performance |
| **Hệ thống chạy ở chế độ fast inference** | Bỏ qua augmentation | Tăng tốc độ xử lý |
| **Ảnh không phải RGB** | Convert về RGB trước khi normalize | Đảm bảo format chuẩn |

### ⚠️ Luồng ngoại lệ

| **Lỗi** | **Xử lý** | **HTTP Status** |
|---------|-----------|------------------|
| **Ảnh bị hỏng hoặc không đọc được** | Trả về lỗi | 400 Bad Request |
| **URL ảnh không tồn tại** | Trả về lỗi | 404 Not Found |
| **Định dạng ảnh không hỗ trợ** | Trả về lỗi | 415 Unsupported Media Type |
| **Lỗi trong quá trình xử lý** | Trả về lỗi hệ thống | 500 Internal Server Error |

## 📋 Điều kiện

### ✅ Điều kiện trước (Pre-conditions)

| **Điều kiện** | **Mô tả** | **Validation** |
|---------------|------------|----------------|
| **Người dùng có quyền gọi API** | Authentication & Authorization | • Kiểm tra JWT token<br/>• Validate user permissions |
| **Hình ảnh đầu vào hợp lệ** | Input validation | • File size < 10MB<br/>• Supported format (JPG, PNG, WEBP)<br/>• Valid image data |
| **Model đã được load sẵn** | System readiness | • Model weights loaded<br/>• GPU/CPU resources available |

### ✅ Điều kiện sau (Post-conditions)

| **Kết quả** | **Mô tả** | **Validation** |
|-------------|------------|----------------|
| **Ảnh được chuẩn hóa thành tensor** | Output format | • Tensor shape: [batch_size, channels, height, width]<br/>• Values normalized to [0, 1]<br/>• Compatible with model input |
| **Hệ thống sẵn sàng gọi chức năng tiếp** | System state | • Model ready for inference<br/>• Next function: nhận diện ảnh sexy |

## 📋 Business Rules

| **Rule** | **Mô tả** | **Implementation** |
|----------|-----------|-------------------|
| **Ảnh đầu vào phải ở định dạng chuẩn** | Format requirements | • Support: JPG, PNG, WEBP<br/>• Reject: GIF, BMP, TIFF |
| **Kích thước đầu vào sau resize luôn cố định** | Size standardization | • Standard size: 224x224 hoặc 299x299<br/>• Maintain aspect ratio<br/>• Padding if necessary |
| **Normalize phải theo đúng mean/std của model** | Normalization standards | • ImageNet stats: mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]<br/>• Consistent across all images |
| **Augmentation nhẹ để tránh kết quả không ổn định** | Data augmentation policy | • Light augmentation only<br/>• Avoid heavy transformations<br/>• Maintain image quality |

## 🔧 Technical Specifications

### 📊 Performance Requirements

| **Metric** | **Target** | **Measurement** |
|------------|------------|----------------|
| **Thời gian xử lý** | < 5 giây/ảnh | End-to-end processing time |
| **Memory usage** | < 2GB RAM | Peak memory consumption |
| **Concurrent requests** | Up to 10 req/s | Throughput capacity |
| **Model accuracy** | > 95% | On test dataset |

### 🛡️ Security & Validation

| **Aspect** | **Requirement** | **Implementation** |
|------------|------------------|-------------------|
| **Input validation** | Strict file type checking | • MIME type validation<br/>• File signature verification |
| **Rate limiting** | Prevent abuse | • Max 100 requests/hour per user<br/>• IP-based throttling |
| **Error handling** | Graceful degradation | • Try-catch for each step<br/>• Detailed error logging |
| **Data privacy** | No image storage | • Process in memory only<br/>• No persistent storage |

## 📈 Monitoring & Logging

| **Event** | **Log Level** | **Information** |
|-----------|---------------|-----------------|
| **Request received** | INFO | User ID, file size, format |
| **Processing steps** | DEBUG | Each preprocessing step |
| **Errors** | ERROR | Error type, stack trace |
| **Performance** | METRIC | Processing time, memory usage |

## 🚀 API Endpoint

```http
POST /sensitive-detection/detect-url
Content-Type: application/json

{
  "image_url": "https://example.com/image.jpg",
  "options": {
    "fast_mode": false,
    "skip_augmentation": false
  }
}
```

**Response:**
```json
{
  "success": true,
  "processed_image": {
    "tensor_shape": [1, 3, 224, 224],
    "normalization_applied": true,
    "augmentation_applied": true
  },
  "ready_for_inference": true
}
```
