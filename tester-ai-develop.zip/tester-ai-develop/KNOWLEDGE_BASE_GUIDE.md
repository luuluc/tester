# 🎓 Knowledge Base System - Hệ thống Học Tập từ Feedback

## 📋 Tổng Quan

Hệ thống Knowledge Base tự động học hỏi từ feedback của người dùng, phân loại theo domain, và áp dụng các kinh nghiệm đã học vào việc tạo test case trong tương lai.

### Luồng Hoạt Động

```
User Submit Feedback
       ↓
AI Phân Tích & Extract
   ├─> Domain Classification (authentication, payment, etc.)
   ├─> Lessons Learned (insights cụ thể)
   ├─> Relevance Score (0.0 - 1.0)
   └─> Tags (keywords)
       ↓
Lưu vào PostgreSQL Database
       ↓
Khi Generate Test Case
   ├─> Detect Domain từ Section Title/Content
   ├─> Retrieve Relevant Lessons by Domain
   └─> Inject vào System Prompt
       ↓
Test Case chất lượng cao hơn
```

---

## 🗄️ Database Schema

### Bảng `feedback` - Các Cột Mới

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| `domain` | TEXT | Domain classification | `authentication`, `payment`, `file_upload` |
| `relevance_score` | FLOAT | Điểm chất lượng/quan trọng (0.0 - 1.0) | `0.85` |
| `tags` | TEXT (JSON) | Keywords để search | `["login", "validation", "error_handling"]` |
| `lessons_learned` | TEXT | Bài học đã trích xuất | "Khi test login, cần kiểm tra cả uppercase/lowercase email" |

---

## 🤖 AI Analysis Process

### 1. Phân Tích Feedback

Khi user gửi feedback, AI thực hiện:

```python
# Input: User feedback text
"Cần thêm test case kiểm tra email không hợp lệ khi đăng nhập"

# AI Analysis Output (JSON):
{
  "status": "ACCEPT",
  "lesson": "Khi tạo test case cho đăng nhập, cần bao gồm validation email format không hợp lệ",
  "domain": "authentication",
  "score": 0.8,
  "tags": ["login", "email_validation", "input_validation"]
}
```

### 2. Domain Classification

**15 Domains được hỗ trợ:**

1. **authentication** - Đăng nhập, xác thực
2. **authorization** - Phân quyền, access control
3. **payment** - Thanh toán, billing
4. **file_upload** - Upload file, import
5. **file_download** - Download, export
6. **data_validation** - Validation dữ liệu
7. **form_submission** - Submit form, nhập liệu
8. **api_integration** - API, integration
9. **database** - Database operations
10. **security** - Bảo mật
11. **performance** - Hiệu năng
12. **ui_interaction** - Giao diện người dùng
13. **notification** - Thông báo, alert
14. **reporting** - Báo cáo, dashboard
15. **workflow** - Quy trình, process
16. **general** - Chung (fallback)

### 3. Relevance Scoring

| Score Range | Meaning | Example |
|-------------|---------|---------|
| **0.9 - 1.0** | Cực kỳ quan trọng, áp dụng rộng | Best practices chung cho mọi feature |
| **0.7 - 0.8** | Quan trọng, specific domain | Validation rules cho domain cụ thể |
| **0.5 - 0.6** | Hữu ích, niche case | Edge cases trong một số trường hợp |
| **0.3 - 0.4** | Tham khảo, rare edge case | Lỗi hiếm gặp hoặc config đặc biệt |

---

## 🔍 Retrieval System

### 1. Domain Detection

Khi generate test case, hệ thống tự động detect domain từ section title và content:

```python
# Example: Section title
"Chức năng đăng nhập hệ thống"

# Auto-detected domain
"authentication"

# Keywords matched
["đăng nhập", "login", "xác thực"]
```

### 2. Lesson Retrieval

```python
# Retrieve relevant lessons
lessons = feedback_db.get_relevant_lessons_by_domain(
    domain='authentication',
    keywords=['login', 'email'],
    limit=5,
    min_score=0.4
)

# Returns top 5 most relevant lessons for authentication domain
```

### 3. Prompt Injection

Lessons được inject vào system prompt khi generate test case:

```
=== 🎓 KINH NGHIỆM ĐÃ HỌC CHO DOMAIN: AUTHENTICATION ===
1. [0.9⭐] Khi test đăng nhập, luôn kiểm tra case-sensitivity của email
2. [0.8⭐] Test case phải bao gồm kiểm tra session timeout
3. [0.7⭐] Đảm bảo test các error messages rõ ràng cho user
...
```

---

## 📊 API Functions

### FeedbackDatabase Methods

#### `add_feedback()`
```python
feedback_id = feedback_db.add_feedback(
    feedback_text="User feedback original",
    processed_feedback="Lesson learned by AI",
    domain="authentication",
    relevance_score=0.8,
    tags='["login", "validation"]',
    lessons_learned="When testing login..."
)
```

#### `get_relevant_lessons_by_domain()`
```python
lessons = feedback_db.get_relevant_lessons_by_domain(
    domain='payment',        # Filter by domain
    keywords=['card', 'cvv'], # Search keywords
    limit=10,                 # Max results
    min_score=0.5             # Minimum quality score
)
```

#### `get_lessons_by_domain_summary()`
```python
# Get formatted string for prompt injection
summary = feedback_db.get_lessons_by_domain_summary(
    domain='authentication',
    limit=5
)

# Returns:
"""
=== 🎓 KINH NGHIỆM ĐÃ HỌC CHO DOMAIN: AUTHENTICATION ===
1. [0.9⭐] Lesson 1...
2. [0.8⭐] Lesson 2...
...
"""
```

---

## 🚀 Usage Guide

### 1. Migration

Chạy migration script để update database:

```bash
python scripts/migrate_feedback_knowledge_base.py
```

### 2. Submit Feedback

Qua UI hoặc API, submit feedback:

```python
from ai.feedback_analyzer import feedback_analyzer

result = feedback_analyzer.process_and_store_feedback(
    feedback_text="Cần thêm test case cho...",
    ai_config={
        'provider': 'Ollama',
        'api_url': 'http://localhost:11434/api/chat',
        'model_name': 'gemma3:latest',
        'api_key': ''
    },
    metadata={'source': 'ui', 'feedback_type': 'improvement'}
)

# Result:
{
    "success": True,
    "feedback_id": 123,
    "analysis": {
        "domain": "authentication",
        "relevance_score": 0.8,
        "tags": ["login", "validation"]
    },
    "learning_experience": "Lesson learned..."
}
```

### 3. Generate Test Cases

Hệ thống tự động inject relevant lessons:

```python
# Trong generate_test_case_prompt()
feedback_enhancement = get_feedback_enhancement(
    section_title="Đăng nhập hệ thống",
    content_preview="User nhập email và password..."
)

# Relevant lessons cho domain 'authentication' được thêm vào prompt
```

---

## 🎯 Benefits

### 1. **Continuous Learning**
- AI tự động học từ mỗi feedback
- Knowledge base phát triển theo thời gian
- Không cần manual training data

### 2. **Context-Aware**
- Lessons được retrieve theo domain
- Chỉ inject lessons relevant
- Giảm noise trong prompt

### 3. **Quality Improvement**
- Test cases cải thiện dần theo feedback
- Áp dụng best practices tự động
- Học từ mistakes và edge cases

### 4. **Scalable**
- PostgreSQL backend có thể handle hàng triệu lessons
- Efficient search với domain + keyword indexing
- Fast retrieval với scoring và filtering

---

## 🔧 Configuration

### Domain Keywords

Có thể custom domain detection trong `ai/ollama_client.py`:

```python
domain_keywords = {
    'your_custom_domain': ['keyword1', 'keyword2', ...],
    ...
}
```

### Score Thresholds

Điều chỉnh min_score khi retrieve:

```python
# Strict: Chỉ lấy lessons chất lượng cao
lessons = feedback_db.get_relevant_lessons_by_domain(
    domain='authentication',
    min_score=0.7  # Only high-quality lessons
)

# Relaxed: Lấy nhiều lessons hơn
lessons = feedback_db.get_relevant_lessons_by_domain(
    domain='authentication',
    min_score=0.3  # Include more lessons
)
```

---

## 📈 Monitoring

### Check Lessons Count

```python
stats = feedback_db.get_feedback_stats()
print(f"Total lessons: {stats['total']}")
```

### View Lessons by Domain

```python
lessons = feedback_db.get_relevant_lessons_by_domain(
    domain='authentication',
    limit=100
)
print(f"Authentication lessons: {len(lessons)}")
```

### Analyze Lesson Quality

```python
lessons = feedback_db.get_all_active_feedback()
avg_score = sum(l.get('relevance_score', 0) for l in lessons) / len(lessons)
print(f"Average lesson quality: {avg_score:.2f}")
```

---

## 🐛 Troubleshooting

### Issue: AI không extract domain đúng

**Solution:** Update `domain_keywords` trong `detect_domain_from_section()`

### Issue: Lessons không được inject vào prompt

**Debug:**
```python
# Check nếu có lessons
lessons = feedback_db.get_relevant_lessons_by_domain('authentication')
print(f"Found {len(lessons)} lessons")

# Check domain detection
domain = detect_domain_from_section("Section title", "content...")
print(f"Detected domain: {domain}")
```

### Issue: Database migration lỗi

**Solution:**
```bash
# Re-run migration
python scripts/migrate_feedback_knowledge_base.py

# Check PostgreSQL logs
tail -f /var/log/postgresql/postgresql-*.log
```

---

## 🎓 Examples

### Example 1: Authentication Lesson

**User Feedback:**
```
"Test case đăng nhập thiếu kiểm tra email không hợp lệ"
```

**AI Analysis:**
```json
{
  "status": "ACCEPT",
  "lesson": "Khi tạo test case cho đăng nhập, phải bao gồm validation email format (missing @, invalid domain, etc.)",
  "domain": "authentication",
  "score": 0.85,
  "tags": ["login", "email_validation", "input_validation"]
}
```

**Retrieval khi generate test case cho section "Đăng nhập":**
```
=== 🎓 KINH NGHIỆM ĐÃ HỌC CHO DOMAIN: AUTHENTICATION ===
1. [0.9⭐] Khi tạo test case cho đăng nhập, phải bao gồm validation email format
...
```

### Example 2: Payment Lesson

**User Feedback:**
```
"Cần test trường hợp card hết hạn"
```

**AI Analysis:**
```json
{
  "status": "ACCEPT",
  "lesson": "Test case thanh toán phải kiểm tra card expiry date (hết hạn, sắp hết hạn, future date)",
  "domain": "payment",
  "score": 0.8,
  "tags": ["payment", "card_validation", "expiry_date"]
}
```

---

## 📚 References

- `ai/feedback_analyzer.py` - AI analysis logic
- `utils/feedback_db.py` - Database operations
- `ai/ollama_client.py` - Domain detection & prompt injection
- `scripts/migrate_feedback_knowledge_base.py` - Migration script

---

✅ **Knowledge Base System is now fully operational!**
