import json
import os
import re
from unstructured.partition.auto import partition
from unstructured.cleaners.core import clean_extra_whitespace
from unstructured.documents.elements import Title, NarrativeText, ListItem

# Function to convert Unstructured elements to JSON structure (legacy support)
def elements_to_json(elements):
    """
    Convert Unstructured elements to a nested JSON structure.
    """
    return elements

# Function to detect heading level and type from Unstructured metadata
def detect_heading_level_from_metadata(element):
    """
    Detect hierarchical level based on Unstructured metadata category_depth and style information.
    Returns: (level, numbering_type, clean_text, number) or None if not a heading
    """
    text = element.get('text', '').strip()
    element_type = element.get('type', '')
    metadata = element.get('metadata', {})
    
    # Try to extract level from Word/document style metadata first
    style_name = metadata.get('style', '').lower()
    if style_name:
        # Extract level from style name (e.g., "Heading 1" -> level 1, "Heading 2" -> level 2)
        style_level_match = re.search(r'(?:heading|header|head|h|tiêu đề)\s*(\d+)', style_name)
        if style_level_match:
            level = int(style_level_match.group(1))
            # Detect numbering from text
            numbering_type = "text"
            number = None
            clean_text = text
            
            # Try to extract numbering pattern
            heading_level_info = detect_heading_level(text)
            if heading_level_info:
                _, numbering_type, clean_text, number = heading_level_info
            
            return level, numbering_type, clean_text, number
    
    # Check category_depth for hierarchy (mainly for lists)
    if 'category_depth' in metadata:
        category_depth = metadata['category_depth']
        
        # Map category_depth to our hierarchy levels
        level = category_depth + 1  # category_depth starts from 0
        
        # Try to detect numbering pattern from text
        numbering_type = "bullet"
        number = None
        clean_text = text
        
        # Detect various numbering patterns
        patterns = [
            (r'^([IVX]+)\.\s*(.+)$', 'roman'),
            (r'^(\d+)\.\s*(.+)$', 'arabic'),
            (r'^([a-z])\.\s*(.+)$', 'letter_lower'),
            (r'^([A-Z])\.\s*(.+)$', 'letter_upper'),
            (r'^\((\d+)\)\s*(.+)$', 'parenthetical'),
            (r'^\(([a-z])\)\s*(.+)$', 'parenthetical_letter'),
            (r'^(\d+)\)\s*(.+)$', 'arabic_paren'),
            (r'^(UC\d+)\s*(.+)$', 'usecase'),  # UC1, UC2, etc.
        ]
        
        for pattern, pattern_type in patterns:
            match = re.match(pattern, text, re.IGNORECASE)
            if match:
                number = match.group(1)
                clean_text = match.group(2).strip()
                numbering_type = pattern_type
                break
        
        return level, numbering_type, clean_text, number
    
    # Check if element_type is ListItem but no category_depth
    if element_type == 'ListItem':
        # Try text-based detection for list items
        heading_level_info = detect_heading_level(text)
        if heading_level_info:
            return heading_level_info
    
    # Fallback to original text-based detection for Title elements
    if element_type == 'Title':
        return detect_heading_level(text)
    
    return None

# Function to detect heading level and type (original function for text-based detection)
def detect_heading_level(text):
    """
    Detect the hierarchical level of a heading and return level info.
    Returns: (level, numbering_type, clean_text, number) or None if not a heading
    """
    text = text.strip()
    
    # Define heading patterns with their levels
    heading_patterns = [
        # Level 1: Roman numerals (I, II, III, IV, V...)
        (r'^([IVX]+)\.\s*(.+)$', 1, 'roman'),
        
        # Level 2: Arabic numbers (1, 2, 3...)
        (r'^(\d+)\.\s*(.+)$', 2, 'arabic'),
        
        # Level 3: Lowercase letters (a, b, c...)
        (r'^([a-z])\.\s*(.+)$', 3, 'letter_lower'),
        
        # Level 4: Parenthetical numbers (1), (2), (3)...
        (r'^\((\d+)\)\s*(.+)$', 4, 'parenthetical'),
        
        # Level 5: Parenthetical letters (a), (b), (c)...
        (r'^\(([a-z])\)\s*(.+)$', 5, 'parenthetical_letter'),
        
        # Alternative patterns
        (r'^(\d+)\)\s*(.+)$', 2, 'arabic_paren'),  # 1) Title
        (r'^([A-Z])\.\s*(.+)$', 3, 'letter_upper'),  # A. Title
        
        # Bullet points and dashes
        (r'^[-•]\s*(.+)$', 6, 'bullet'),
        
        # Chapter/Section keywords
        (r'^(Chapter|Chương|Section|Phần|Part|Mục)\s*(\d+)[\.\:]?\s*(.+)$', 1, 'chapter'),
        
        # Use case patterns
        (r'^(UC\d+)\s*(.+)$', 3, 'usecase'),
    ]
    
    for pattern, level, numbering_type in heading_patterns:
        match = re.match(pattern, text, re.IGNORECASE)
        if match:
            if numbering_type == 'chapter':
                number = match.group(2)
                clean_text = match.group(3).strip()
                return level, numbering_type, clean_text, number
            elif numbering_type in ['bullet']:
                clean_text = match.group(1).strip()
                return level, numbering_type, clean_text, None
            else:
                number = match.group(1)
                clean_text = match.group(2).strip()
                return level, numbering_type, clean_text, number
    
    return None

# Function to determine if an element is a title/header
def is_title_element(element):
    """
    Determine if an element should be treated as a title/header with enhanced hierarchy detection.
    Supports multiple heading types and document formats.
    """
    element_type = element.get('type', '')
    text = element.get('text', '').strip()
    metadata = element.get('metadata', {})
    
    # Skip if no text
    if not text:
        return False
    
    # 1. Check for standard Title element type
    if element_type == 'Title':
        return True
    
    # 2. Check for Header element type (page headers can sometimes be headings)
    if element_type == 'Header':
        # Only if text looks like a heading (short and not typical header content)
        if len(text.split()) <= 15 and not re.search(r'\d+/\d+|\bpage\b', text, re.IGNORECASE):
            return True
    
    # 3. Check for metadata indicating heading style (Word/Google Docs heading styles)
    # Common style names: "Heading 1", "Heading 2", "Title", "Subtitle", etc.
    style_name = metadata.get('style', '').lower()
    if style_name:
        heading_style_patterns = [
            r'heading\s*\d+',  # Heading 1, Heading 2, etc.
            r'title',
            r'subtitle',
            r'header\s*\d+',
            r'head\s*\d+',
            r'h\d+',  # h1, h2, etc.
            r'caption',
            r'tiêu đề',  # Vietnamese
        ]
        if any(re.search(pattern, style_name) for pattern in heading_style_patterns):
            return True
    
    # 4. Check file metadata category (some parsers include this)
    category = metadata.get('category', '').lower()
    if category in ['title', 'heading', 'header', 'subtitle']:
        return True
    
    # 5. Check for ListItem with category_depth (Unstructured hierarchy)
    if element_type == 'ListItem' and 'category_depth' in metadata:
        # Consider ListItems with category_depth as potential headings
        # But filter out very long text that's likely content
        if len(text) > 200:
            return False
        
        # Check if it looks like a heading pattern
        heading_info = detect_heading_level_from_metadata(element)
        if heading_info:
            return True
        
        # Also consider short ListItems as potential headings
        if len(text.split()) <= 10:
            return True
    
    # 6. Check font size metadata (larger fonts often indicate headings)
    font_size = metadata.get('font_size') or metadata.get('text_as_html', {}).get('font_size')
    if font_size:
        try:
            # Convert to float and check if significantly larger (>= 14pt typically indicates heading)
            size_value = float(font_size) if isinstance(font_size, (int, float, str)) else 0
            if size_value >= 14:
                # Large font + reasonable length = likely heading
                if len(text.split()) <= 20:
                    return True
        except (ValueError, TypeError):
            pass
    
    # 7. Check for bold/emphasized text detection
    emphasized_tags = metadata.get('emphasized_text_tags', [])
    emphasized_contents = metadata.get('emphasized_text_contents', [])
    
    if 'b' in emphasized_tags or 'strong' in emphasized_tags:
        # Check if the full text matches the emphasized content
        is_fully_bold = any(emphasized_text.strip() == text for emphasized_text in emphasized_contents)
        
        if is_fully_bold:
            # Must be relatively short (titles are usually concise)
            if len(text) > 150:
                return False
            
            # Title-like patterns
            title_patterns = [
                r'^[A-Z][A-Z\s]{2,}[A-Z]$',  # ALL CAPS title
                r'^[A-Z][^.!?]*[:]$',  # Starts with capital, ends with colon
                r'^(Mục đích|Phạm vi|Nguyên tắc|Quy định|Điều kiện)',  # Vietnamese common headings
                r'^(Chapter|Section|Part|Article|Clause)\s+\d+',  # English section markers
                r'^(Chương|Phần|Điều|Khoản|Mục)\s+\d+',  # Vietnamese section markers
            ]
            
            has_title_pattern = any(re.match(pattern, text, re.IGNORECASE) for pattern in title_patterns)
            
            # Paragraph indicators
            paragraph_indicators = [
                r'[.!?]\s+[A-Z]',  # Multiple sentences
                r'\b(và|hoặc|nhưng|tuy nhiên|do đó|ngoài ra)\b',  # Vietnamese connecting words
                r'[,;]\s+\w+',  # Contains commas/semicolons with following words
            ]
            
            has_paragraph_indicators = any(re.search(pattern, text, re.IGNORECASE) for pattern in paragraph_indicators)
            
            # Word count check
            word_count = len(text.split())
            is_reasonable_length = word_count <= 15
            
            # Ends like title
            ends_like_title = not text.endswith(('.', '!', '?')) or text.endswith(':')
            
            # Scoring
            title_score = sum([
                has_title_pattern,
                not has_paragraph_indicators,
                is_reasonable_length,
                ends_like_title
            ])
            
            return title_score >= 3 or has_title_pattern
    
    # 8. Check for ALL CAPS text (often used for headings)
    if text.isupper() and len(text.split()) <= 12:
        # ALL CAPS + short = likely heading
        return True
    
    return False

# Helper function to analyze title detection (for debugging)
def analyze_title_candidates(elements, debug=False):
    """
    Analyze potential title candidates and provide debugging information.
    """
    candidates = []
    
    for i, element in enumerate(elements):
        text = element.get('text', '').strip()
        metadata = element.get('metadata', {})
        emphasized_tags = metadata.get('emphasized_text_tags', [])
        emphasized_contents = metadata.get('emphasized_text_contents', [])
        
        if 'b' in emphasized_tags and text:
            is_title = is_title_element(element)
            
            analysis = {
                "index": i,
                "text": text,
                "is_detected_as_title": is_title,
                "text_length": len(text),
                "word_count": len(text.split()),
                "emphasized_contents": emphasized_contents,
                "is_fully_bold": any(emphasized_text.strip() == text for emphasized_text in emphasized_contents),
            }
            
            if debug:
                print(f"Element {i}: {'[TITLE]' if is_title else '[NOT TITLE]'}")
                print(f"  Text: {text[:100]}{'...' if len(text) > 100 else ''}")
                print(f"  Fully bold: {analysis['is_fully_bold']}")
                print(f"  Length: {len(text)} chars, {len(text.split())} words")
                print()
            
            candidates.append(analysis)
    
    return candidates

# Function to create hierarchical structure
def create_hierarchical_structure(elements):
    """
    Create a hierarchical structure from document elements based on heading levels.
    Returns a nested structure representing the document hierarchy.
    """
    hierarchy = []
    current_stack = []  # Stack to keep track of current hierarchy
    
    for element in elements:
        element_type = element.get('type', '')
        text = element.get('text', '').strip()
        
        if is_title_element(element):
            # First try metadata-based detection (for Unstructured ListItems)
            heading_info = detect_heading_level_from_metadata(element)
            
            # Fallback to text-based detection
            if not heading_info:
                heading_info = detect_heading_level(text)
            
            if heading_info:
                level, numbering_type, clean_text, number = heading_info
                
                # Create heading node with additional metadata
                heading_node = {
                    "type": "heading",
                    "element_type": element_type,
                    "level": level,
                    "numbering_type": numbering_type,
                    "number": number,
                    "title": clean_text,
                    "full_text": text,
                    "children": [],
                    "content": [],
                    "metadata": element.get('metadata', {})
                }
                
                # Find the correct parent level
                while current_stack and current_stack[-1]["level"] >= level:
                    current_stack.pop()
                
                # Add to appropriate parent
                if current_stack:
                    current_stack[-1]["children"].append(heading_node)
                else:
                    hierarchy.append(heading_node)
                
                current_stack.append(heading_node)
            else:
                # It's a title but doesn't match patterns, treat as level 1
                heading_node = {
                    "type": "heading",
                    "element_type": element_type,
                    "level": 1,
                    "numbering_type": "text",
                    "number": None,
                    "title": text,
                    "full_text": text,
                    "children": [],
                    "content": [],
                    "metadata": element.get('metadata', {})
                }
                
                current_stack = [heading_node]
                hierarchy.append(heading_node)
        else:
            # It's content, add to the current heading
            content_item = {
                "type": element_type,
                "text": text,
                "metadata": element.get('metadata', {})
            }
            
            # Special handling for different element types
            if element_type == "Table":
                # Extract table HTML if available
                metadata = element.get('metadata', {})
                if 'text_as_html' in metadata:
                    content_item["html"] = metadata['text_as_html']
                if 'emphasized_text_contents' in metadata:
                    content_item["table_headers"] = metadata['emphasized_text_contents']
            
            if current_stack:
                current_stack[-1]["content"].append(content_item)
            else:
                # No current heading, create a default one
                default_heading = {
                    "type": "heading",
                    "element_type": "default",
                    "level": 0,
                    "numbering_type": "default",
                    "number": None,
                    "title": "Phần mở đầu",
                    "full_text": "Phần mở đầu",
                    "children": [],
                    "content": [content_item],
                    "metadata": {}
                }
                hierarchy.append(default_heading)
                current_stack = [default_heading]
    
    return hierarchy

# Function to convert hierarchy to flat sections for AI processing
def flatten_hierarchy_for_ai(hierarchy, parent_path=""):
    """
    Convert hierarchical structure to flat sections suitable for AI processing.
    Each section includes its path in the hierarchy and detailed content information.
    """
    sections = []
    
    for i, node in enumerate(hierarchy):
        # Create section path
        if parent_path:
            section_path = f"{parent_path} > {node['title']}"
        else:
            section_path = node['title']
        
        # Collect all content from this node
        content_texts = []
        tables = []
        other_content = []
        
        # Process direct content
        for content_item in node.get('content', []):
            if content_item['text'].strip():
                content_type = content_item.get('type', 'text')
                
                if content_type == 'Table':
                    # Special handling for tables
                    table_info = {
                        "type": "Table",
                        "text": content_item['text'],
                        "html": content_item.get('html', ''),
                        "headers": content_item.get('table_headers', []),
                        "metadata": content_item.get('metadata', {})
                    }
                    tables.append(table_info)
                    content_texts.append(f"[TABLE] {content_item['text']}")
                else:
                    content_texts.append(content_item['text'])
                    other_content.append({
                        "type": content_type,
                        "text": content_item['text'],
                        "metadata": content_item.get('metadata', {})
                    })
        
        # Create section data with enhanced information
        section_data = {
            "id": f"section_{len(sections) + 1}",
            "level": node['level'],
            "element_type": node.get('element_type', 'unknown'),
            "numbering_type": node['numbering_type'],
            "number": node['number'],
            "title": node['title'],
            "full_text": node['full_text'],
            "path": section_path,
            "content": ' '.join(content_texts),
            "content_length": len(' '.join(content_texts)),
            "has_children": len(node.get('children', [])) > 0,
            "children_count": len(node.get('children', [])),
            "direct_content_items": len(node.get('content', [])),
            "tables": tables,
            "table_count": len(tables),
            "other_content": other_content,
            "metadata": node.get('metadata', {})
        }
        
        sections.append(section_data)
        
        # Recursively process children
        if node.get('children'):
            child_sections = flatten_hierarchy_for_ai(node['children'], section_path)
            sections.extend(child_sections)
    
    return sections

# Function to group content by sections/titles (updated for hierarchy)
def group_content_by_sections(elements):
    """
    Group document elements by their hierarchical sections.
    Returns a hierarchical structure and flattened sections.
    """
    # Create hierarchical structure
    hierarchy = create_hierarchical_structure(elements)
    
    # Create flat sections for AI processing
    flat_sections = flatten_hierarchy_for_ai(hierarchy)
    
    return {
        "hierarchy": hierarchy,
        "flat_sections": flat_sections,
        "total_sections": len(flat_sections)
    }

# Function to create structured sections for AI processing
def create_sections_for_ai(sections_data):
    """
    Create a structured format optimized for AI processing with hierarchical information.
    """
    if isinstance(sections_data, dict) and 'flat_sections' in sections_data:
        # New hierarchical format
        sections = sections_data['flat_sections']
        hierarchy = sections_data['hierarchy']
        
        # Save both hierarchy and flat sections
        hierarchy_file = "document_hierarchy.json"
        with open(hierarchy_file, "w", encoding="utf-8") as f:
            json.dump(hierarchy, f, indent=2, ensure_ascii=False)
        
        sections_file = "ai_sections.json"
        with open(sections_file, "w", encoding="utf-8") as f:
            json.dump(sections, f, indent=2, ensure_ascii=False)
        
        return {
            "sections": sections,
            "hierarchy": hierarchy,
            "hierarchy_file": hierarchy_file,
            "sections_file": sections_file,
            "total_sections": len(sections)
        }
    else:
        # Legacy format compatibility
        ai_sections = []
        
        for title, elements in sections_data.items():
            content_texts = []
            list_items = []
            
            for element in elements:
                element_type = element.get('type', '')
                text = element.get('text', '').strip()
                
                if text and element_type != 'PageBreak':
                    content_texts.append(text)
                    
                    if element_type == 'ListItem':
                        list_items.append(text)
            
            full_content = ' '.join(content_texts)
            
            section_data = {
                "title": title,
                "content": full_content,
                "list_items": list_items,
                "element_count": len(elements),
                "content_length": len(full_content)
            }
            
            ai_sections.append(section_data)
        
        output_file = "ai_sections.json"
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(ai_sections, f, indent=2, ensure_ascii=False)
        
        return ai_sections

# Main function to parse document and generate JSON
def parse_document_to_json(file_path, group_by_sections=True):
    """
    Parse a document using Unstructured and return its hierarchical structure as JSON.
    """
    try:
        # Check if file exists
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File {file_path} not found.")

        # Partition the document into elements
        elements = partition(
            filename=file_path,
            strategy="auto"
        )

        json_output = [element.to_dict() for element in elements]
        
        # Save original JSON output
        output_file = file_path.rsplit(".", 1)[0] + "_output.json"
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(json_output, f, indent=2, ensure_ascii=False)
        
        result = {
            "original_json": json_output,
            "output_file": output_file
        }
        
        if group_by_sections:
            # Create hierarchical structure
            sections_data = group_content_by_sections(json_output)
            
            # Create AI-optimized sections with hierarchy
            ai_result = create_sections_for_ai(sections_data)
            
            if isinstance(ai_result, dict):
                # New hierarchical format
                result.update({
                    "hierarchy": ai_result["hierarchy"],
                    "sections": ai_result["sections"],
                    "total_sections": ai_result["total_sections"],
                    "hierarchy_file": ai_result["hierarchy_file"],
                    "sections_file": ai_result["sections_file"]
                })
            else:
                # Legacy format
                result.update({
                    "sections": ai_result,
                    "total_sections": len(ai_result)
                })
        
        return result

    except Exception as e:
        print(f"Error processing document: {str(e)}")
        return None

# Function to generate AI prompts for each section
def generate_ai_prompts_for_sections(sections, task_type="test_case_generation"):
    """
    Generate AI prompts for each section based on the task type.
    """
    prompts = []
    
    for i, section in enumerate(sections):
        if task_type == "test_case_generation":
            prompt = f"""
Please analyze the following document section and generate comprehensive test cases:

**Section Title:** {section['title']}

**Content Summary:** {section['content_summary']}

**Full Content:** {section['full_content']}

**List Items:** {json.dumps(section['list_items'], indent=2)}

Please generate:
1. Functional test cases for any features described
2. Edge cases and error scenarios
3. Integration test scenarios if applicable
4. User acceptance criteria

Format your response as structured test cases with clear steps, expected results, and test data.
"""
        else:
            prompt = f"""
Please analyze the following document section:

**Section Title:** {section['title']}
**Content:** {section['full_content']}

Please provide analysis and insights for this section.
"""
        
        prompts.append({
            "section_index": i + 1,
            "section_title": section['title'],
            "prompt": prompt,
            "content_length": section['content_length']
        })
    
    return prompts

# Example usage
if __name__ == "__main__":
    # Sample file path (replace with your uploaded file)
    sample_file = "Tai_lieu_gia_phap.docx"  # Could be .pdf, .docx, etc.

    # Parse document and get grouped sections
    result = parse_document_to_json(sample_file, group_by_sections=True)

    if result:
        print("=== DOCUMENT PROCESSING COMPLETE ===\n")
        print(json.dumps(result, indent=4, ensure_ascii=False))